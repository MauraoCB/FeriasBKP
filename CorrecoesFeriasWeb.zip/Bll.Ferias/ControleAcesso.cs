﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Pier.Web.Bll.Ferias
{
    public class ControleAcesso : Dao.Ferias.ControleAcesso, IDisposable
    {
        #region Construtor
        public ControleAcesso(string Usuario) : base(Usuario) { }
        #endregion Construtor

        #region Dispose
        public new void Dispose()
        {
            GC.SuppressFinalize(this);
        }
        #endregion Dispose

        #region GetAcessoPorRegistroPerfil
        public new DataTable GetAcessoPorRegistroPerfil(string strFuncRegistro, string strPerfilId)
        {
            try
            {
                return base.GetAcessoPorRegistroPerfil(strFuncRegistro, strPerfilId);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetAcessoPorRegistroPerfil

        #region GetAcessoLiberadoSistemaPorRegistroOutroPerfil
        public new DataTable GetAcessoLiberadoSistemaPorRegistroOutroPerfil(string strFuncRegistro, string strPerfilId)
        {
            try
            {
                return base.GetAcessoLiberadoSistemaPorRegistroOutroPerfil(strFuncRegistro, strPerfilId);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetAcessoLiberadoSistemaPorRegistroOutroPerfil

        #region GetAcessoInativoSistemaPorRegistroPerfil
        public new DataTable GetAcessoInativoSistemaPorRegistroPerfil(string strFuncRegistro, string strPerfilId)
        {
            try
            {
                return base.GetAcessoInativoSistemaPorRegistroPerfil(strFuncRegistro, strPerfilId);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetAcessoInativoSistemaPorRegistroPerfil

        #region GetUsuarioPorRegistro
        public new DataTable GetUsuarioPorRegistro(string strFuncRegistro)
        {
            try
            {
                return base.GetUsuarioPorRegistro(strFuncRegistro);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetUsuarioPorRegistro

        #region RemoveAcesso
        public new bool RemoveAcesso(string strAcessoId, string strPerfilId)
        {
            try
            {
                return base.RemoveAcesso(strAcessoId, strPerfilId);
            }
            catch
            {
                return false;
            }
        }
        #endregion RemoveAcesso

        #region GravaSessao
        public new long GravaSessao(string strUsuarioId)
        {
            try
            {
                return base.GravaSessao(strUsuarioId);
            }
            catch
            {
                return 0;
            }
        }
        #endregion GravaSessao

        #region GravaAcesso
        public new bool GravaAcesso(string strPerfilAcessoId, string strUsuarioId, string strSessaoId)
        {
            try
            {
                return base.GravaAcesso(strPerfilAcessoId, strUsuarioId, strSessaoId);
            }
            catch
            {
                return false;
            }
        }
        #endregion GravaAcesso

        #region AtivaAcesso
        public new bool AtivaAcesso(string strAcessoId, string strPerfilId)
        {
            try
            {
                return base.AtivaAcesso(strAcessoId, strPerfilId);
            }
            catch
            {
                return false;
            }
        }
        #endregion AtivaAcesso

    }
}