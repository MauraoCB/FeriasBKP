﻿using Ferias.Web.Dao.Ferias;
using FeriasWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Pier.Web
{
    public partial class ProgramacaoFerias : System.Web.UI.Page
    {
        const int SEM_13_SALARIO = 0;
        const int PRIMEIRO_PERIODO_13_SALARIO = 1;
        const int SEGUNDO_PERIODO_13_SALARIO = 2;
        const int AMBOS_PERIODOS_13_SALARIO = 3;

        const string APROVADO = "0";
        const string NAO_APROVADO = "1";
        const string PENDENTE_RH = "2";
        const string PENDENTE_GESTOR = "3";
        const string PERDIDO = "4";

        public List<TipoProgramacaoModel> ListaTipoProgramacao
        {
            get
            {
                if (Session["ListaTipoProgramacao"] != null)
                {
                    return (List<TipoProgramacaoModel>)Session["ListaTipoProgramacao"];
                }
                else
                {
                    return new List<TipoProgramacaoModel>();
                }

            }
            set { Session["ListaTipoProgramacao"] = value; }
        }


        public bool AlterouDados        {
            get
            {
                if (Session["AlterouDados"] != null)
                {
                    return (bool)Session["AlterouDados"];
                }
                else
                {
                    return false;
                }

            }
            set { Session["AlterouDados"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {            
            string operacao = "" + Request.QueryString["Operacao"];
          
            if (!IsPostBack)
            {                            
                if (Session["GestorId"] == null)
                {
                    Session["GestorId"] = 0; 
                }
                Session["Funcionarios"] = null;

                if (Session["strPerfilAcesso"].ToString().ToUpper() == "ADMINISTRADOR DO RH" && ControladorSelecaoGestor.GestorId == 0)
                {
                    Session["GestorId"] = 0;
                }

                if (Session["strPerfilAcesso"].ToString().ToUpper().Contains("DELEGA"))
                {
                    var funcionario = new Funcionario().GetFuncionario(Session["strUsuaRegistro"].ToString());
                   
                    Session["GestorId"] = funcionario.FUNC_GESTOR;
                    ControladorSelecaoGestor.GestorId = funcionario.FUNC_GESTOR;
                }

                btnCancelar.Visible = Session["strPerfilAcesso"].ToString().ToUpper() == "ADMINISTRADOR DO RH";

                ddlStatus.Enabled = Session["strPerfilAcesso"].ToString().ToUpper() == "ADMINISTRADOR DO RH"; 
                txtMotivoSatus.Enabled = Session["strPerfilAcesso"].ToString().ToUpper() == "ADMINISTRADOR DO RH";

                // ControladorSelecaoFuncionarios.AoSelecionarFuncionario += ControladorSelecaoFuncionarios_AoSelecionarFuncionario;  

                List<ListItem> listaStatus = new List<ListItem>();
                listaStatus.Add(new ListItem { Text = "(Selecione)", Value = "", Selected = true });
                listaStatus.Add(new ListItem { Text = "Aprovado", Value = "0" });
                listaStatus.Add(new ListItem { Text = "Não Aprovado", Value = "1" });
                listaStatus.Add(new ListItem { Text = "Aprovação Pendente RH", Value = "2" });
                listaStatus.Add(new ListItem { Text = "Aprovação Pendente Gestor", Value = "3" });
                listaStatus.Add(new ListItem { Text = "Perdido", Value = "4" });

                ddlStatus.Items.Clear();
                if (operacao == "APROVAR")
                {
                    //pnlLancamentoProgramacao.Enabled = false;
                    btnSalvar.Visible = false;
                    btnCancelar.Visible = false;
                    //btnAprovar.Visible = true;
                    lblTitulo.Text = "Aprovação de Programação de Férias";
                    ddlStatus.Enabled = true;
                    txtMotivoSatus.Enabled = true;

                    ddlStatus.DataSource = listaStatus.Where(s => s.Value == APROVADO || s.Value == NAO_APROVADO || s.Value=="");
                }
                else
                {
                    ddlStatus.DataSource = listaStatus;
                }
                ddlStatus.DataBind();
            }

            if (Session["strPerfilAcesso"].ToString().ToUpper() == "GESTOR")
            {
                Session["GestorId"] = Session["strUsuaRegistro"];
                ControladorSelecaoGestor.GestorId = Convert.ToInt32(Session["GestorId"]);
            }          
        }

        private void ControladorSelecaoFuncionarios_AoSelecionarFuncionario(object source, EventArgs e)
        {
          //  throw new NotImplementedException();
        }

        protected void Page_Unload(object sender, EventArgs e)
        {
        /*    Session["Funcionarios"] = null;
            Session["ProgramacaoFerias"] = null;
            Session["GestorId"] = null;
            Session["FuncionariosUltimaBusca"] = null;*/
        }

        protected void btnSalvar_Click(object sender, EventArgs e)
        {
            if (cboTipoProgramacao.SelectedIndex < 1)
            {
                Util.Alert.Show(this.Page, "Por favor ecolha um tipo de programação", "info", "Salvar");
                return;
            }

            if (Session["strPerfilAcesso"].ToString().ToUpper() != "ADMINISTRADOR DO RH" && ddlStatus.SelectedValue == PERDIDO)
            {
                Util.Alert.Show(this.Page, "Período perdido, programação não pode ser alterada", "info", "Salvar");
                return;
            }

            if (ddlStatus.SelectedValue == PERDIDO && txtMotivoSatus.Text == "")
            {
                Util.Alert.Show(this.Page, "Obrigatório justificar o motivo da perda do período aquisitivo", "error", "");
                return;
            }

            if (Session["strPerfilAcesso"].ToString().ToUpper() == "GESTOR")
            {
                ddlStatus.SelectedValue = PENDENTE_RH;
            }
            
            if (Session["strPerfilAcesso"].ToString().ToUpper().Contains("DELEGA"))
            {
                VerificarFluxoGestor((FeriasDelegaModel)Session["Delegacao"]);
            }

            SalvarProgramacao("atualizada");
        }

        protected void btnVoltar_Click(object sender, EventArgs e)
        {
            pnlLancamentoProgramacao.Visible = false;
            pnlBotoes.Visible = false;
            ControladorSelecaoFuncionarios.Visible = true;
            tblAprovacao.Visible = false;

            Session["ProgramacaoFerias"] = null;
            ControladorSelecaoFuncionarios.ProgramacaoFerias = new List<ProgramacaoModel>();
            ControladorSelecaoFuncionarios.CarregarGrid((List<FuncionarioModel>)Session["FuncionariosUltimaBusca"]);
        }

        internal void OcultarSelecaoFuncionario()
        {
            ControladorSelecaoFuncionarios.Visible = false;
            pnlLancamentoProgramacao.Visible = true;
            tblAprovacao.Visible = true;
           pnlBotoes.Visible = true;

            CarregarPragramacao();
        }

        protected void cboTipoProgramacao_SelectedIndexChanged(object sender, EventArgs e)
        {
            AlterouDados = true;

            trDias2.Visible = false;
            trProgramacao2.Visible = false;
            tr13Salario2.Visible = false;
            trRetorno2.Visible = false;

            if (cboTipoProgramacao.SelectedIndex <= 0)
            {
                return;
            }
            ConfigurarTipoProgramacao();
            txtMotivoSatus.Text = "";           

            if (!lblCamposAlterados.Text.Contains("Tipo de Programação"))
            {
                lblCamposAlterados.Text += "Tipo de Programação. ";
            }
            CalcularDatasRetorno();
        }

        private void ConfigurarTipoProgramacao()
        {
            var tipoProgramacao = ListaTipoProgramacao.Where(t => t.TPPG_ID.ToString() == cboTipoProgramacao.SelectedValue).FirstOrDefault();

            if (tipoProgramacao == null)
            {
                return;
            }

            var programacaoSelecionada = (ProgramacaoModel)Session["ProgramacaoFeriasSelecionada"];
            if (programacaoSelecionada.PGFR_DIAS_1 == 0)
            {
                txtDias.Text = tipoProgramacao.TPPG_DIAS_1_PER.ToString();
            }
            if (programacaoSelecionada.PGFR_ABONO != 0)
            {
                txtAbono.Text = tipoProgramacao.TPPG_ABONO.ToString();
            }

            if (Session["strPerfilAcesso"].ToString().ToUpper() != "ADMINISTRADOR DO RH")
            {
                DateTime fimPeridoAqusitivo = Convert.ToDateTime(lblPeriodoAquisitivo.Text.Substring(13));
                Calendar1.StartDate = fimPeridoAqusitivo.AddDays(1);
                Calendar1.EndDate = Convert.ToDateTime(lblDataLimite.Text);

                if (tipoProgramacao.TPPG_DIAS_2_PER > 0)
                {
                    Calendar2.StartDate = fimPeridoAqusitivo.AddDays(1);
                    Calendar2.EndDate = Convert.ToDateTime(lblDataLimite.Text);
                }
            }

            if (tipoProgramacao.TPPG_DIAS_2_PER > 0)
            {
                trDias2.Visible = true;
                trProgramacao2.Visible = true;
                tr13Salario2.Visible = true;
                trRetorno2.Visible = true;
                txtDias2.Text = tipoProgramacao.TPPG_DIAS_2_PER.ToString();
            } 
        }

        protected void btnAprovar_Click(object sender, ImageClickEventArgs e)
        {
            if (ddlStatus.SelectedValue == NAO_APROVADO && txtMotivoSatus.Text == "")
            {
                Util.Alert.Show(this.Page, "Obrigatório justificar a não aprovação", "error", "");
                return;
            }

            string autorizado = "1";
            if (ddlStatus.SelectedValue == NAO_APROVADO)
            {
                autorizado = "0";
            }

            if (Session["strPerfilAcesso"].ToString().ToUpper() == "GESTOR" && ddlStatus.SelectedValue == APROVADO)
            {
                autorizado = "0";
                ddlStatus.ClearSelection();
                ddlStatus.Items.Add(new ListItem { Text = "Aprovação Pendente RH", Value = "2" });
                ddlStatus.SelectedValue = PENDENTE_RH;
                txtMotivoSatus.Text = "";
            }
            if (AlterouDados)
            {
                SalvarProgramacao("Aprovar");
            }

            string jsonProgramacoesAprovar = $"[{{PGFR_ID : '{ControladorSelecaoFuncionarios.IdPrevisaoProgramacao}', Autorizado : '{autorizado}', Status: '{ddlStatus.SelectedItem.Text}', MotivoStatus : '{txtMotivoSatus.Text}'}}]";

            ProgramacaoFeriasDAO programacaoFeriasDAO = new ProgramacaoFeriasDAO();
            string[] retorno = programacaoFeriasDAO.AprovarProgramacoes(jsonProgramacoesAprovar).Result;

            Util.Alert.Show(this.Page, retorno[1], retorno[0], "Aprovação");

            btnVoltar_Click(sender, e);
        }

        #region Private methods

        private void CalcularDatasRetorno()
        {
            if (Util.ValidationHelper.IsDate(txtProgramacao.Text))
            {
                txtRetorno.Text = Convert.ToDateTime(txtProgramacao.Text).AddDays(double.Parse("0" + txtDias.Text)).ToString("dd/MM/yyyy");
            }
            if (Util.ValidationHelper.IsDate(txtProgramacao2.Text))
            {
                txtRetorno2.Text = Convert.ToDateTime(txtProgramacao2.Text).AddDays(double.Parse("0" + txtDias2.Text)).ToString("dd/MM/yyyy");
            }
        }
        private void SalvarProgramacao(string operacao)
        {
            try
            {
                //Salva / cancela a programação de férias
                var programacaoSalvar = (ProgramacaoModel)Session["ProgramacaoFeriasSelecionada"];

                programacaoSalvar.TPPG_ID = Convert.ToInt16(cboTipoProgramacao.SelectedValue);

                programacaoSalvar.PGFR_AUTORIZADO = false;

                if (operacao == "atualizada")
                {
                    programacaoSalvar.PGFR_CAMPOS_ALTERADOS = lblCamposAlterados.Text;

                    programacaoSalvar.PGFR_ABONO = Convert.ToInt16(txtAbono.Text.PadLeft(1, '0'));
                    if (Util.ValidationHelper.IsDate(txtProgramacao.Text))
                    {
                        programacaoSalvar.PGFR_PROGRAMACAO_1 = Convert.ToDateTime(txtProgramacao.Text);
                    }
                    programacaoSalvar.PGFR_DIAS_1 = Convert.ToInt16(txtDias.Text.PadLeft(1, '0'));
                    if (Util.ValidationHelper.IsDate(txtProgramacao2.Text))
                    {
                        programacaoSalvar.PGFR_PROGRAMACAO_2 = Convert.ToDateTime(txtProgramacao2.Text);
                    }
                    programacaoSalvar.PGFR_DIAS_2 = Convert.ToInt16(txtDias2.Text.PadLeft(1, '0'));
                    programacaoSalvar.PGFR_13 = SEM_13_SALARIO;

                    if (chk13Salario1.Checked && !chk13Salario2.Checked)
                    {
                        programacaoSalvar.PGFR_13 = PRIMEIRO_PERIODO_13_SALARIO;
                    }

                    if (!chk13Salario1.Checked && chk13Salario2.Checked)
                    {
                        programacaoSalvar.PGFR_13 = SEGUNDO_PERIODO_13_SALARIO;
                    }

                    if (chk13Salario1.Checked && chk13Salario2.Checked)
                    {
                        programacaoSalvar.PGFR_13 = AMBOS_PERIODOS_13_SALARIO;
                    }

                    if (Session["strPerfilAcesso"].ToString().ToUpper() != "ADMINISTRADOR DO RH")
                    {
                        if (programacaoSalvar.PGFR_PROGRAMACAO_1 < Calendar1.StartDate || programacaoSalvar.PGFR_PROGRAMACAO_1 > Calendar1.EndDate)
                        {
                            Util.Alert.Show(this.Page, "Programação 1 inválida", "error", "Data não Permitida");
                            return;
                        }

                        if ((programacaoSalvar.PGFR_PROGRAMACAO_2 < Calendar2.StartDate || programacaoSalvar.PGFR_PROGRAMACAO_2 > Calendar2.EndDate) && programacaoSalvar.PGFR_PROGRAMACAO_2 != DateTime.MinValue)
                        {
                            Util.Alert.Show(this.Page, "Programação 2 inválida", "error", "Data não Permitida");
                            return;
                        }

                        if (DateTime.Now.Day >5)
                        {
                            if (programacaoSalvar.PGFR_PROGRAMACAO_1.Subtract(DateTime.Now).Days < 30 || (programacaoSalvar.PGFR_PROGRAMACAO_2 != DateTime.MinValue && programacaoSalvar.PGFR_PROGRAMACAO_2.Subtract(DateTime.Now).Days < 30))
                            {
                                Util.Alert.Show(this.Page, $"Período de aprovação de férias para {DateTime.Now.ToString("MM/yyyy")} e {DateTime.Now.AddMonths(1).ToString("MM/yyyy")} encerrado. Não é possível efetuar alterações na programação.", "info", "");
                                return;
                            }
                        }
                    }
                    else
                    {
                        //ddlStatus.SelectedIndex = 1;
                        txtMotivoSatus.Text = "";
                    }

                    if (ddlStatus.SelectedValue == NAO_APROVADO && txtMotivoSatus.Text == "")
                    {
                        Util.Alert.Show(this.Page, "Obrigatório justificar a não aprovação", "error", "");
                        return;
                    }

                    programacaoSalvar.PGFR_STATUS = ddlStatus.SelectedItem.Text;
                    programacaoSalvar.PGFR_MOTIVO_STATUS = txtMotivoSatus.Text;
                    programacaoSalvar.PGFR_DT_LANC_PERIODO = DateTime.Now;
                }
                else
                {                    
                    programacaoSalvar.TPPG_ID = null;
                    programacaoSalvar.PGFR_ABONO = 0;
                    programacaoSalvar.PGFR_PROGRAMACAO_1 = DateTime.MinValue;
                    programacaoSalvar.PGFR_DIAS_1 = 0;
                    programacaoSalvar.PGFR_PROGRAMACAO_2 = DateTime.MinValue;
                    programacaoSalvar.PGFR_DIAS_2 = 0;
                    programacaoSalvar.PGFR_13 = SEM_13_SALARIO;
                    programacaoSalvar.PGFR_STATUS = "";
                    programacaoSalvar.PGFR_MOTIVO_STATUS = "";
                    programacaoSalvar.PGFR_CAMPOS_ALTERADOS = "";
                    programacaoSalvar.PGFR_DT_LANC_PERIODO = DateTime.MinValue;
                }

                _ = new ProgramacaoFeriasDAO().SaveProgramacaoFerias(programacaoSalvar);

                if (operacao != "Aprovar")
                {
                    Util.Alert.Show(this.Page, "Programação " + operacao + " com sucesso", "info", "");
                }
                    System.Threading.Thread.Sleep(5000);

                    btnVoltar_Click(null, null);               
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private void CarregarPragramacao()
        {
            txtProgramacao2.Text = "";
            txtProgramacao.Text = "";

            var programacaoFerias = ControladorSelecaoFuncionarios.ProgramacaoFerias.Where(p => p.PGFR_ID == ControladorSelecaoFuncionarios.IdPrevisaoProgramacao).FirstOrDefault();
            if (programacaoFerias == null)
            {
                return;
            }

            Session["ProgramacaoFeriasSelecionada"] = programacaoFerias;
            
            lblCamposAlterados.Text = programacaoFerias.PGFR_CAMPOS_ALTERADOS;
            trCamposAlterados.Visible = lblCamposAlterados.Text.Length > 0;

            lblNomeFuncionario.Text = programacaoFerias.PGFR_NOME;
            lblRegistroFuncionario.Text = programacaoFerias.PGFR_MATRICULA.ToString();
            lblCargo.Text = ControladorSelecaoFuncionarios.FuncionarioSelecionado.FUNC_CARGO;
            if (programacaoFerias.PGFR_DATA_LIMITE != DateTime.MinValue)
            {
                lblDataLimite.Text = programacaoFerias.PGFR_DATA_LIMITE.ToString("dd/MM/yyyy");
            }
            lblPeriodoAquisitivo.Text = programacaoFerias.PGFR_PERIODO_AQUISITIVO;

            //Carrega o combo de tipos de programação de acordo com a coluna OPER_ADM da view de equipes
            CarregarTipoProgramacao(ControladorSelecaoFuncionarios.FuncionarioSelecionado.FUNC_ID);

            if (programacaoFerias.TPPG_ID != null)
            {
                cboTipoProgramacao.SelectedValue = programacaoFerias.TPPG_ID.ToString();
            }
            txtProgramacao.Text = "";

            if (programacaoFerias.PGFR_PROGRAMACAO_1 != DateTime.MinValue)
            {
                txtProgramacao.Text = programacaoFerias.PGFR_PROGRAMACAO_1.ToString("dd/MM/yyyy");
            }
            txtDias.Text = programacaoFerias.PGFR_DIAS_1.ToString();

            if (programacaoFerias.PGFR_PROGRAMACAO_2 != DateTime.MinValue)
            {
                txtProgramacao2.Text = programacaoFerias.PGFR_PROGRAMACAO_2.ToString("dd/MM/yyyy");
            }
            txtDias2.Text = programacaoFerias.PGFR_DIAS_2.ToString();

            txtAbono.Text = programacaoFerias.PGFR_ABONO.ToString();
            chk13Salario1.Checked = false;
            chk13Salario2.Checked = false;
            chk13Salario1.Checked = (programacaoFerias.PGFR_13 == 1 || programacaoFerias.PGFR_13 == 3);
            chk13Salario2.Checked = (programacaoFerias.PGFR_13 == 2 || programacaoFerias.PGFR_13 == 3);
            chk13Salario1.Enabled = programacaoFerias.PGFR_PROGRAMACAO_1.Month >= 2 && programacaoFerias.PGFR_PROGRAMACAO_1.Month <= 6;
            chk13Salario2.Enabled = programacaoFerias.PGFR_PROGRAMACAO_2.Month >= 2 && programacaoFerias.PGFR_PROGRAMACAO_2.Month <= 6;
             
            if (Request.QueryString["Operacao"] != null && programacaoFerias.PGFR_STATUS== "Aprovação Pendente RH" && Session["strPerfilAcesso"].ToString().ToUpper() == "GESTOR")
            {
                ddlStatus.Items.Add(new ListItem { Text = "Aprovação Pendente RH", Value = "2" });
                ddlStatus.Enabled = false;
            }

            for (int i = 0; i < ddlStatus.Items.Count; i++)
            {
                if (programacaoFerias.PGFR_STATUS == ddlStatus.Items[i].Text)
                {
                    ddlStatus.SelectedIndex = i;
                }  
            }
            
            txtMotivoSatus.Text = programacaoFerias.PGFR_MOTIVO_STATUS;
            trMotivoStatus.Visible = (programacaoFerias.PGFR_STATUS == "Não Aprovado" || programacaoFerias.PGFR_STATUS == "Perdido");

            ConfigurarTipoProgramacao();
            CalcularDatasRetorno();         

            if (Session["strPerfilAcesso"].ToString().ToUpper().Contains ("DELEGA"))
            {                
                var delegacao = new FeriasDelega().GetFeriasDelega(Convert.ToInt32(Session["GestorId"])).Where(d => d.FUNC_REGISTRO_FILHO == programacaoFerias.PGFR_MATRICULA && d.FUNC_REGISTRO_DELEGADO == Convert.ToInt32(Session["strUsuaRegistro"]) && d.FRDL_ATIVO == true).FirstOrDefault();

                Session["Delegacao"] = delegacao;

                if (String.IsNullOrEmpty(programacaoFerias.PGFR_STATUS))
                {
                    ddlStatus.ClearSelection();
                    VerificarFluxoGestor(delegacao); 
                }
            }
        }

        private void CarregarTipoProgramacao(int funcId)
        {
            ListaTipoProgramacao = new TipoProgramacao().GetTipoProgramacao();

            var equipeFuncionario = new Funcionario().GetEquipeFuncionarios().Where(e => e.FUNC_ID == funcId).FirstOrDefault();

            if (equipeFuncionario != null)
            {
                if (equipeFuncionario.OperAdm == 0)
                {                   
                    ListaTipoProgramacao = ListaTipoProgramacao.Where(t => t.TPVZ_ID == 1 || t.TPVZ_ID == 3).ToList();
                }               
            }
            else
            {
                if (ControladorSelecaoFuncionarios.FuncionarioSelecionado.FUNC_TP_MDO.Substring(0,3).ToUpper() == "MOD")
                {
                    ListaTipoProgramacao = ListaTipoProgramacao.Where(t => t.TPVZ_ID == 1 || t.TPVZ_ID == 3).ToList();
                }
            }

            cboTipoProgramacao.Items.Clear();
            cboTipoProgramacao.Items.Add(new ListItem { Value = "0", Text = "(Selecione)", Selected = true });

            foreach (var item in ListaTipoProgramacao)
            {
                cboTipoProgramacao.Items.Add(new ListItem { Value = item.TPPG_ID.ToString(), Text = item.TPPG_DESCRICAO });
            }
        }

        private bool Habilitar13Salario(string dataProgramacao)
        {
            DateTime outDataProgramacao;
            if (!DateTime.TryParse(dataProgramacao, out outDataProgramacao))
            {
                return false;
            }

            int mes = Convert.ToDateTime(dataProgramacao).Month;

            return mes >= 2 && mes <= 6;
        }
        private void VerificarFluxoGestor(FeriasDelegaModel delegacao)
        {
            if (delegacao.FRDL_FLOW_GESTOR)
            {
                ddlStatus.SelectedValue = PENDENTE_GESTOR;
            }
            else
            {
                ddlStatus.SelectedValue = PENDENTE_RH;
            }
        }
        #endregion

        protected void txtProgramacao_TextChanged(object sender, EventArgs e)
        {
            AlterouDados = true;
            chk13Salario1.Checked = false;
            chk13Salario1.Enabled = Habilitar13Salario(txtProgramacao.Text);
            txtMotivoSatus.Text = "";

            ddlStatus.SelectedValue = PENDENTE_RH;
            if (Session["strPerfilAcesso"].ToString().ToUpper().Contains("DELEGA"))
            {
                VerificarFluxoGestor((FeriasDelegaModel)Session["Delegacao"]);
            }

            if (!lblCamposAlterados.Text.Contains("Programação 1º Período"))
            {
                lblCamposAlterados.Text += "Programação 1º Período. ";
            }
            CalcularDatasRetorno();
        }

        protected void txtProgramacao2_TextChanged(object sender, EventArgs e)
        {
            AlterouDados = true;
            chk13Salario2.Checked = false;
            chk13Salario2.Enabled = Habilitar13Salario(txtProgramacao2.Text);
            txtMotivoSatus.Text = "";
                 
            ddlStatus.SelectedValue = PENDENTE_RH;
            if (Session["strPerfilAcesso"].ToString().ToUpper().Contains("DELEGA"))
            {
                VerificarFluxoGestor((FeriasDelegaModel)Session["Delegacao"]);
            }

            if (!lblCamposAlterados.Text.Contains("Programação 2º Período"))
            {
                lblCamposAlterados.Text += "Programação 2º Período. ";
            }
            CalcularDatasRetorno();
        }

        protected void btnCancelar_Click1(object sender, EventArgs e)
        {
            SalvarProgramacao("cancelada");
        }

        protected void ddlStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            trMotivoStatus.Visible = (ddlStatus.SelectedValue== NAO_APROVADO || ddlStatus.SelectedValue== PERDIDO);
            btnAprovar.Visible = ddlStatus.SelectedValue == APROVADO;
            btnReprovar.Visible = ddlStatus.SelectedValue == NAO_APROVADO;
        }

        protected void chk13Salario1_CheckedChanged(object sender, EventArgs e)
        {
            AlterouDados = true;
            if (!lblCamposAlterados.Text.Contains("13º Salário 1º Período"))
            {
                lblCamposAlterados.Text += "13º Salário 1º Período. ";
            }
        }

        protected void chk13Salario2_CheckedChanged(object sender, EventArgs e)
        {
            AlterouDados = true;
            if (!lblCamposAlterados.Text.Contains("13º Salário 2º Período"))
            {
                lblCamposAlterados.Text += "13º Salário 2º Período. ";                
            }
        }
    }
}