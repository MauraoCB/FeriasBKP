﻿using FeriasWeb.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI.WebControls;

namespace Ferias.Web.Dao.Ferias
{
    public class TipoProgramacao : System.Web.UI.Page
    {
        #region Variables
        private string uri = System.Configuration.ConfigurationManager.AppSettings["UrlFeriasAPI"];
        #endregion

        public List<TipoVisualizacaoModel> GetTipoVisualizacao()
        {
            string Metodo = "TipoProgramacao/GetTipoVisualizacao/";
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;
            List<TipoVisualizacaoModel> result = new List<TipoVisualizacaoModel>();

            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(20);
                using (var response = client.GetAsync(Url).GetAwaiter().GetResult())
                {
                    Retorno = response.IsSuccessStatusCode ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : response.ReasonPhrase.ToString();
                }
            }

            result = JsonConvert.DeserializeObject<List<TipoVisualizacaoModel>>(Retorno);
            return result;
        }

        public List<TipoProgramacaoModel> GetTipoProgramacao(string tipoProgramacaoId = "")
        {
           /* if (Session["ListaTipoProgramacaoTotal"] != null && tipoProgramacaoId == "")
            {
                return (List<TipoProgramacaoModel>)Session["ListaTipoProgramacaoTotal"];
            }*/

            string Metodo = string.Concat("TipoProgramacao/GetTipoProgramacao/", tipoProgramacaoId);
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;
            List<TipoProgramacaoModel> result = new List<TipoProgramacaoModel>();

            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(20);
                using (var response = client.GetAsync(Url).GetAwaiter().GetResult())
                {
                    Retorno = response.IsSuccessStatusCode ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : response.ReasonPhrase.ToString();
                }
            }

            result = JsonConvert.DeserializeObject<List<TipoProgramacaoModel>>(Retorno);
            Session["ListaTipoProgramacaoTotal"] = result;

            return result;
        }

        public string GetDescricaoTipoProgramacao(int? tppgId)
        {
            if (tppgId == null)
            {
                return "";
            }
            return GetTipoProgramacao(tppgId.ToString()).FirstOrDefault().TPPG_DESCRICAO;
        }
        public async Task<string> SalvarTipoProgramacao(TipoProgramacaoModel tipoProgramacao)
        {
            string Metodo = string.Concat("TipoProgramacao/SaveTipoProgramacao");
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;
            string jsonTipoProgramacao = JsonConvert.SerializeObject(tipoProgramacao);


            var httpContent = new StringContent(jsonTipoProgramacao, Encoding.UTF8, "application/json");

            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(20);
                using (var response = await client.PostAsync(Url, httpContent))
                {
                    Retorno = response.IsSuccessStatusCode ? await response.Content.ReadAsStringAsync() : response.ReasonPhrase.ToString();
                }
            }

            return Retorno;
        }
    }
}