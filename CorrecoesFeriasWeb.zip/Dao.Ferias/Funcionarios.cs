﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Pier.Entity;
using Pier.Entity.Acesso;
using NHibernate;

namespace Pier.Web.Dao.Ferias
{
    public class Funcionarios : ECRUD.Oracle
    {
        #region Properties
        public string Ambiente { get; private set; }
        public string Usuario { get; private set; }
        #endregion Properties

        #region Construtor
        public Funcionarios(string Usuario)
        {
            Ambiente = System.Configuration.ConfigurationManager.AppSettings["Ambiente"].ToString();
            this.Usuario = Usuario;
        }
        #endregion Construtor

        #region GetVariaveisFuncionariosPorRegistro
        public DataTable GetVariaveisFuncionariosPorRegistro(string strRegistro)
        {
            try
            {
                /*
                string strQuery = "";
                strQuery = strQuery + "SELECT F.*, U.USUA_ID, U.USUA_LOGIN, U.USUA_PORTARIA, U.USUA_RH, U.USUA_MASTER, U.USUA_TOTAL_RH, E.NOME NOME_EMPRESA, TRIM(REPLACE(REPLACE(F.FUNC_CPF,'-',''),'.','')) USUA_CPF ";
                strQuery = strQuery + "  FROM TELEMAT.FUNCIONARIOS F, ACESSOS.USUARIOS U, ESCALA.EMPRESAS E ";
                strQuery = strQuery + " WHERE F.FUNC_REGISTRO = U.USUA_REGISTRO AND U.USUA_REGISTRO = '" + strRegistro + "' AND E.EMPR_FILIAL(+) = F.FUNC_FILIAL ";
                */

                string strQuery = "SELECT DISTINCT F.*, U.USUA_ID, U.USUA_LOGIN, U.USUA_PORTARIA, U.USUA_RH, U.USUA_MASTER, U.USUA_TOTAL_RH, E.EMFL_UNIDADE_DESCRICAO NOME_EMPRESA, TRIM(REPLACE(REPLACE(F.FUNC_CPF,'-',''),'.','')) USUA_CPF FROM RESTRITO.V_FUNCIONARIOS F, ACESSOS.USUARIOS@CORP_LINK U, RESTRITO.EMPRESA_FILIAL E WHERE F.FUNC_REGISTRO = U.USUA_REGISTRO AND U.USUA_REGISTRO = '" + strRegistro + "' AND E.EMFL_UNIDADE = F.UNIDADE AND E.EMFL_ID_FILIAL = F.FUNC_FILIAL";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetVariaveisFuncionariosPorRegistro

        #region GetFuncionario
        public DataTable GetFuncionario(string Ambiente, string strNome)
        {
            try
            {
                if (strNome.Contains("'")) strNome = strNome.Replace("'", "´");
                string strQuery = "SELECT F.*, F.FUNC_GESTOR || ' - ' || F.FUNC_GESTOR_NOME GESTOR, E.*, D.*, CC.*, E.EMFL_ID_FILIAL || ' - ' || E.EMFL_DESCRICAO DESCRICAO_FILIAL FROM RESTRITO.V_FUNCIONARIOS F, RESTRITO.EMPRESA_FILIAL E, RESTRITO.V_DEPARTAMENTOS D, RESTRITO.CENTRO_DE_CUSTO CC WHERE F.FUNC_NOME LIKE '%" + strNome.Replace("'", "''") + "%' AND F.FUNC_ATIVO = 1 AND (F.UNIDADE = '" + Ambiente.ToString() + "' OR '" + Ambiente.ToString() + "' IS NULL) AND D.DPTO_ID = F.DEPARTAMENTO AND D.UNIDADE = F.UNIDADE AND CC.CEDC_CC_ID = F.FUNC_CC AND CC.CEDC_EMPRESA = F.UNIDADE AND E.EMFL_UNIDADE = F.UNIDADE AND E.EMFL_ID_FILIAL = F.FUNC_FILIAL ORDER BY F.FUNC_NOME";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetFuncionario(string Ambiente, int intRegistro)
        {
            try
            {
                string strQuery = "SELECT F.*, F.FUNC_GESTOR || ' - ' || F.FUNC_GESTOR_NOME GESTOR, E.*, D.*, CC.*, E.EMFL_ID_FILIAL || ' - ' || E.EMFL_DESCRICAO DESCRICAO_FILIAL FROM RESTRITO.V_FUNCIONARIOS F, RESTRITO.EMPRESA_FILIAL E, RESTRITO.V_DEPARTAMENTOS D, RESTRITO.CENTRO_DE_CUSTO CC WHERE F.FUNC_REGISTRO = " + intRegistro + " AND F.FUNC_ATIVO = 1 AND (F.UNIDADE = '" + Ambiente.ToString() + "' OR '" + Ambiente.ToString() + "' IS NULL) AND D.DPTO_ID(+) = F.DEPARTAMENTO AND D.UNIDADE(+) = F.UNIDADE AND CC.CEDC_CC_ID = F.FUNC_CC AND CC.CEDC_EMPRESA = F.UNIDADE AND E.EMFL_UNIDADE = F.UNIDADE AND E.EMFL_ID_FILIAL = F.FUNC_FILIAL ORDER BY F.FUNC_NOME";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetFuncionario

        #region GetFuncionarioSub
        public DataTable GetFuncionarioSub(string Ambiente, string strNome)
        {
            try
            {
                if (strNome.Contains("'")) strNome = strNome.Replace("'", "´");
                string strQuery = "SELECT F.*, F.FUNC_GESTOR || ' - ' || F.FUNC_GESTOR_NOME GESTOR, E.*, D.*, CC.*, E.EMFL_ID_FILIAL || ' - ' || E.EMFL_DESCRICAO DESCRICAO_FILIAL FROM RESTRITO.V_FUNCIONARIOS_SUB F, RESTRITO.EMPRESA_FILIAL E, RESTRITO.V_DEPARTAMENTOS D, RESTRITO.CENTRO_DE_CUSTO CC WHERE F.FUNC_NOME LIKE '%" + strNome.Replace("'", "''") + "%' AND (F.UNIDADE = '" + Ambiente.ToString() + "' OR '" + Ambiente.ToString() + "' IS NULL) AND D.DPTO_ID = F.DEPARTAMENTO AND D.UNIDADE = F.UNIDADE AND CC.CEDC_CC_ID = F.FUNC_CC AND CC.CEDC_EMPRESA = F.UNIDADE AND E.EMFL_UNIDADE = F.UNIDADE AND E.EMFL_ID_FILIAL = F.FUNC_FILIAL ORDER BY F.FUNC_NOME";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetFuncionarioSub(string Ambiente, int intRegistro)
        {
            try
            {
                string strQuery = "SELECT F.*, F.FUNC_GESTOR || ' - ' || F.FUNC_GESTOR_NOME GESTOR, E.*, D.*, CC.*, E.EMFL_ID_FILIAL || ' - ' || E.EMFL_DESCRICAO DESCRICAO_FILIAL FROM RESTRITO.V_FUNCIONARIOS_SUB F, RESTRITO.EMPRESA_FILIAL E, RESTRITO.V_DEPARTAMENTOS D, RESTRITO.CENTRO_DE_CUSTO CC WHERE F.FUNC_REGISTRO = " + intRegistro + " AND (F.UNIDADE = '" + Ambiente.ToString() + "' OR '" + Ambiente.ToString() + "' IS NULL) AND D.DPTO_ID(+) = F.DEPARTAMENTO AND D.UNIDADE(+) = F.UNIDADE AND CC.CEDC_CC_ID = F.FUNC_CC AND CC.CEDC_EMPRESA = F.UNIDADE AND E.EMFL_UNIDADE = F.UNIDADE AND E.EMFL_ID_FILIAL = F.FUNC_FILIAL ORDER BY F.FUNC_NOME";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetFuncionarioSub

        #region GetFuncionarioAll
        public DataTable GetFuncionarioAll(string Ambiente, int intRegistro)
        {
            try
            {
                string strQuery = "SELECT F.*, F.FUNC_GESTOR || ' - ' || F.FUNC_GESTOR_NOME GESTOR, E.*, D.*, CC.*, E.EMFL_ID_FILIAL || ' - ' || E.EMFL_DESCRICAO DESCRICAO_FILIAL FROM RESTRITO.V_FUNCIONARIOS F, RESTRITO.EMPRESA_FILIAL E, RESTRITO.V_DEPARTAMENTOS D, RESTRITO.CENTRO_DE_CUSTO CC WHERE F.FUNC_REGISTRO = " + intRegistro + " AND F.UNIDADE = '" + Ambiente.ToString() + "' AND D.DPTO_ID = F.DEPARTAMENTO AND D.UNIDADE = F.UNIDADE AND CC.CEDC_CC_ID = F.FUNC_CC AND CC.CEDC_EMPRESA = F.UNIDADE AND E.EMFL_UNIDADE = F.UNIDADE AND E.EMFL_ID_FILIAL = F.FUNC_FILIAL";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetFuncionarioAll

        #region GetFuncionarioAcesso
        public DataTable GetFuncionarioAcesso(int intRegistro)
        {
            try
            {
                string strQuery = "SELECT * FROM ACESSOS.TBL_FUNCIONARIOS@CORPDW_LINK WHERE FUNC_ATIVO = 1 AND FUNC_REGISTRO = " + intRegistro + "";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetFuncionarioAcesso(string strNome)
        {
            try
            {
                string strQuery = "SELECT * FROM ACESSOS.TBL_FUNCIONARIOS@CORPDW_LINK WHERE FUNC_ATIVO = 1 AND FUNC_NOME LIKE '%" + strNome.Replace("'", "''") + "%'";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetFuncionarioAcesso

        #region GetMaxDataMovimentacaoSalarial
        public DataTable GetMaxDataMovimentacaoSalarial(int intRegistro)
        {
            try
            {
                string strQuery = "SELECT RESTRITO.F_GET_ULTIMA_MOV_SALARIAL(" + intRegistro.ToString() + ") DT_ULT_MOV_SAL FROM DUAL";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetMaxDataMovimentacaoSalarial

        #region GetHistoricoMovimentacaoSalarial
        public DataTable GetHistoricoMovimentacaoSalarial(int intRegistro)
        {
            try
            {
                //string strQuery = "SELECT HM.FUNC_REGISTRO_MOV, HM.SLMV_DATA, TO_CHAR (HM.SLMV_SALARIO_DELTA_2, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 1";
                //string strQuery = "SELECT HM.FUNC_REGISTRO_MOV, TO_DATE(HM.SLMV_DATA_FOLHA,'DD/MM/YY') SLMV_DATA, TO_CHAR (HM.SLMV_SALARIO_DELTA_2, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_DATA_FOLHA IS NOT NULL UNION ALL SELECT HM.FUNC_REGISTRO_MOV, HM.SLMV_DATA, TO_CHAR (HM.SLMV_SALARIO_DELTA_2, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 1 ORDER BY (2) DESC";
                //string strQuery = "SELECT HM.FUNC_REGISTRO_MOV, HM.SLMV_DATA, TO_CHAR (HM.SLMV_SALARIO_DELTA_2, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 1 UNION ALL SELECT HM.FUNC_REGISTRO_MOV, TO_DATE (HM.SLMV_DATA_FOLHA, 'DD/MM/YY') SLMV_DATA, TO_CHAR (HM.SLMV_SALARIO_DELTA_2, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'N' AND HM.SLMV_DATA_FOLHA IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO,HM.SLMV_MERITO,HM.SLMV_PROMOCAO) UNION ALL SELECT HM.FUNC_REGISTRO_MOV, TO_DATE (HM.SLMV_ESCALONADO_DT1, 'DD/MM/YY') SLMV_DATA, TO_CHAR (HM.SLMV_ESCALONADO_DELTA1, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'S' AND HM.SLMV_ESCALONADO_DT_FOLHA1 IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO,HM.SLMV_MERITO,HM.SLMV_PROMOCAO) UNION ALL SELECT HM.FUNC_REGISTRO_MOV, TO_DATE (HM.SLMV_ESCALONADO_DT2, 'DD/MM/YY') SLMV_DATA, TO_CHAR (HM.SLMV_ESCALONADO_DELTA2, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'S' AND HM.SLMV_ESCALONADO_DT_FOLHA2 IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO,HM.SLMV_MERITO,HM.SLMV_PROMOCAO) UNION ALL SELECT HM.FUNC_REGISTRO_MOV, TO_DATE (HM.SLMV_ESCALONADO_DT3, 'DD/MM/YY') SLMV_DATA, TO_CHAR (HM.SLMV_ESCALONADO_DELTA3, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'S' AND HM.SLMV_ESCALONADO_DT_FOLHA3 IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO,HM.SLMV_MERITO,HM.SLMV_PROMOCAO) ORDER BY (2) DESC";
                //string strQuery = "SELECT HM.FUNC_REGISTRO_MOV, HM.SLMV_DATA, TO_CHAR (HM.SLMV_SALARIO_DELTA_2, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 1 UNION ALL SELECT HM.FUNC_REGISTRO_MOV, '01/' || TO_CHAR(HM.SLMV_DATA_FOLHA,'MM/YYYY') SLMV_DATA, TO_CHAR (HM.SLMV_SALARIO_DELTA_2, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE     HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'N' AND HM.SLMV_DATA_FOLHA IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO, HM.SLMV_MERITO, HM.SLMV_PROMOCAO) UNION ALL SELECT HM.FUNC_REGISTRO_MOV, TO_DATE (HM.SLMV_ESCALONADO_DT1, 'DD/MM/YY') SLMV_DATA, TO_CHAR (HM.SLMV_ESCALONADO_DELTA1, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento (Escalonado)' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito (Escalonado)' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção (Escalonado)' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE     HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'S' AND HM.SLMV_ESCALONADO_DT_FOLHA1 IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO, HM.SLMV_MERITO, HM.SLMV_PROMOCAO) UNION ALL SELECT HM.FUNC_REGISTRO_MOV, TO_DATE (HM.SLMV_ESCALONADO_DT2, 'DD/MM/YY') SLMV_DATA, TO_CHAR (HM.SLMV_ESCALONADO_DELTA2, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento (Escalonado)' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito (Escalonado)' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção (Escalonado)' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE     HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'S' AND HM.SLMV_ESCALONADO_DT_FOLHA2 IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO, HM.SLMV_MERITO, HM.SLMV_PROMOCAO) UNION ALL SELECT HM.FUNC_REGISTRO_MOV, TO_DATE (HM.SLMV_ESCALONADO_DT3, 'DD/MM/YY') SLMV_DATA, TO_CHAR (HM.SLMV_ESCALONADO_DELTA3, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento (Escalonado)' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito (Escalonado)' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção (Escalonado)' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE     HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'S' AND HM.SLMV_ESCALONADO_DT_FOLHA3 IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO, HM.SLMV_MERITO, HM.SLMV_PROMOCAO) ORDER BY (2) DESC";
                //string strQuery = "SELECT HM.FUNC_REGISTRO_MOV, TO_CHAR(HM.SLMV_DATA,'DD/MM/YYYY') SLMV_DATA, TO_CHAR (HM.SLMV_SALARIO_DELTA_2, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 1 UNION ALL SELECT HM.FUNC_REGISTRO_MOV, '01/' || TO_CHAR (HM.SLMV_DATA_FOLHA, 'MM/YYYY') SLMV_DATA, TO_CHAR (HM.SLMV_SALARIO_DELTA_2, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'N' AND HM.SLMV_DATA_FOLHA IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO, HM.SLMV_MERITO, HM.SLMV_PROMOCAO) UNION ALL SELECT HM.FUNC_REGISTRO_MOV, TO_CHAR (HM.SLMV_ESCALONADO_DT1, 'DD/MM/YYYY') SLMV_DATA, TO_CHAR (HM.SLMV_ESCALONADO_DELTA1, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento (Escalonado)' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito (Escalonado)' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção (Escalonado)' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'S' AND HM.SLMV_ESCALONADO_DT_FOLHA1 IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO, HM.SLMV_MERITO, HM.SLMV_PROMOCAO) UNION ALL SELECT HM.FUNC_REGISTRO_MOV, TO_CHAR (HM.SLMV_ESCALONADO_DT2, 'DD/MM/YYYY') SLMV_DATA, TO_CHAR (HM.SLMV_ESCALONADO_DELTA2, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento (Escalonado)' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito (Escalonado)' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção (Escalonado)' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'S' AND HM.SLMV_ESCALONADO_DT_FOLHA2 IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO, HM.SLMV_MERITO, HM.SLMV_PROMOCAO) UNION ALL SELECT HM.FUNC_REGISTRO_MOV, TO_CHAR (HM.SLMV_ESCALONADO_DT3, 'DD/MM/YYYY') SLMV_DATA, TO_CHAR (HM.SLMV_ESCALONADO_DELTA3, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento (Escalonado)' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito (Escalonado)' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção (Escalonado)' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'S' AND HM.SLMV_ESCALONADO_DT_FOLHA3 IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO, HM.SLMV_MERITO, HM.SLMV_PROMOCAO) ORDER BY (2) DESC";
                string strQuery = "SELECT FUNC_REGISTRO_MOV, TO_DATE(SLMV_DATA) SLMV_DATA, SLMV_SALARIO_DELTA_2, TIPO FROM (SELECT HM.FUNC_REGISTRO_MOV, TO_CHAR(HM.SLMV_DATA,'DD/MM/YYYY') SLMV_DATA, TO_CHAR (HM.SLMV_SALARIO_DELTA_2, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 1 UNION ALL SELECT HM.FUNC_REGISTRO_MOV, '01/' || TO_CHAR (HM.SLMV_DATA_FOLHA, 'MM/YYYY') SLMV_DATA, TO_CHAR (HM.SLMV_SALARIO_DELTA_2, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'N' AND HM.SLMV_DATA_FOLHA IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO, HM.SLMV_MERITO, HM.SLMV_PROMOCAO) UNION ALL SELECT HM.FUNC_REGISTRO_MOV, TO_CHAR (HM.SLMV_ESCALONADO_DT1, 'DD/MM/YYYY') SLMV_DATA, TO_CHAR (HM.SLMV_ESCALONADO_DELTA1, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento (Escalonado)' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito (Escalonado)' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção (Escalonado)' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'S' AND HM.SLMV_ESCALONADO_DT_FOLHA1 IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO, HM.SLMV_MERITO, HM.SLMV_PROMOCAO) UNION ALL SELECT HM.FUNC_REGISTRO_MOV, TO_CHAR (HM.SLMV_ESCALONADO_DT2, 'DD/MM/YYYY') SLMV_DATA, TO_CHAR (HM.SLMV_ESCALONADO_DELTA2, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento (Escalonado)' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito (Escalonado)' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção (Escalonado)' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'S' AND HM.SLMV_ESCALONADO_DT_FOLHA2 IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO, HM.SLMV_MERITO, HM.SLMV_PROMOCAO) UNION ALL SELECT HM.FUNC_REGISTRO_MOV, TO_CHAR (HM.SLMV_ESCALONADO_DT3, 'DD/MM/YYYY') SLMV_DATA, TO_CHAR (HM.SLMV_ESCALONADO_DELTA3, 'FM990D90') SLMV_SALARIO_DELTA_2, (CASE WHEN HM.SLMV_ENQUADRAMENTO = '1' THEN 'Enquadramento (Escalonado)' WHEN HM.SLMV_MERITO = '1' THEN 'Progressão por Mérito (Escalonado)' WHEN HM.SLMV_PROMOCAO = '1' THEN 'Promoção (Escalonado)' ELSE '-' END) TIPO FROM RESTRITO.SOLICITACAO_MOVIMENTACAO HM WHERE HM.FUNC_REGISTRO_MOV = '" + intRegistro.ToString() + "' AND HM.SLMV_HISTORICO_MOV = 0 AND HM.SLMV_ESCALONADO_FOLHA = 'S' AND HM.SLMV_ESCALONADO_DT_FOLHA3 IS NOT NULL AND '1' IN (HM.SLMV_ENQUADRAMENTO, HM.SLMV_MERITO, HM.SLMV_PROMOCAO)) ORDER BY TO_DATE(SLMV_DATA) DESC";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetHistoricoMovimentacaoSalarial

        #region GetFuncionarios
        public DataTable GetFuncionarios()
        {
            try
            {
                string strQuery = "SELECT FUNC_REGISTRO, FUNC_NOME, FUNC_NOME || ' - ' || FUNC_REGISTRO REGISTRO_NOME FROM RESTRITO.V_FUNCIONARIOS WHERE FUNC_ATIVO = 1 ORDER BY REGISTRO_NOME";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetFuncionarios

        #region GetFuncionariosEmpresa
        public DataTable GetFuncionariosEmpresa(string strEmpresa)
        {
            try
            {
                string strQuery = "SELECT FUNC_REGISTRO, FUNC_NOME, FUNC_NOME || ' - ' || FUNC_REGISTRO REGISTRO_NOME FROM RESTRITO.V_FUNCIONARIOS WHERE FUNC_ATIVO = 1 AND(UNIDADE = '" + strEmpresa.ToString() + "' OR '" + strEmpresa.ToString() + "' IS NULL) ORDER BY REGISTRO_NOME";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetFuncionariosEmpresa

        #region ValGestorFuncionario
        public DataTable ValGestorFuncionario(string strRegGestor, string strRegFuncionario)
        {
            try
            {
                string strQuery = "SELECT * FROM DUAL WHERE RESTRITO.F_VAL_GESTOR(" + strRegFuncionario.ToString() + "," + strRegGestor.ToString() + ") = '1'";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion ValGestorFuncionario

        #region ValGestorFuncionarioSub
        public DataTable ValGestorFuncionarioSub(string strRegGestor, string strRegFuncionario)
        {
            try
            {
                string strQuery = "SELECT * FROM DUAL WHERE RESTRITO.F_VAL_GESTOR_SUB(" + strRegFuncionario.ToString() + "," + strRegGestor.ToString() + ") = '1'";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion ValGestorFuncionarioSub

        #region GetFuncionariosByEmpresaFilialCcGestor
        public DataTable GetFuncionariosByEmpresaFilialCcGestor(string strPerfilAcesso, string strEmpresa, string strFilial, string strCC)
        {
            try
            {
                string strFiltroUsuario = "";

                //Se usuário for perfil Administrador poderá ver todas as solicitações do sistema:
                if (strPerfilAcesso.ToString().ToUpper() != "ADMINISTRADOR")
                {
                    strFiltroUsuario = "AND RESTRITO.F_VAL_GESTOR(V.FUNC_REGISTRO,'" + Usuario.ToString() + "') = '1' ";
                }

                string strQuery = "SELECT V.*, V.FUNC_GESTOR || ' - ' || V.FUNC_GESTOR_NOME FUNC_GESTOR_IMEDIATO FROM RESTRITO.V_FUNCIONARIOS V WHERE V.UNIDADE = '" + strEmpresa.ToString() + "' AND V.FUNC_FILIAL = '" + strFilial.ToString() + "' AND V.FUNC_CC = '" + strCC.ToString() + "' " + strFiltroUsuario + " ORDER BY V.FUNC_NOME";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetFuncionariosByEmpresaFilialCcGestor
    }
}