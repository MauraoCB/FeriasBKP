﻿namespace MasterSbsa.Dal
{
    public class Enums
    {
        public enum Bancos
        {
            TelematTecon,
            TelematImbituba,
            TelematLogistica,
            TelematConvicon,
            TelematTeconDW,
            SgtapTecon,
            SgtapImbituba,
            SgtapLogistica,
            SgtapConvicon,
            CtisTecon,
            CtisImbituba,
            CtisLogistica,
            CtisConvicon,
            CtisNovelis,
            CtisSaboo2,
            CtisSaboo,
            FatuTecon,
            FatuImbituba,
            FatuLogistica,
            FatuConvicon,
            ProdAlcis
        }
    }
}