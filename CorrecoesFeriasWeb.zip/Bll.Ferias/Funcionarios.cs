﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace Pier.Web.Bll.Ferias
{
    public class Funcionarios : Dao.Ferias.Funcionarios, IDisposable
    {
        #region Construtor
        public Funcionarios(string Usuario) : base(Usuario) { }
        #endregion Construtor

        #region Dispose
        public new void Dispose()
        {
            GC.SuppressFinalize(this);
        }
        #endregion Dispose

        #region GetVariaveisFuncionariosPorRegistro
        public new DataTable GetVariaveisFuncionariosPorRegistro(string strRegistro)
        {
            try
            {
                return base.GetVariaveisFuncionariosPorRegistro(strRegistro);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetVariaveisFuncionariosPorRegistro

        #region GetFuncionario
        public new DataTable GetFuncionario(string Ambiente, int intRegistro)
        {
            try
            {
                return base.GetFuncionario(Ambiente, intRegistro);
            }
            catch
            {
                return null;
            }
        }

        public new DataTable GetFuncionario(string Ambiente, string strNome)
        {
            try
            {
                return base.GetFuncionario(Ambiente, strNome);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetFuncionario

        #region GetFuncionarioSub
        public new DataTable GetFuncionarioSub(string Ambiente, int intRegistro)
        {
            try
            {
                return base.GetFuncionarioSub(Ambiente, intRegistro);
            }
            catch
            {
                return null;
            }
        }

        public new DataTable GetFuncionarioSub(string Ambiente, string strNome)
        {
            try
            {
                return base.GetFuncionarioSub(Ambiente, strNome);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetFuncionarioSub

        #region GetFuncionarioAll
        public new DataTable GetFuncionarioAll(string Ambiente, int intRegistro)
        {
            try
            {
                return base.GetFuncionarioAll(Ambiente, intRegistro);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetFuncionarioAll

        #region GetFuncionarioAcesso
        public new DataTable GetFuncionarioAcesso(int intRegistro)
        {
            try
            {
                return base.GetFuncionarioAcesso(intRegistro);
            }
            catch
            {
                return null;
            }
        }

        public new DataTable GetFuncionarioAcesso(string strNome)
        {
            try
            {
                return base.GetFuncionarioAcesso(strNome);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetFuncionarioAcesso

        #region GetMaxDataMovimentacaoSalarial
        public new DataTable GetMaxDataMovimentacaoSalarial(int intRegistro)
        {
            try
            {
                return base.GetMaxDataMovimentacaoSalarial(intRegistro);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetMaxDataMovimentacaoSalarial

        #region GetHistoricoMovimentacaoSalarial
        public new DataTable GetHistoricoMovimentacaoSalarial(int intRegistro)
        {
            try
            {
                return base.GetHistoricoMovimentacaoSalarial(intRegistro);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetHistoricoMovimentacaoSalarial

        #region GetFuncionarios
        public new DataTable GetFuncionarios()
        {
            try
            {
                return base.GetFuncionarios();
            }
            catch
            {
                return null;
            }
        }
        #endregion GetFuncionarios

        #region GetFuncionariosEmpresa
        public new DataTable GetFuncionariosEmpresa(string strEmpresa)
        {
            try
            {
                return base.GetFuncionariosEmpresa(strEmpresa);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetFuncionariosEmpresa

        #region ValGestorFuncionario
        public new DataTable ValGestorFuncionario(string strRegGestor, string strRegFuncionario)
        {
            try
            {
                return base.ValGestorFuncionario(strRegGestor, strRegFuncionario);
            }
            catch
            {
                return null;
            }
        }
        #endregion ValGestorFuncionario

        #region ValGestorFuncionarioSub
        public new DataTable ValGestorFuncionarioSub(string strRegGestor, string strRegFuncionario)
        {
            try
            {
                return base.ValGestorFuncionarioSub(strRegGestor, strRegFuncionario);
            }
            catch
            {
                return null;
            }
        }
        #endregion ValGestorFuncionarioSub

        #region GetFuncionariosByEmpresaFilialCcGestor
        public new DataTable GetFuncionariosByEmpresaFilialCcGestor(string strPerfilAcesso, string strEmpresa, string strFilial, string strCC)
        {
            try
            {
                return base.GetFuncionariosByEmpresaFilialCcGestor(strPerfilAcesso, strEmpresa, strFilial, strCC);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetFuncionariosByEmpresaFilialCcGestor

    }
}