﻿using FeriasWeb.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI.WebControls;

namespace Ferias.Web.Dao.Ferias
{
    public class Funcionario : System.Web.UI.Page
    {
        #region Variables
        private string uri = System.Configuration.ConfigurationManager.AppSettings["UrlFeriasAPI"];
        #endregion

        public List<FuncionarioModel> GetFuncionarios(int gestor)
        {
            if (Session["Funcionarios"] != null)
            {
                return (List<FuncionarioModel>)Session["Funcionarios"];
            }
            string Metodo = string.Concat("Funcionario/GetFuncionariosByGestor/", gestor);
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;
            List<FuncionarioModel> result = new List<FuncionarioModel>();

            using (var client = new HttpClient())
            {

                using (var response = client.GetAsync(Url).GetAwaiter().GetResult())
                {
                    Retorno = response.IsSuccessStatusCode ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : response.ReasonPhrase.ToString();
                }
            }

            result = JsonConvert.DeserializeObject<List<FuncionarioModel>>(Retorno);
            Session["Funcionarios"] = result;

            return result;
        }

        public List<ListItem> GetCentroCusto()
        {
            var CentroCustoList = GetFuncionarios().Where(c => !String.IsNullOrEmpty(c.FUNC_CC_NOME)).OrderBy(c => c.FUNC_CC_NOME);

            List<ListItem> listRetorno = new List<ListItem>();
            listRetorno.Add(new ListItem { Value = "0", Text = "(Selecione)" });

            string ccAnterior = "";
            foreach (var item in CentroCustoList)
            {
                if (item.FUNC_CC_NOME.ToUpper().Trim() != ccAnterior)
                {
                    listRetorno.Add(new ListItem { Value = item.FUNC_CC_NOME.Trim(), Text = item.FUNC_CC_NOME.Trim() });
                }
                ccAnterior = item.FUNC_CC_NOME.ToUpper().Trim();
            }

            return listRetorno.OrderBy(l => l.Text).ToList();
        }

        public List<ListItem> GetCargos()
        {
            var CargosList = GetFuncionarios().GroupBy(c => new { Value = c.FUNC_COD_CARGO.ToString(), Text = c.FUNC_COD_CARGO }).Select(g => g.First()).ToList();

            List<ListItem> listRetorno = CargosList.Select(l => new ListItem { Value = l.FUNC_COD_CARGO.ToString(), Text = l.FUNC_CARGO }).ToList();
            listRetorno.Insert(0, new ListItem { Value = "0", Text = "(Selecione)" });

            return listRetorno.OrderBy(l => l.Text).ToList();
        }

        public List<ListItem> GetGestores()
        {
            if (Session["Gestores"] != null)
            {
                return (List<ListItem>)Session["Gestores"];
            }
            string Metodo = string.Concat("Funcionario/GetGestores/");
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;
            List<ListItem> result = new List<ListItem>();

            using (var client = new HttpClient())
            {

                using (var response = client.GetAsync(Url).GetAwaiter().GetResult())
                {
                    Retorno = response.IsSuccessStatusCode ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : response.ReasonPhrase.ToString();
                }
            }

            var gestores = JsonConvert.DeserializeObject<List<FuncionarioModel>>(Retorno);
            result = gestores.Select(l => new ListItem { Value = l.FUNC_REGISTRO.ToString(), Text = l.FUNC_NOME }).ToList();

            result.Insert(0, new ListItem { Value = "0", Text = "(Selecione)", Selected = true });

            Session["Gestores"] = result;

            return result;
        }

        public List<ListItem> GetEquipes()
        {
            if (Session["Equipes"] != null)
            {
                return (List<ListItem>)Session["Equipes"];
            }
            string Metodo = string.Concat("Funcionario/GetEquipes/");
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;
            List<ListItem> result = new List<ListItem>();

            using (var client = new HttpClient())
            {

                using (var response = client.GetAsync(Url).GetAwaiter().GetResult())
                {
                    Retorno = response.IsSuccessStatusCode ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : response.ReasonPhrase.ToString();
                }
            }

            foreach (var item in JsonConvert.DeserializeObject<List<string>>(Retorno))
            {
                result.Add(new ListItem { Value = item, Text = item });
            }

            Session["Equipes"] = result;

            return result;
        }
        public List<EquipeFuncionarioModel> GetEquipeFuncionarios()
        {
            if (Session["EquipeFuncionario"] != null)
            {
                return (List<EquipeFuncionarioModel>)Session["EquipeFuncionario"];
            }
            string Metodo = string.Concat("Funcionario/GetEquipeFuncionarios/");
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;
            List<EquipeFuncionarioModel> result = new List<EquipeFuncionarioModel>();

            using (var client = new HttpClient())
            {

                using (var response = client.GetAsync(Url).GetAwaiter().GetResult())
                {
                    Retorno = response.IsSuccessStatusCode ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : response.ReasonPhrase.ToString();
                }
            }

            result = JsonConvert.DeserializeObject<List<EquipeFuncionarioModel>>(Retorno);
            Session["EquipeFuncionario"] = result;

            return result;
        }
        public List<ListItem> GetAreas()
        {
            var AreasList = GetFuncionarios().GroupBy(a => new { Value = a.FUNC_AREA, Text = a.FUNC_AREA }).Select(g => g.First()).Where(a => a.FUNC_AREA != null).ToList();

            List<ListItem> listRetorno = AreasList.Select(l => new ListItem { Value = l.FUNC_AREA.ToString(), Text = l.FUNC_AREA }).ToList();
            listRetorno.Insert(0, new ListItem { Value = "0", Text = "(Selecione)" });

            return listRetorno.OrderBy(l => l.Text).ToList();
        }

        private List<FuncionarioModel> GetFuncionarios()
        {
            int gestor = 0;

            if (Session["GestorId"] != null)
            {
                gestor = (int)Session["GestorId"];
            }

            return GetFuncionarios(gestor);
        }
    }
}