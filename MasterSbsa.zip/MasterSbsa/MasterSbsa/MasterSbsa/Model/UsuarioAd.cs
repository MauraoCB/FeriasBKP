﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MasterSbsa.Model
{
    public class UsuarioAd
    {
        public String login { get; set; }
        public String nome { get; set; }
        public String cpf { get; set; }
        public String registro { get; set; }
    }
}