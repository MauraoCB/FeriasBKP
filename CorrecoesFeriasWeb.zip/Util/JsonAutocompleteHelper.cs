﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pier.Web.Util
{
    public class JsonAutocompleteHelper
    {
        public int total;
        public List<JsonRow> rows = new List<JsonRow>();
    }
    public class JsonRow
    {
        public string id;
        public string label;
        public string value;
    }
}