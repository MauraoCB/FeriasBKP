﻿using FeriasWeb.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Ferias.Web.Dao.Ferias
{
    public class PrevisaoFeriasDAO: System.Web.UI.Page
    {
        #region Variables
        private string uri = System.Configuration.ConfigurationManager.AppSettings["UrlFeriasAPI"];
        #endregion
        public List<DistribuicaoFeriasOperModel> GetDistribuicaoFerias()
        {
            if (Session["ListaDistribuicaoFerias"] != null)
            {
                return (List<DistribuicaoFeriasOperModel>)Session["ListaDistribuicaoFerias"];
            }

            string Metodo = "PrevisaoFerias/GetPrevisaoFerias/";
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;
            List<DistribuicaoFeriasOperModel> result = new List<DistribuicaoFeriasOperModel>();

            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(20);
                using (var response = client.GetAsync(Url).GetAwaiter().GetResult())
                {
                    Retorno = response.IsSuccessStatusCode ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : response.ReasonPhrase.ToString();
                }
            }

            result = JsonConvert.DeserializeObject<List<DistribuicaoFeriasOperModel>>(Retorno);
            Session["ListaDistribuicaoFerias"] = result;

            return result;
        }

        public async Task<string> SavePrevisaoFerias(List<DistribuicaoFeriasOperModel> model)
        {
            string Metodo = string.Concat("PrevisaoFerias/SavePrevisaoFerias");
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;

            string jsonDistribuicaoFerias = JsonConvert.SerializeObject(model);

            jsonDistribuicaoFerias = jsonDistribuicaoFerias.Replace("true", "1");
            jsonDistribuicaoFerias = jsonDistribuicaoFerias.Replace("false", "0");

            var httpContent = new StringContent(jsonDistribuicaoFerias, Encoding.UTF8, "application/json");

            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(20);
                using (var response = await client.PostAsync(Url, httpContent))
                {
                    Retorno = response.IsSuccessStatusCode ? await response.Content.ReadAsStringAsync() : response.ReasonPhrase.ToString();
                }
            }

            return Retorno;
        }

    }
}