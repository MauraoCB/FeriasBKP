﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Reflection;
using System.Text;
using FeriasWeb.Models;
using Ferias.Web.Dao.Ferias;
using System.Data;

namespace Pier.Web
{

	public partial class ControladorSelecaoFuncionarios : UserControl
	{
		public delegate void EventoSelecionouFuncionario(object source, EventArgs e);
		public event EventoSelecionouFuncionario AoSelecionarFuncionario;

		public FuncionarioModel FuncionarioSelecionado { get; set; }
		/// <summary>
		/// Define ou retorna o ID da previsão ou da programação de férias, de acordo com a respectiva tela/tabela
		/// </summary>
		public int IdPrevisaoProgramacao {
			get
			{
				if (Session["IdPrevisaoProgramacao"] != null)
				{
					return Convert.ToInt32(Session["IdPrevisaoProgramacao"]);
				}
				else
				{
					return 0;
				}
			}
			set { Session["IdPrevisaoProgramacao"] = value; }
		}

		public List<FuncionarioModel> Funcionarios
		{
			get
			{
				if (Session["Funcionarios"] != null)
				{
					return (List<FuncionarioModel>)Session["Funcionarios"];
				}
				else
				{
					return new List<FuncionarioModel>();
				}

			}
			set { Session["Funcionarios"] = value; }
		}

		public List<FuncionarioModel> Subordinados
		{
			get
			{
				if (Session["Subordinados"] != null)
				{
					return (List<FuncionarioModel>)Session["Subordinados"];
				}
				else
				{
					return new List<FuncionarioModel>();
				}

			}
			set { Session["Subordinados"] = value; }
		}

		public List<DistribuicaoFeriasOperModel> PrevisaoFerias
		{
			get
			{
				if (Session["PrevisaoFerias"] != null)
				{
					return (List<DistribuicaoFeriasOperModel>)Session["PrevisaoFerias"];
				}
				else
				{
					return new List<DistribuicaoFeriasOperModel>();
				}

			}
			set { Session["PrevisaoFerias"] = value; }
		}

		public List<ProgramacaoModel> ProgramacaoFerias
		{
			get
			{
				if (Session["ProgramacaoFerias"] != null)
				{
					return (List<ProgramacaoModel>)Session["ProgramacaoFerias"];
				}
				else
				{
					return new List<ProgramacaoModel>();
				}

			}
			set { Session["ProgramacaoFerias"] = value; }
		}
		// expose the event publicly
		public event EventHandler UserControlButtonClicked;

		// a method to raise the publicly exposed event
		private void OnUserControlButtonClick()
		{
			UserControlButtonClicked?.Invoke(this, EventArgs.Empty);
		}

		protected override void OnLoad(EventArgs e)
		{
		
			//	base.OnLoad(e);
		
			Funcionarios = new Funcionario().GetFuncionarios(Convert.ToInt32(Session["GestorId"]));
		
			if (Session["PrevisaoFerias"] == null && this.Page.GetType().Name == "previsaoferias_aspx")
			{
				Session["PrevisaoFerias"] = new PrevisaoFeriasDAO().GetDistribuicaoFerias();
			}

			if (Session["ProgramacaoFerias"] == null && this.Page.GetType().Name == "programacaoferias_aspx")
			{
				Session["ProgramacaoFerias"] = new ProgramacaoFeriasDAO().GetProgramacaoFerias();
				ProgramacaoFerias = (List<ProgramacaoModel>)Session["ProgramacaoFerias"];
			}

			if (!Page.IsPostBack)
			{
				_ = new TipoProgramacao().GetTipoProgramacao();

				string operacao = "" + Request.QueryString["Operacao"];

				if (this.Page.GetType().Name == "previsaoferias_aspx")
				{
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Chefia", DataField = "DFOP_NOME_CHEFIA" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Período Aquisitivo", DataField = "DFOP_PERIODO_AQUISITIVO" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Programação", DataField = "DFOP_PROGRAMACAO", DataFormatString = "{0:MM/yyyy}" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Data Limite", DataField = "DFOP_DATA_LIMITE", DataFormatString = "{0:dd/MM/yyyy}" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Qtd. Dias", DataField = "DFOP_QTDE_DIAS" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Abono", DataField = "DFOP_ABONO" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "13º Salário", DataField = "DFOP_13" });
				}
				else
				{
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Chefia", DataField = "PGFR_NOME_CHEFIA" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Período Aquisitivo", DataField = "PGFR_PERIODO_AQUISITIVO" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Tipo de Programação", DataField = "TPPG_DESCRICAO" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Programação 1", DataField = "PGFR_PROGRAMACAO_1", DataFormatString = "{0:dd/MM/yyyy}" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Programação 2", DataField = "PGFR_PROGRAMACAO_2", DataFormatString = "{0:dd/MM/yyyy}" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Data Limite", DataField = "PGFR_DATA_LIMITE", DataFormatString = "{0:dd/MM/yyyy}" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "13º Salário", DataField = "PGFR_13", ItemStyle = { HorizontalAlign = HorizontalAlign.Center } });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Status", DataField = "PGFR_STATUS" , ItemStyle = { HorizontalAlign = HorizontalAlign.Center } });
					GridFuncionarios.Columns.Add(new CheckBoxField() { HeaderText = "Aprovar", DataField = "PGFR_AUTORIZADO", ReadOnly = false, Visible = operacao == "APROVAR" });

					GridFuncionarios.DataKeyNames = new string[] { "FUNC_ID","ID_PREVISAO_PROGRAMACAO", "PGFR_MOTIVO_STATUS", "PGFR_CAMPOS_ALTERADOS", "FUNC_REGISTRO" };
				}
				CarregarGrid(Funcionarios);
			}
		}

		protected void GridFuncionarios_SelectedIndexChanged(object sender, EventArgs e)
        {
            SelecionarFuncionario(GridFuncionarios);
        }

        protected void GridSubordinados_SelectedIndexChanged(object sender, EventArgs e)
        {
			SelecionarFuncionario((GridView)sender);
        }

		protected void GridSubordinados_RowDataBound(object sender, GridViewRowEventArgs e) {
			GridView gridSubordinados = sender as GridView;
			var dataSource = (dynamic)gridSubordinados.DataSource;

			string indiceImg = gridSubordinados.ID.Substring(8, 1);
		
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				for (int i = 0; i < e.Row.Cells.Count; i++)
				{
					if (i == 1)
					{
						//Chefia
						e.Row.Cells[i].Controls[1].Visible = EhFuncionarioGestor(Convert.ToInt32(dataSource[e.Row.RowIndex].FUNC_REGISTRO)); // "D;C;G;L;S".Contains(dataSource[e.Row.RowIndex].FUNC_POSICAO);
					}
					if (e.Row.Cells[i].Text.Contains("01/0001"))
					{
						e.Row.Cells[i].Text = "";
					}					
					if (this.Page.GetType().Name == "programacaoferias_aspx")
					{
						if (e.Row.Cells[11].Text == "Aprovado")
						{
							e.Row.Cells[11].ForeColor = System.Drawing.Color.Green;
						}
						else if (Server.HtmlDecode(e.Row.Cells[10].Text) == "Não Aprovado")
						{
							e.Row.Cells[11].ForeColor = System.Drawing.Color.Red;
							e.Row.Cells[11].Attributes.Add("title", String.Format("{0}", gridSubordinados.DataKeys[e.Row.RowIndex].Values[2]));
						}
						else
						{
							e.Row.Cells[11].Attributes.Add("title", String.Format("{0}", gridSubordinados.DataKeys[e.Row.RowIndex].Values[3]));
						}
						
					}
				}
			}
		}
		protected virtual void onSelecionouFuncionario()
		{

		}

		public void OnSelecionarFuncionario(object source, EventArgs e)
		{

		}
		protected void ddlCarregaConsulta_SelectedIndexChanged(object sender, EventArgs e)
		{
			txtRegistroNome.Text = "";
			txtRegistroNome.Width = new Unit(120, UnitType.Pixel);
			ddlParametroConsulta.Visible = ddlCarregaConsulta.SelectedIndex > 2;
			pnlProcurar.Visible = "1;2".Contains(ddlCarregaConsulta.SelectedValue);
			pnlUnidades.Visible = false;
			txtCentroCusto.Visible = ddlCarregaConsulta.SelectedValue == "3";
			if (ddlCarregaConsulta.SelectedValue == "2")
			{
				txtRegistroNome.Width = new Unit(300, UnitType.Pixel);
			}

			switch (ddlCarregaConsulta.SelectedValue)
			{
				case "0":
					Funcionarios = new Funcionario().GetFuncionarios(Convert.ToInt32(Session["GestorId"]));
					ProgramacaoFerias = new ProgramacaoFeriasDAO().GetProgramacaoFerias();
					CarregarGrid(Funcionarios);
					break;
				case "3":
					ddlParametroConsulta.DataSource = new Funcionario().GetCentroCusto();
					break;
				case "4":
					ddlParametroConsulta.DataSource = new Funcionario().GetCargos();
					break;
				case "5":
					ddlParametroConsulta.DataSource = new Funcionario().GetEquipes();
					break;					
				case "6":
					CarregarEmpresas();					
					break;
				default:
					return;
			}
			ddlParametroConsulta.DataBind();
		}

		protected void ddlParametroConsulta_SelectedIndexChanged(object sender, EventArgs e)
		{
			switch (ddlCarregaConsulta.SelectedValue)
			{				
				case "3":
					txtCentroCusto.Text = ddlParametroConsulta.SelectedValue;
					BuscaPorCentroCusto();
					break;
				case "4":
					BuscaPorCargo();
					break;
				case "5":
					BuscaPorEquipe();
					break;
				case "6":
					CarregarUnidades();
					break;
				default:
					GridFuncionarios.DataSource = Funcionarios;
					GridFuncionarios.DataBind();
					break;
			}
		}

		private bool EhFuncionarioGestor(int matricula)
        {
           
			var gestores = new Funcionario().GetGestores();

			return gestores.Count(f=>f.Value == matricula.ToString()) > 0;
        }
        public void CarregarGrid(List<FuncionarioModel> funcionarios, GridView gridFuncionarios = null)
		{
            if (gridFuncionarios == null)
            {
				gridFuncionarios = GridFuncionarios;

			}
			///Guarda na seção o último resultado
			Session["FuncionariosUltimaBusca"] = funcionarios;

			if (this.Page.GetType().Name == "previsaoferias_aspx")
			{
				CarregarPrevisaoFerias(funcionarios);
			}
			else
            {
                if (Session["strPerfilAcesso"].ToString().ToUpper() != "ADMINISTRADOR DO RH")
                {
                    var delegacoes = new FeriasDelega().GetFeriasDelega(0).Where(d => d.FUNC_REGISTRO_DELEGADO == Convert.ToInt32(Session["strUsuaRegistro"]) && d.FRDL_ATIVO == true).ToList();

                    if (Session["strPerfilAcesso"].ToString().ToUpper().Contains("DELEGA"))
                    {
                        if (delegacoes.Count == 0)
                        {
                            Util.Alert.Show(this.Page, "Não há delegações ativas para " + Session["strNomeUsuario"].ToString(), "error", "Funcionário Delegado");
                            return;
                        }
                    }
                    var funcionariosDelegacoes = GetDelegacoes(delegacoes);

                    //Se for funcionário delegado considerar só as suas delegações
                    if (Session["strPerfilAcesso"].ToString().ToUpper().Contains("DELEGA"))
                    {
                        funcionarios = funcionariosDelegacoes;
                    }
                    else
                    {
                        foreach (var item in funcionariosDelegacoes)
                        {
                            funcionarios.Add(item);
                        }
                    } 
                }
                CarregarProgramacaoFerias(funcionarios, gridFuncionarios);
            }

            if (GridFuncionarios.Rows.Count == 0)
            {
				string titulo = "";
                if (ddlParametroConsulta.SelectedIndex > 0)
                {
					titulo = ddlParametroConsulta.SelectedItem.Text;
                }
				Util.Alert.Show(this.Page, "Sem dados para o filtro selecionado. Por favor verifique se a leitura da planilha foi executada", "info", titulo);
			}
		}


		private void SelecionarFuncionario(GridView gridFuncionarios)
		{
			var funcId = gridFuncionarios.DataKeys[gridFuncionarios.SelectedIndex].Values[0].ToString();

			IdPrevisaoProgramacao = (int)gridFuncionarios.DataKeys[gridFuncionarios.SelectedIndex].Values[1];

            if (gridFuncionarios.ID == "GridFuncionarios")
            {
                FuncionarioSelecionado = Funcionarios.Where(f => f.FUNC_ID.ToString() == funcId).FirstOrDefault();
            }
            else
            {
				FuncionarioSelecionado  = Subordinados.Where(f => f.FUNC_ID.ToString() == funcId).FirstOrDefault();
			}

			// AoSelecionarFuncionario = new EventoSelecionouFuncionario(OnSelecionarFuncionario);;
			//AoSelecionarFuncionario.Invoke(sender, e);

			//Gambiarra dos infernos porque a porra do evento não foi acionado
			if (this.Page.GetType().Name == "previsaoferias_aspx")
			{
				((PrevisaoFerias)this.Page).OcultarSelecaoFuncionario();
			}
			else
			{
				((ProgramacaoFerias)this.Page).OcultarSelecaoFuncionario();
			}

			//OnUserControlButtonClick();
		}
		private List<FuncionarioModel> GetDelegacoes(List<FeriasDelegaModel> delegacoes)
        {
            Session["Funcionarios"] = null;

			List<FuncionarioModel> funcionarios = new Funcionario().GetFuncionarios(0);

			   var funcionariosRetorno	= (from func in funcionarios
                    join d in delegacoes on func.FUNC_REGISTRO equals d.FUNC_REGISTRO_FILHO.ToString()
                    select func).Distinct().ToList();

			return funcionariosRetorno;

		}
		#region Métdos privados
		private void CarregarSubordinados(GridView gridSubordinados, int gestorId)
		{
			gridSubordinados.Columns.Add(new BoundField() { HeaderText = "Registro", DataField = "FUNC_REGISTRO", ItemStyle = { HorizontalAlign = HorizontalAlign.Center } });
			gridSubordinados.Columns.Add(new BoundField() { HeaderText = "Nome", DataField = "FUNC_NOME" });
			gridSubordinados.Columns.Add(new BoundField() { HeaderText = "Cargo", DataField = "FUNC_CARGO" });
			gridSubordinados.Columns.Add(new BoundField() { HeaderText = "Período Aquisitivo", DataField = "PGFR_PERIODO_AQUISITIVO" });
			gridSubordinados.Columns.Add(new BoundField() { HeaderText = "Tipo de Programação", DataField = "TPPG_DESCRICAO" });
			gridSubordinados.Columns.Add(new BoundField() { HeaderText = "Programação 1", DataField = "PGFR_PROGRAMACAO_1", DataFormatString = "{0:dd/MM/yyyy}" });
			gridSubordinados.Columns.Add(new BoundField() { HeaderText = "Programação 2", DataField = "PGFR_PROGRAMACAO_2", DataFormatString = "{0:dd/MM/yyyy}" });
			gridSubordinados.Columns.Add(new BoundField() { HeaderText = "Data Limite", DataField = "PGFR_DATA_LIMITE", DataFormatString = "{0:dd/MM/yyyy}" });
			gridSubordinados.Columns.Add(new BoundField() { HeaderText = "13º Salário", DataField = "PGFR_13", ItemStyle = { HorizontalAlign = HorizontalAlign.Center } });
			gridSubordinados.Columns.Add(new BoundField() { HeaderText = "Status", DataField = "PGFR_STATUS", ItemStyle = { HorizontalAlign = HorizontalAlign.Center } });

			gridSubordinados.DataKeyNames = new string[] { "FUNC_ID", "ID_PREVISAO_PROGRAMACAO", "PGFR_MOTIVO_STATUS", "PGFR_CAMPOS_ALTERADOS", "FUNC_REGISTRO" };
			
			gridSubordinados.AlternatingRowStyle.BackColor = System.Drawing.Color.White;
			gridSubordinados.AlternatingRowStyle.ForeColor = GridFuncionarios.AlternatingRowStyle.ForeColor;
			gridSubordinados.HeaderStyle.BackColor = GridFuncionarios.HeaderStyle.BackColor;
			gridSubordinados.HeaderStyle.ForeColor = GridFuncionarios.HeaderStyle.ForeColor;
			gridSubordinados.GridLines = GridLines.None;
			gridSubordinados.BackColor = System.Drawing.Color.LightGray;

			List<FuncionarioModel> subordinados = new List<FuncionarioModel>();


			if (Session[$"Subordinados_{gestorId}"] == null)
            {
                 subordinados = new Funcionario().GetFuncionarios(gestorId);
				 Session[$"Subordinados_{gestorId}"] = subordinados;
            }
            else
            {
				subordinados = (List<FuncionarioModel>)Session[$"Subordinados_{gestorId}"];

			}
			Subordinados = subordinados;
			CarregarGrid(subordinados, gridSubordinados);
		}
		private void BuscaPorCentroCusto()
		{
			var funcionariosCentroCusto = Funcionarios.Where(f => f.FUNC_CC.ToString()  == ddlParametroConsulta.SelectedValue).ToList();
			//ProgramacaoFerias = new ProgramacaoFeriasDAO().GetProgramacaoFerias().Where(p => p.PGFR_CODIGO_CENTRO_RESULTADO.ToString() == ddlParametroConsulta.SelectedValue).ToList();
			CarregarGrid(funcionariosCentroCusto);
		}

		private void CarregarEmpresas()
		{
			var empresas = new EmpresaFilialDAO().GetEmpresas().GroupBy(e=> new { Vaue = e.EMPR_ID.ToString(), Text = e.EMPR_DESC }).Select(g=> g.First()).ToList();

			List<ListItem> listEmpresas = empresas.Select(l => new ListItem { Value = l.EMPR_ID.ToString(), Text = l.EMPR_DESC }).ToList();
			listEmpresas.Insert(0, new ListItem { Value = "0", Text = "(Selecione)" });

			ddlParametroConsulta.DataSource = listEmpresas;
		}

		private void CarregarUnidades()
        {
			var  listUnidades = new EmpresaFilialDAO().GetUnidades(int.Parse(ddlParametroConsulta.SelectedValue));
            //	ddlUnidades.DataSource = listUnidades;
            foreach (var item in listUnidades)
            {
				ddlUnidades.Items.Add(new ListItem { Value = item.Value, Text = item.Text });
            }
			pnlUnidades.Visible = true;
        }
		private void BuscaPorUnidade()
		{
			var funcionariosUnidade = Funcionarios.Where(f => f.FUNC_FILIAL.ToString() == ddlUnidades.SelectedValue).ToList();

			CarregarGrid(funcionariosUnidade);
		}

		private void BuscaPorCargo()
		{
			var funcionariosCargo = Funcionarios.Where(f => f.FUNC_COD_CARGO.ToString() == ddlParametroConsulta.SelectedValue).ToList();
			
			CarregarGrid(funcionariosCargo);
		}
		private void BuscaPorEquipe()
		{
			var funcionariosEquipe = new Funcionario().GetEquipeFuncionarios().Where(e => e.Descricao == ddlParametroConsulta.SelectedValue).ToList();

			if (funcionariosEquipe.Count == 0)
			{
			 Util.Alert.Show(this.Page, "Nenhum funcionário nesta equipe", "info", "");
				return;
			}

			var funcionariosFiltrados =
			(from func in Funcionarios
			 join eq in funcionariosEquipe on func.FUNC_ID equals eq.FUNC_ID
			 select func).Distinct().ToList();

			if (funcionariosFiltrados.Count == 0)
			{
				Util.Alert.Show(this.Page, "Nenhum funcionário nesta equipe", "info", "");
				return;
			}

			CarregarGrid(funcionariosFiltrados);
		}

		private void CarregarPrevisaoFerias(List<FuncionarioModel> funcionariosFiltrados)
		{
			var previsoes =
			(from func in funcionariosFiltrados
			 join prev in PrevisaoFerias on func.FUNC_REGISTRO equals prev.DFOP_MATRICULA.ToString()
			 select new
			 {
				 func.FUNC_ID,
				 ID_PREVISAO_PROGRAMACAO = prev.DFOP_ID,
				 func.FUNC_REGISTRO,
				 func.FUNC_NOME,
				 func.FUNC_CARGO,
				 prev.DFOP_NOME_CHEFIA,
				 prev.DFOP_PERIODO_AQUISITIVO,
				 prev.DFOP_PROGRAMACAO,
				 prev.DFOP_DATA_LIMITE,
				 prev.DFOP_13,
				 prev.DFOP_QTDE_DIAS,
				 prev.DFOP_ABONO
			 }).Distinct().OrderBy(f => f.FUNC_NOME).ToList();

			GridFuncionarios.DataSource = previsoes;
			GridFuncionarios.DataBind();
		}

		private void CarregarProgramacaoFerias(List<FuncionarioModel> funcionariosFiltrados, GridView gridFuncionarios)
		{			           
			ProgramacaoFerias = new ProgramacaoFeriasDAO().GetProgramacaoFerias();			

			string[] opcao13Salario = "Não;1º Período;2º Período;1º e 2º Períodos".Split(';');

			var programacoes =
			(from func in funcionariosFiltrados
			 join prog in ProgramacaoFerias on func.FUNC_REGISTRO equals prog.PGFR_MATRICULA.ToString()
			 select new
			 {
				 func.FUNC_ID,
				 ID_PREVISAO_PROGRAMACAO = prog.PGFR_ID,
				 func.FUNC_REGISTRO,
				 func.FUNC_NOME,
				 func.FUNC_CARGO,
				 func.FUNC_POSICAO,
				 prog.PGFR_NOME_CHEFIA,
				 prog.PGFR_PERIODO_AQUISITIVO,
				 prog.PGFR_PROGRAMACAO_1,
				 prog.PGFR_PROGRAMACAO_2,
				 prog.PGFR_DATA_LIMITE,
				 prog.PGFR_AUTORIZADO,
				 TPPG_DESCRICAO = new TipoProgramacao().GetDescricaoTipoProgramacao(prog.TPPG_ID),
				 PGFR_13 = opcao13Salario[prog.PGFR_13],
				 prog.PGFR_ABONO,
				 prog.PGFR_DT_LANC_PERIODO,
				 prog.PGFR_STATUS,
				 prog.PGFR_MOTIVO_STATUS,
				 prog.PGFR_CAMPOS_ALTERADOS
			 }).Distinct().OrderBy(f => f.FUNC_REGISTRO + f.PGFR_STATUS).ToList();


			string operacao = "" + Request.QueryString["Operacao"];

            if (operacao == "APROVAR")
            {
                if (Session["strPerfilAcesso"].ToString().ToUpper() == "GESTOR")
                {
                    programacoes = programacoes.Where(p => p.PGFR_DT_LANC_PERIODO != DateTime.MinValue && p.PGFR_MOTIVO_STATUS != "Aprovação Pendente RH").ToList();
                }
                else
                {
					programacoes = programacoes.Where(p => p.PGFR_DT_LANC_PERIODO != DateTime.MinValue).ToList();
				}

				programacoes = programacoes.OrderByDescending(f => f.PGFR_STATUS + f.FUNC_NOME).ToList();
			}

			gridFuncionarios.DataSource = programacoes;
			gridFuncionarios.DataBind();

			pnlAprovar.Visible = (operacao == "APROVAR" && programacoes.Count > 0);
		}

		#endregion

		protected void btnProcurar_Click(object sender, ImageClickEventArgs e)
		{
			List<FuncionarioModel> funcionarios = new List<FuncionarioModel>();
			if (ddlCarregaConsulta.SelectedValue == "1")
			{
				funcionarios = Funcionarios.Where(f => f.FUNC_REGISTRO == txtRegistroNome.Text).ToList();
			//	ProgramacaoFerias = new ProgramacaoFeriasDAO().GetProgramacaoFerias().Where(p => p.PGFR_MATRICULA.ToString() == txtRegistroNome.Text).ToList();
			}
			else
			{
				funcionarios = Funcionarios.Where(f => f.FUNC_NOME.ToUpper().Contains(txtRegistroNome.Text.ToUpper())).ToList();
			//	ProgramacaoFerias = new ProgramacaoFeriasDAO().GetProgramacaoFerias().Where(p => p.PGFR_NOME == txtRegistroNome.Text).ToList();
			}
			if (funcionarios.Count() == 0)
			{
				Util.Alert.Show(this.Page, "Funcionário não encontrado", "error", ddlCarregaConsulta.SelectedItem.Text);
				return;
			}
			CarregarGrid(funcionarios);
		}

		protected void GridFuncionarios_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			bool aprovadorSN = "" + Request.QueryString["Operacao"] == "APROVAR";
			var dataSource = (dynamic)GridFuncionarios.DataSource;
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				for (int i = 0; i < e.Row.Cells.Count; i++)
				{
                    if (i==1)
                    {
						//Chefia
						e.Row.Cells[i].FindControl("imgNivel1Show").Visible = EhFuncionarioGestor( Convert.ToInt32(dataSource[e.Row.RowIndex].FUNC_REGISTRO)); // "D;C;G;L;S".Contains(dataSource[e.Row.RowIndex].FUNC_POSICAO);

					}
					if (e.Row.Cells[i].Text.Contains("01/0001"))
					{
						e.Row.Cells[i].Text = "";
					}
					if (this.Page.GetType().Name == "previsaoferias_aspx" && i == 10)
					{
						e.Row.Cells[i].Text = "Não";

						if (e.Row.Cells[i].Text.ToLower() == "true")
						{
							e.Row.Cells[i].Text = "Sim";
						}
					}
					if (this.Page.GetType().Name == "programacaoferias_aspx")
					{
						if (e.Row.Cells[12].Text == "Aprovado")
						{
							e.Row.Cells[12].ForeColor = System.Drawing.Color.Green;
						}
						else if (Server.HtmlDecode(e.Row.Cells[11].Text) == "Não Aprovado")
						{
							e.Row.Cells[12].ForeColor = System.Drawing.Color.Red;
							e.Row.Cells[12].Attributes.Add("title", String.Format("{0}", GridFuncionarios.DataKeys[e.Row.RowIndex].Values[2]));
						}
						else
						{
							e.Row.Cells[12].Attributes.Add("title", String.Format("{0}", GridFuncionarios.DataKeys[e.Row.RowIndex].Values[3]));
						}
						
						((CheckBox)e.Row.Cells[13].Controls[0]).Enabled = aprovadorSN;
						((CheckBox)e.Row.Cells[13].Controls[0]).Checked = dataSource[e.Row.RowIndex].PGFR_AUTORIZADO;

						if (Session["strPerfilAcesso"].ToString().ToUpper() == "ADMINISTRADOR DO RH")
						{
							((CheckBox)e.Row.Cells[13].Controls[0]).Enabled = e.Row.Cells[12].Text != "Aprovação Pendente Gestor";

						}
					}
				}
			}
		}
		protected void ShowHideGridSubordinados(object sender, EventArgs e)
		{
			ImageButton imgShowHide = (sender as ImageButton);
			GridViewRow row = (imgShowHide.NamingContainer as GridViewRow);

			GridView gridPai = row.NamingContainer as GridView;
			
			string gridSubordinadosId = "griNivel" + imgShowHide.CommandArgument.Split(';')[1];
			if (imgShowHide.CommandArgument.Split(';')[0] == "Show")
			{
				row.FindControl("pnlSubordinados").Visible = true;
				imgShowHide.CommandArgument = "Hide;" + imgShowHide.CommandArgument.Split(';')[1];
				imgShowHide.ImageUrl = "~/images/minus.png";
				int gestorId = Convert.ToInt32(gridPai.DataKeys[row.RowIndex].Values[4]);
				GridView gridSubordinados = row.FindControl(gridSubordinadosId) as GridView;

				((Label)gridPai.Rows[row.RowIndex].FindControl("lblGestor")).Text = "&nbsp;Chefia: " + gridPai.Rows[row.RowIndex].Cells[3].Text;
		
                CarregarSubordinados(gridSubordinados, gestorId);

			}
			else
			{
				row.FindControl("pnlSubordinados").Visible = false;
				imgShowHide.CommandArgument = "Show;" + imgShowHide.CommandArgument.Split(';')[1];
				imgShowHide.ImageUrl = "~/images/plus.png";
			}


			gridPai.Rows[row.RowIndex].Cells[0].Visible = !row.FindControl("pnlSubordinados").Visible;			

			for (int i = 2; i < gridPai.Rows[row.RowIndex].Cells.Count; i++)
			{
				gridPai.Rows[row.RowIndex].Cells[i].Visible = !row.FindControl("pnlSubordinados").Visible;
			}

		}

		protected void btnAprovar_Click(object sender, ImageClickEventArgs e)
		{
			string jsonAprovacoes = "[";
			for (int i = 0; i < GridFuncionarios.Rows.Count; i++)
			{
				string status = "Aprovado";
				string autorizado = "0";
				if (GridFuncionarios.Rows[i].RowType == DataControlRowType.DataRow)
				{
					if (((CheckBox)GridFuncionarios.Rows[i].Cells[13].Controls[0]).Checked)
					{
						autorizado = "1";
                    }
                    else
                    {
						continue;
                    }
				}

				if (Session["strPerfilAcesso"].ToString().ToUpper() == "GESTOR")
                {
					status = "Aprovação Pendente RH";
                }

				jsonAprovacoes += $"{{PGFR_ID: {GridFuncionarios.DataKeys[i].Values[1]}, Autorizado : {autorizado}, Status: '{status}', MotivoStatus: ''}},";
			}
			jsonAprovacoes = jsonAprovacoes.Remove(jsonAprovacoes.Length - 1) + "]";

			ProgramacaoFeriasDAO programacaoFeriasDAO = new ProgramacaoFeriasDAO();
			string[] retorno = programacaoFeriasDAO.AprovarProgramacoes(jsonAprovacoes).Result;

		    Util.Alert.Show(this.Page,  retorno[1] , retorno[0], "Aprovação");

			//Recarrega o gri de funcionários com última busca e a alteração da programação de férias
			Session["ProgramacaoFerias"] = null;

			CarregarGrid((List<FuncionarioModel>)Session["FuncionariosUltimaBusca"]);
		}

        protected void GridFuncionarios_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
			GridFuncionarios.PageIndex = e.NewPageIndex;
			CarregarGrid((List<FuncionarioModel>)Session["FuncionariosUltimaBusca"]);
        }

        protected void chkPaginarListagem_CheckedChanged(object sender, EventArgs e)
        {
			GridFuncionarios.AllowPaging = chkPaginarListagem.Checked;
			CarregarGrid((List<FuncionarioModel>)Session["FuncionariosUltimaBusca"]);
		}

		protected void btnSelecionarTodos_Click(object sender, EventArgs e)
		{
			for (int i = 0; i < GridFuncionarios.Rows.Count; i++)
			{
				if (GridFuncionarios.Rows[i].RowType == DataControlRowType.DataRow)
				{
					((CheckBox)GridFuncionarios.Rows[i].Cells[13].Controls[0]).Checked = btnSelecionarTodos.Text == "Selecionar Todos";
				}
			}

			btnSelecionarTodos.Text = "Selecionar Todos";
			if (btnSelecionarTodos.Text == "Selecionar Todos")
			{
				btnSelecionarTodos.Text = "Desmarcar Todos";
			}
		}

        protected void ddlUnidades_SelectedIndexChanged(object sender, EventArgs e)
        {
			BuscaPorUnidade();
        }

        protected void txtCentroCusto_TextChanged(object sender, EventArgs e)
        {
			ddlParametroConsulta.ClearSelection();
            try
            {
				int result = 0;

                if (int.TryParse(txtCentroCusto.Text, out result))
                {
                    ddlParametroConsulta.SelectedValue = txtCentroCusto.Text;
					ddlParametroConsulta_SelectedIndexChanged(null, null);
				}
                else
                {
                    for (int i = 0; i < ddlParametroConsulta.Items.Count; i++)
                    {
                        if (ddlParametroConsulta.Items[i].Text.ToUpper().Contains(txtCentroCusto.Text.ToUpper()))
                        {
							ddlParametroConsulta.SelectedValue = ddlParametroConsulta.Items[i].Value;
							ddlParametroConsulta_SelectedIndexChanged(null, null);
							return;
						}
                    }
                }
            }
            catch (Exception)
            {

                
            }
        }
    }
}