﻿namespace MasterSbsa
{
    public partial class VivaVozAppPostConfig : System.Web.UI.Page
    {
    }
}