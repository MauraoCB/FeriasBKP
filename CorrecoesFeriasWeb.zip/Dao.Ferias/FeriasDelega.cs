﻿using FeriasWeb.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Ferias.Web.Dao.Ferias
{
    public class FeriasDelega
    {
        #region Variables
        private string uri = System.Configuration.ConfigurationManager.AppSettings["UrlFeriasAPI"];
        #endregion

        public List<FeriasDelegaModel> GetFeriasDelega(int gestor)
        {
            string Metodo = string.Concat( "FeriasDelega/GetFeriasDelega/", gestor);
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;
            List<FeriasDelegaModel> result = new List<FeriasDelegaModel>();

            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(20);
                using (var response = client.GetAsync(Url).GetAwaiter().GetResult())
                {
                    Retorno = response.IsSuccessStatusCode ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : response.ReasonPhrase.ToString();

                    if (response.IsSuccessStatusCode)
                    {
                        result = JsonConvert.DeserializeObject<List<FeriasDelegaModel>>(Retorno);
                    }
                }
            }

            return result;
        }

        public async Task<string> SalvarDelegacoesLancamento(string jsonDelegacoesLancamento)
        {
            string Metodo = string.Concat("/FeriasDelega/SaveFeriasDelegaList");
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;            

            var httpContent = new StringContent(jsonDelegacoesLancamento, Encoding.UTF8, "application/json");

            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(20);
                using (var response = await client.PostAsync(Url, httpContent))
                {
                    Retorno = response.IsSuccessStatusCode ? await response.Content.ReadAsStringAsync() : response.ReasonPhrase.ToString();
                }
            }

            return Retorno;
        }

        public async Task<string> IncluirDelegacaoLancamento(List<FeriasDelegaModel> model)
        {
            string Metodo = string.Concat("/FeriasDelega/SaveFeriasDelegaList");
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;

            string jsonDelegacoesLancamento = JsonConvert.SerializeObject(model);

            jsonDelegacoesLancamento = jsonDelegacoesLancamento.Replace("true", "1");
            jsonDelegacoesLancamento = jsonDelegacoesLancamento.Replace("false", "0");

            var httpContent = new StringContent(jsonDelegacoesLancamento, Encoding.UTF8, "application/json");

            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(20);
                using (var response = await client.PostAsync(Url, httpContent))
                {
                    Retorno = response.IsSuccessStatusCode ? await response.Content.ReadAsStringAsync() : response.ReasonPhrase.ToString();
                }
            }

            return Retorno;
        }
    }
}