﻿namespace MasterSbsa
{
    public partial class VivaVozAppGetConfig : System.Web.UI.Page
    {
    }
}