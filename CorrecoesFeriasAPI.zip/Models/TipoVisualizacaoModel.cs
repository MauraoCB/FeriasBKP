﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FeriasAPI.Models
{
    public class TipoVisualizacaoModel
    {

        public int TPVZ_ID { get; set; }
        public string TPVZ_DESCRICAO { get; set; }
    }
}