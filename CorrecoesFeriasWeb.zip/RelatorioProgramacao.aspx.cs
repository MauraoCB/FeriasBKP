﻿using Ferias.Web.Dao.Ferias;
using FeriasWeb.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Pier.Web
{
    public partial class RelatorioProgramacao : System.Web.UI.Page
    {
		#region Properties
		public List<FuncionarioModel> Funcionarios
		{
			get
			{
				if (Session["Funcionarios"] != null)
				{
					return (List<FuncionarioModel>)Session["Funcionarios"];
				}
				else
				{
					return new List<FuncionarioModel>();
				}

			}
			set { Session["Funcionarios"] = value; }
		}
		public List<ProgramacaoModel> ProgramacaoFerias
		{
			get
			{
				if (Session["ProgramacaoFerias"] != null)
				{
					return (List<ProgramacaoModel>)Session["ProgramacaoFerias"];
				}
				else
				{
					return new List<ProgramacaoModel>();
				}

			}
			set { Session["ProgramacaoFerias"] = value; }
		}
		#endregion
		protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
				if (Session["Funcionarios"] == null)
				{
					Funcionarios = new Funcionario().GetFuncionarios(0);
				}

				if (Session["ProgramacaoFerias"] == null)
				{
					Session["ProgramacaoFerias"] = new ProgramacaoFeriasDAO().GetProgramacaoFerias();
				}
			}
		}
	
		protected void ddlCarregaConsulta_SelectedIndexChanged(object sender, EventArgs e)
		{
			txtRegistroNome.Text = "";
			txtRegistroNome.Width = new Unit(120, UnitType.Pixel);
			txtRegistroNome.Visible = ddlCarregaConsulta.SelectedIndex < 2;
			txtMesAno.Text = "";
			txtMesAno.Visible = ddlCarregaConsulta.SelectedValue == "2";
			ddlParametroConsulta.Visible = ddlCarregaConsulta.SelectedIndex > 2;
			pnlProcurar.Visible = ddlCarregaConsulta.SelectedIndex <= 2;

			if (ddlCarregaConsulta.SelectedValue == "1")
			{
				txtRegistroNome.Width = new Unit(300, UnitType.Pixel);
			}

			switch (ddlCarregaConsulta.SelectedValue)
			{
				case "3":
					ddlParametroConsulta.DataSource = new Funcionario().GetCentroCusto();
					break;
				case "4":
					ddlParametroConsulta.DataSource = new Funcionario().GetCargos();
					break;
				case "5":
					ddlParametroConsulta.DataSource = new Funcionario().GetAreas();
					break;
				case "6":
					ddlParametroConsulta.DataSource = new ProgramacaoFeriasDAO().GetEmpresas();
					break;
				default:
					return;
			}
			ddlParametroConsulta.DataBind();
		}

		protected void ddlParametroConsulta_SelectedIndexChanged(object sender, EventArgs e)
		{
			switch (ddlCarregaConsulta.SelectedValue)
			{
				case "3":
					BuscaPorCentroCusto();
					break;
				case "4":
					BuscaPorCargo();
					break;
				case "5":
					BuscaPorArea();
					break;
				case "6":
					BuscaPorEmpresa();
					break;
				default:
					GridFuncionarios.DataSource = Funcionarios;
					GridFuncionarios.DataBind();
					break;
			}
		}


		#region Métdos privados
		private void BuscaPorEmpresa()
		{
			var programacaoEmpresa = ProgramacaoFerias.Where(prog => prog.PGFR_CODIGO_EMPRESA.ToString() == ddlParametroConsulta.SelectedValue);

			var funcionarios =
			(from func in Funcionarios
			 join prog in programacaoEmpresa on func.FUNC_REGISTRO equals prog.PGFR_MATRICULA.ToString()
			 select func
			).ToList();

			CarregarGrid(funcionarios);
		}

		public void BuscaPorGestor(int gestor)
		{
			Funcionarios = new Funcionario().GetFuncionarios(gestor);
		}
		private List<FuncionarioModel> BuscaPorMesAno(List<FuncionarioModel> funcionarios)
		{
			var programacaoMesAno = ProgramacaoFerias.Where(prog => prog.PGFR_PROGRAMACAO_1.ToString("MM/yyyy") == txtMesAno.Text || prog.PGFR_PROGRAMACAO_2.ToString("MM/yyyy") == txtMesAno.Text);
			
			var funcionariosRetorno =
			(from func in funcionarios
			 join prog in programacaoMesAno on func.FUNC_REGISTRO equals prog.PGFR_MATRICULA.ToString()			  
			 select func
			).ToList();

			return funcionariosRetorno;
		}
		private void BuscaPorCentroCusto()
		{
			var funcionariosCentroCusto = Funcionarios.Where(f=> !String.IsNullOrEmpty(f.FUNC_CC_NOME)).Where(f => f.FUNC_CC_NOME.Trim().ToUpper() == ddlParametroConsulta.SelectedValue.Trim().ToUpper()).ToList();
			CarregarGrid(funcionariosCentroCusto);
		}

		private void BuscaPorCargo()
		{
			var funcionariosCargo = Funcionarios.Where(f => f.FUNC_COD_CARGO.ToString() == ddlParametroConsulta.SelectedValue).ToList();

			CarregarGrid(funcionariosCargo);
		}
		private void BuscaPorArea() {
			var funcionariosArea = Funcionarios.Where(f => f.FUNC_AREA == ddlParametroConsulta.SelectedValue).ToList();

			CarregarGrid(funcionariosArea);
		}
		private void CarregarGrid(List<FuncionarioModel> funcionariosFiltrados)
		{
			string[] opcao13Salario = "Não;1º Período;2º Período, 1º e 2º Período".Split(';');

			var tipoProgramacao = new TipoProgramacao().GetTipoProgramacao();
			var programacoes =
			(from func in funcionariosFiltrados
			 join prog in ProgramacaoFerias on func.FUNC_REGISTRO equals prog.PGFR_MATRICULA.ToString()
			 join tppg in tipoProgramacao on prog.TPPG_ID equals tppg.TPPG_ID
			 select new
			 {
				 func.FUNC_REGISTRO,
				 func.FUNC_NOME,
				 func.FUNC_CARGO,
				 prog.PGFR_ADMISSAO,
				 func.FUNC_CC,
				 func.FUNC_CC_NOME,
				 func.FUNC_AREA,
				 func.FUNC_GESTOR_NOME,
				 FUNC_EMPRESA = prog.PGFR_NOME_EMPRESA,
				 func.UNIDADE,
				 prog.PGFR_PERIODO_AQUISITIVO,
				 prog.PGFR_DATA_LIMITE,
				 tppg.TPPG_DESCRICAO,
				 prog.PGFR_PROGRAMACAO_1,
				 prog.PGFR_DIAS_1,
				 prog.PGFR_ABONO,
				 prog.PGFR_PROGRAMACAO_2,
				 prog.PGFR_DIAS_2,
				 PGFR_13 = opcao13Salario[prog.PGFR_13],
				 prog.PGFR_DT_LANC_PERIODO,
				 PGFR_AUTORIZADO = (prog.PGFR_AUTORIZADO == true ? "Autorizado" : ""),
			 }).OrderBy(f=> f.FUNC_NOME).ToList();

			GridFuncionarios.DataSource = programacoes;
			GridFuncionarios.DataBind();

			Session["ProgramacaoExportar"] = programacoes;
			Session["prefixoNome"] = "";
			if (ddlParametroConsulta.SelectedIndex > 0)
			{
				Session["prefixoNome"] = ddlParametroConsulta.SelectedItem.Text.Replace(" ", "_") +  "_";
			}
			
			pnlExportarExcel.Visible = programacoes.Count > 0;
		}
		#endregion
		protected void btnProcurar_Click(object sender, ImageClickEventArgs e)
		{
			List<FuncionarioModel> funcionarios = new List<FuncionarioModel>();
			
            switch (ddlCarregaConsulta.SelectedValue)
            {
				case "0":
					funcionarios = Funcionarios.Where(f => f.FUNC_REGISTRO == txtRegistroNome.Text).ToList();
					break;
				case "1":
					funcionarios = Funcionarios.Where(f => f.FUNC_NOME.ToUpper().Contains(txtRegistroNome.Text.ToUpper())).ToList();
					break;
				case "2":
					funcionarios = BuscaPorMesAno(funcionarios);
					break;
				default:
                    break;
            }
            if (funcionarios.Count() == 0)
			{
				Util.Alert.Show("Funcionário não encontrado");
				return;
			}
			CarregarGrid(funcionarios);
		}

        protected void GridFuncionarios_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			for (int i = 0; i < e.Row.Cells.Count; i++)
			{
				if (e.Row.RowType == DataControlRowType.DataRow)
				{
					if (e.Row.Cells[i].Text.Contains("01/0001"))
					{
						e.Row.Cells[i].Text = "";
					}					
				}
			}
		}
    }
}