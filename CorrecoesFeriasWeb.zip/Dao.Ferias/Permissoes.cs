﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Pier.Entity;
using Pier.Entity.Acesso;
using NHibernate;

namespace Pier.Web.Dao.Ferias
{
    public class Permissoes : ECRUD.Oracle
    {
        #region Properties
        public string Ambiente { get; private set; }
        public string Usuario { get; private set; }
        #endregion Properties

        #region Construtor
        public Permissoes(string Usuario)
        {
            Ambiente = System.Configuration.ConfigurationManager.AppSettings["Ambiente"].ToString();
            this.Usuario = Usuario;
        }
        #endregion Construtor

        #region GetPermissoes
        public DataTable GetPermissoes()
        {
            try
            {
                string strQuery = "SELECT DISTINCT VF.FUNC_ID, VF.FUNC_REGISTRO, VF.FUNC_NOME, VF.FUNC_CARGO, EF.EMFL_UNIDADE_DESCRICAO EMPRESA, RESTRITO.F_GET_PERFIL_ACESSO (10621, VF.FUNC_REGISTRO, 'ADMINISTRADOR DO RH') ADMINISTRADOR_DO_RH, RESTRITO.F_GET_PERFIL_ACESSO (10621, VF.FUNC_REGISTRO, 'GESTOR') GESTOR, RESTRITO.F_GET_PERFIL_ACESSO (10621, VF.FUNC_REGISTRO, 'FUNCIONÁRIO DELEGADO') FUNCIONARIO_DELEGADO, RESTRITO.F_GET_PERFIL_ACESSO (10621, VF.FUNC_REGISTRO, 'ESCALA') ESCALA FROM PIER.SISTEMA@CORP_LINK SI, PIER.PERFIL_ACESSO@CORP_LINK PA, PIER.ACESSO@CORP_LINK AC, PIER.USUARIO@CORP_LINK US, PIER.PESSOA@CORP_LINK PE, RESTRITO.V_FUNCIONARIOS VF, RESTRITO.EMPRESA_FILIAL EF WHERE SI.ID = 10621 AND PA.SISTEMA_ID = SI.ID AND PA.ATIVO = 1 AND AC.PERFIL_ACESSO_ID = PA.ID AND AC.ATIVO = 1 AND US.ID = AC.USUARIO_ID AND PE.PESSOA_ID = US.PESSOA AND VF.FUNC_REGISTRO = PE.FUNC_REGISTRO AND VF.FUNC_ATIVO = 1 AND EF.EMFL_UNIDADE = VF.UNIDADE";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetPermissoes(string strFuncRegistro, string strEmpresa)
        {
            try
            {
                string strQuery = "SELECT DISTINCT VF.FUNC_ID, VF.FUNC_REGISTRO, VF.FUNC_NOME, VF.FUNC_CARGO, EF.EMFL_UNIDADE_DESCRICAO EMPRESA, RESTRITO.F_GET_PERFIL_ACESSO (10621, VF.FUNC_REGISTRO, 'ADMINISTRADOR DO RH') ADMINISTRADOR_DO_RH, RESTRITO.F_GET_PERFIL_ACESSO (10621, VF.FUNC_REGISTRO, 'GESTOR') GESTOR, RESTRITO.F_GET_PERFIL_ACESSO (10621, VF.FUNC_REGISTRO, 'FUNCIONÁRIO DELEGADO') FUNCIONARIO_DELEGADO, RESTRITO.F_GET_PERFIL_ACESSO (10621, VF.FUNC_REGISTRO, 'ESCALA') ESCALA FROM RESTRITO.V_FUNCIONARIOS VF, RESTRITO.EMPRESA_FILIAL EF WHERE VF.FUNC_ATIVO = 1 AND EF.EMFL_UNIDADE = VF.UNIDADE AND EF.EMFL_ID_FILIAL = VF.FUNC_FILIAL AND (VF.UNIDADE = '" + strEmpresa.ToString() + "' OR '" + strEmpresa.ToString() + "' IS NULL) AND (VF.FUNC_REGISTRO = '" + strFuncRegistro.ToString() + "' OR '" + strFuncRegistro.ToString() + "' IS NULL) ";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetPermissoes

        #region GetEmpresas
        public DataTable GetEmpresas()
        {
            try
            {
                string strQuery = "SELECT DISTINCT EMFL_UNIDADE EMPRESA, EMFL_UNIDADE_DESCRICAO EMPRESA_EXIBICAO FROM RESTRITO.EMPRESA_FILIAL ORDER BY (2)";
                return GetDataTable(strQuery, Enums.Bancos.RestritoTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetEmpresas

        #region GetPaginaLogin
        public DataTable GetPaginaLogin(string strUsuaCPF, string strEndereco)
        {
            try
            {
                string strQuery = "SELECT * FROM PIER.V_PAGINAS_LOGIN_MASTER_SBSA WHERE LPAD(REGEXP_REPLACE(USUA_CPF,'[^0-9]',''),15,'0') = LPAD(REGEXP_REPLACE('" + strUsuaCPF.ToString() + "','[^0-9]',''),15,'0') AND AMBIENTE = '0' AND UPPER(ENDERECO) = '" + strEndereco.ToUpper() + "' AND SISTEMA_ID IN (10621)";
                return GetDataTable(strQuery, Enums.Bancos.SgtapTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetPaginaLogin

        #region GetTextoPrincipal
        public string GetTextoPrincipal()
        {
            try
            {
                string strQuery = "SELECT DESCR FROM INTERNET.NEWS WHERE NEWS_SUBJECT_ID = 16";
                DataTable dt = GetDataTable(strQuery, Enums.Bancos.CorpTecon);

                string retorno = "";

                if (dt != null && dt.Rows.Count > 0)
                {
                    retorno = dt.Rows[0]["DESCR"].ToString();
                }

                return retorno;
            }
            catch
            {
                return "";
            }
        }
        #endregion GetTextoPrincipal

        #region GetRegrasProcedimentos
        public string GetRegrasProcedimentos()
        {
            try
            {
                string strQuery = "SELECT DESCR FROM INTERNET.NEWS WHERE NEWS_SUBJECT_ID = 17";
                DataTable dt = GetDataTable(strQuery, Enums.Bancos.CorpTecon);

                string retorno = "";

                if (dt != null && dt.Rows.Count > 0)
                {
                    retorno = dt.Rows[0]["DESCR"].ToString();
                }

                return retorno;
            }
            catch
            {
                return "";
            }
        }
        #endregion GetRegrasProcedimentos

        #region GetAvisos
        public DataTable GetAvisos()
        {
            try
            {
                string strQuery = "SELECT ID, INSERT_DATE DATA_AVISO, TITLE TITULO_AVISO, DESCR TEXTO_AVISO, PUBLISH_DATE DATA_INATIVACAO FROM INTERNET.NEWS WHERE NEWS_SUBJECT_ID = 15";
                return GetDataTable(strQuery, Enums.Bancos.CorpTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion

        #region GravaAvisos
        public bool GravaAvisos(string tituloAvisdo, string textoAviso)
        {
            try
            {
                string strQuery = "INSERT INTO INTERNET.NEWS (INSERT_DATE, TITLE, DESCR, NEWS_SUBJECT_ID) VALUES (SYSDATE,'" + tituloAvisdo.ToString() + "','" + textoAviso.ToString() + "', 15)";
                return InsertUpdateDelete(strQuery, Enums.Bancos.CorpTecon);
            }
            catch
            {
                return false;
            }
        }
        #endregion GravaAvisos

        #region AtualizaAvisos
        public bool AtualizaAvisos(string tituloAvisdo, string textoAviso, long idAviso)
        {
            try
            {
                string strQuery = "UPDATE INTERNET.NEWS SET TITLE = '" + tituloAvisdo.ToString() + "', DESCR = '" + textoAviso.ToString() + "' WHERE ID = " + idAviso + " AND NEWS_SUBJECT_ID = 15";
                return InsertUpdateDelete(strQuery, Enums.Bancos.CorpTecon);
            }
            catch
            {
                return false;
            }
        }
        #endregion AtualizaAvisos

        #region InativaAtivaAvisos
        public bool InativaAtivaAvisos(long idAviso, string dataInativacao)
        {
            try
            {
                string strQuery = "";
                if (dataInativacao == "" || dataInativacao == "&nbsp;")
                {
                    strQuery = "UPDATE INTERNET.NEWS SET PUBLISH_DATE = SYSDATE WHERE ID = " + idAviso + " AND NEWS_SUBJECT_ID = 15";
                }
                else
                {
                    strQuery = "UPDATE INTERNET.NEWS SET PUBLISH_DATE = '' WHERE ID = " + idAviso + " AND NEWS_SUBJECT_ID = 15";
                }
                
                return InsertUpdateDelete(strQuery, Enums.Bancos.CorpTecon);
            }
            catch
            {
                return false;
            }
        }
        #endregion InativaAtivaAvisos

        #region ExcluiAvisos
        public bool ExcluiAvisos(long idAviso)
        {
            try
            {
                string strQuery = "DELETE INTERNET.NEWS WHERE ID = " + idAviso + " AND NEWS_SUBJECT_ID = 15";                

                return InsertUpdateDelete(strQuery, Enums.Bancos.CorpTecon);
            }
            catch
            {
                return false;
            }
        }
        #endregion ExcluiAvisos

        #region AtualizaRegras
        public bool AtualizaRegras(string textoRegras)
        {
            try
            {
                string strQuery = "UPDATE INTERNET.NEWS SET DESCR = '" + textoRegras.ToString() + "' WHERE ID = 1420 AND NEWS_SUBJECT_ID = 17";
                return InsertUpdateDelete(strQuery, Enums.Bancos.CorpTecon);
            }
            catch
            {
                return false;
            }
        }
        #endregion AtualizaRegras

        #region AtualizaMensagens
        public bool AtualizaMensagens(string textoMensagens)
        {
            try
            {
                string strQuery = "UPDATE INTERNET.NEWS SET DESCR = '" + textoMensagens.ToString() + "' WHERE ID = 1419 AND NEWS_SUBJECT_ID = 16";
                return InsertUpdateDelete(strQuery, Enums.Bancos.CorpTecon);
            }
            catch
            {
                return false;
            }
        }
        #endregion AtualizaMensagens

        #region BuscarAviso
        public DataTable BuscarAviso(long idAviso)
        {
            try
            {
                string strQuery = "SELECT ID, TITLE, DESCR FROM INTERNET.NEWS WHERE NEWS_SUBJECT_ID = 15 AND ID = " + idAviso;
                return GetDataTable(strQuery, Enums.Bancos.CorpTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion BuscarAviso
    }
}