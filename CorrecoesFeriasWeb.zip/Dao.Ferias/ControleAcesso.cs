﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Pier.Web.Dao.Ferias
{
    public class ControleAcesso : ECRUD.Oracle
    {
        #region Properties
        public string Ambiente { get; private set; }
        public string Usuario { get; private set; }
        #endregion Properties

        #region Construtor
        public ControleAcesso(string Usuario)
        {
            Ambiente = System.Configuration.ConfigurationManager.AppSettings["Ambiente"].ToString();
            this.Usuario = Usuario;
        }
        #endregion Construtor

        #region GetAcessoPorRegistroPerfil
        public DataTable GetAcessoPorRegistroPerfil(string strFuncRegistro, string strPerfilId)
        {
            try
            {
                string strQuery = "SELECT AC.* FROM PIER.PESSOA PE, PIER.USUARIO US, PIER.ACESSO AC, PIER.PERFIL_ACESSO PA, PIER.SISTEMA SI WHERE PE.FUNC_REGISTRO = '" + strFuncRegistro.ToString() + "' AND US.PESSOA = PE.PESSOA_ID AND US.ATIVO = 1 AND AC.USUARIO_ID = US.ID AND AC.ATIVO = 1 AND PA.ID = AC.PERFIL_ACESSO_ID AND SI.ID = 10621 AND PA.SISTEMA_ID = SI.ID AND PA.ATIVO = 1 AND PA.ID = '" + strPerfilId.ToString() + "'";
                return GetDataTable(strQuery, Enums.Bancos.CorpTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetAcessoPorRegistroPerfil

        #region GetAcessoLiberadoSistemaPorRegistroOutroPerfil
        public DataTable GetAcessoLiberadoSistemaPorRegistroOutroPerfil(string strFuncRegistro, string strPerfilId)
        {
            try
            {
                string strQuery = "SELECT AC.* FROM PIER.PESSOA PE, PIER.USUARIO US, PIER.ACESSO AC, PIER.PERFIL_ACESSO PA, PIER.SISTEMA SI WHERE PE.FUNC_REGISTRO = '" + strFuncRegistro.ToString() + "' AND US.PESSOA = PE.PESSOA_ID AND US.ATIVO = 1 AND AC.USUARIO_ID = US.ID AND AC.ATIVO = 1 AND PA.ID = AC.PERFIL_ACESSO_ID AND SI.ID = 10621 AND PA.SISTEMA_ID = SI.ID AND PA.ATIVO = 1 AND PA.ID != '" + strPerfilId.ToString() + "'";
                return GetDataTable(strQuery, Enums.Bancos.CorpTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetAcessoLiberadoSistemaPorRegistroOutroPerfil

        #region GetAcessoInativoSistemaPorRegistroPerfil
        public DataTable GetAcessoInativoSistemaPorRegistroPerfil(string strFuncRegistro, string strPerfilId)
        {
            try
            {
                string strQuery = "SELECT AC.* FROM PIER.PESSOA PE, PIER.USUARIO US, PIER.ACESSO AC, PIER.PERFIL_ACESSO PA, PIER.SISTEMA SI WHERE PE.FUNC_REGISTRO = '" + strFuncRegistro.ToString() + "' AND US.PESSOA = PE.PESSOA_ID AND US.ATIVO = 1 AND AC.USUARIO_ID = US.ID AND AC.ATIVO = 0 AND PA.ID = AC.PERFIL_ACESSO_ID AND SI.ID = 10621 AND PA.SISTEMA_ID = SI.ID AND PA.ATIVO = 1 AND PA.ID = '" + strPerfilId.ToString() + "'";
                return GetDataTable(strQuery, Enums.Bancos.CorpTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetAcessoInativoSistemaPorRegistroPerfil

        #region GetUsuarioPorRegistro
        public DataTable GetUsuarioPorRegistro(string strFuncRegistro)
        {
            try
            {
                string strQuery = "SELECT US.* FROM PIER.PESSOA PE, PIER.USUARIO US WHERE PE.FUNC_REGISTRO = '" + strFuncRegistro.ToString() + "' AND US.PESSOA = PE.PESSOA_ID AND US.ATIVO = 1";
                return GetDataTable(strQuery, Enums.Bancos.CorpTecon);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetUsuarioPorRegistro

        #region RemoveAcesso
        public bool RemoveAcesso(string strAcessoId, string strPerfilId)
        {
            try
            {
                string strQuery = "UPDATE PIER.ACESSO SET ATIVO = 0 WHERE ID = '" + strAcessoId.ToString() + "' AND PERFIL_ACESSO_ID = '" + strPerfilId.ToString() + "' AND ATIVO = 1";
                return InsertUpdateDelete(strQuery, Enums.Bancos.CorpTecon);
            }
            catch
            {
                return false;
            }
        }
        #endregion RemoveAcesso

        #region GravaSessao
        public long GravaSessao(string strUsuarioId)
        {
            try
            {
                using (var Oracle = new ECRUD.Oracle())
                {
                    string strQuery = "BEGIN INSERT INTO PIER.SESSAO (AMBIENTE,USUARIO) VALUES (0,'" + strUsuarioId.ToString() + "') RETURNING ID INTO :newId; END;";
                    object[,] Params = { { ":newId", "" } };
                    return InsertUpdateDeleteReturningBind(strQuery, Enums.Bancos.CorpTecon, Params, Usuario != "" ? Usuario : "AUTOMATICO");
                }
            }
            catch
            {
                return 0;
            }
        }
        #endregion GravaSessao

        #region GravaAcesso
        public bool GravaAcesso(string strPerfilAcessoId, string strUsuarioId, string strSessaoId)
        {
            try
            {
                string strQuery = "INSERT INTO PIER.ACESSO (PERFIL_ACESSO_ID,USUARIO_ID,SESSAO_ID) VALUES ('" + strPerfilAcessoId.ToString() + "','" + strUsuarioId.ToString() + "','" + strSessaoId.ToString() + "')";
                return InsertUpdateDelete(strQuery, Enums.Bancos.CorpTecon);
            }
            catch
            {
                return false;
            }
        }
        #endregion GravaAcesso

        #region AtivaAcesso
        public bool AtivaAcesso(string strAcessoId, string strPerfilId)
        {
            try
            {
                string strQuery = "UPDATE PIER.ACESSO SET ATIVO = 1 WHERE ID = '" + strAcessoId.ToString() + "' AND PERFIL_ACESSO_ID = '" + strPerfilId.ToString() + "' AND ATIVO = 0";
                return InsertUpdateDelete(strQuery, Enums.Bancos.CorpTecon);
            }
            catch
            {
                return false;
            }
        }
        #endregion AtivaAcesso
    }
}