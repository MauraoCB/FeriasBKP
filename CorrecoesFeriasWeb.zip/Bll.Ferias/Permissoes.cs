﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Pier.Web.Bll.Ferias
{
    public class Permissoes : Dao.Ferias.Permissoes, IDisposable
    {

        #region Construtor
        public Permissoes(string Usuario) : base(Usuario) { }
        #endregion

        #region Dispose
        public new void Dispose()
        {
            GC.SuppressFinalize(this);
        }
        #endregion

        #region GetPermissoes
        public new DataTable GetPermissoes()
        {
            try
            {
                return base.GetPermissoes();
            }
            catch
            {
                return null;
            }
        }
        #endregion

        #region GetPermissoes
        public new DataTable GetPermissoes(string strFuncRegistro, string strEmpresa)
        {
            try
            {
                return base.GetPermissoes(strFuncRegistro, strEmpresa);
            }
            catch
            {
                return null;
            }
        }
        #endregion

        #region GetEmpresas
        public new DataTable GetEmpresas()
        {
            try
            {
                return base.GetEmpresas();
            }
            catch
            {
                return null;
            }
        }
        #endregion

        #region GetPaginaLogin
        public new DataTable GetPaginaLogin(string strUsuaCPF, string strEndereco)
        {
            try
            {
                return base.GetPaginaLogin(strUsuaCPF, strEndereco);
            }
            catch
            {
                return null;
            }
        }
        #endregion GetPaginaLogin        

        #region GetRegrasProcedimentos
        public new string GetRegrasProcedimentos()
        {
            try
            {
                return base.GetRegrasProcedimentos();
            }
            catch
            {
                return "";
            }
        }
        #endregion GetRegrasProcedimentos        

        #region GetTextoPrincipal
        public new string GetTextoPrincipal()
        {
            try
            {
                return base.GetTextoPrincipal();
            }
            catch
            {
                return "";
            }
        }
        #endregion GetTextoPrincipal

        #region GetAvisos
        public new DataTable GetAvisos()
        {
            try
            {
                return base.GetAvisos();
            }
            catch
            {
                return null;
            }
        }
        #endregion

        #region GravaAvisos
        public new bool GravaAvisos(string tituloAvisdo, string textoAviso)
        {
            try
            {
                return base.GravaAvisos(tituloAvisdo, textoAviso);
            }
            catch
            {
                return false;
            }
        }
        #endregion GravaAvisos

        #region AtualizaAvisos
        public new bool AtualizaAvisos(string tituloAvisdo, string textoAviso, long idAviso)
        {
            try
            {
                return base.AtualizaAvisos(tituloAvisdo, textoAviso, idAviso);
            }
            catch
            {
                return false;
            }
        }
        #endregion AtualizaAvisos

        #region InativaAtivaAvisos
        public new bool InativaAtivaAvisos(long idAviso, string dataInativacao)
        {
            try
            {
                return base.InativaAtivaAvisos(idAviso, dataInativacao);
            }
            catch
            {
                return false;
            }
        }
        #endregion InativaAtivaAvisos

        #region ExcluiAvisos
        public new bool ExcluiAvisos(long idAviso)
        {
            try
            {
                return base.ExcluiAvisos(idAviso);
            }
            catch
            {
                return false;
            }
        }
        #endregion ExcluiAvisos

        #region AtualizaRegras
        public new bool AtualizaRegras(string textoRegras)
        {
            try
            {
                return base.AtualizaRegras(textoRegras);
            }
            catch
            {
                return false;
            }
        }
        #endregion AtualizaRegras

        #region AtualizaMensagens
        public new bool AtualizaMensagens(string textoMensagens)
        {
            try
            {
                return base.AtualizaMensagens(textoMensagens);
            }
            catch
            {
                return false;
            }
        }
        #endregion AtualizaMensagens

        public new DataTable BuscarAviso(long idAviso)
        {
            try
            {
                return base.BuscarAviso(idAviso);
            }
            catch
            {
                return null;
            }
        }

    }
}