﻿using Ferias.Web.Dao.Ferias;
using FeriasWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Pier.Web
{
    public partial class TipoProgramacaoEdit : System.Web.UI.Page
    {
        public int TipoProgramacaoId { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                TipoProgramacao tipoProgramacao = new TipoProgramacao();

                cboTipoVisualizacao.DataSource = tipoProgramacao.GetTipoVisualizacao();
                cboTipoVisualizacao.DataBind();

                cboTipoVisualizacao.Items.Insert(0, new ListItem { Value = "0", Text = "(Selecione)" });

                if (Request.QueryString["tipoProgramacaoId"] != null)
                {
                    List<TipoProgramacaoModel> tipoProgramacaoList = tipoProgramacao.GetTipoProgramacao(Request.QueryString["tipoProgramacaoId"].ToString());
                    txtDescricao.Text = tipoProgramacaoList[0].TPPG_DESCRICAO;
                    txtDiasPeriodo1.Text = tipoProgramacaoList[0].TPPG_DIAS_1_PER.ToString();
                    txtDiasPeriodo2.Text = tipoProgramacaoList[0].TPPG_DIAS_2_PER.ToString();
                    txtAbono.Text = tipoProgramacaoList[0].TPPG_ABONO.ToString();
                    TipoProgramacaoId = tipoProgramacaoList[0].TPPG_ID;
                    chkAtivo.Checked = tipoProgramacaoList[0].TPPG_ATIVO;
                    cboTipoVisualizacao.SelectedValue = tipoProgramacaoList[0].TPVZ_ID.ToString();
                } 
            }
        }


        protected void btnSalvar_Click(object sender, EventArgs e)
        {
            if (cboTipoVisualizacao.SelectedIndex <= 0)
            {
                Util.Alert.Show(this.Page, "Por favor escolha o tipo de visualização", "info", "Tipos de Programação");
                return;
            }
            TipoProgramacao tipoProgramacao = new TipoProgramacao();

            TipoProgramacaoModel model = new TipoProgramacaoModel()
            {
                TPPG_ID = TipoProgramacaoId,
                TPPG_ABONO = Convert.ToByte(txtAbono.Text),
                TPPG_ATIVO = chkAtivo.Checked,
                TPPG_DIAS_1_PER = Convert.ToByte(txtDiasPeriodo1.Text),
                TPPG_DIAS_2_PER = Convert.ToByte(txtDiasPeriodo2.Text),
                TPPG_DESCRICAO = txtDescricao.Text,
                TPVZ_ID = Convert.ToInt16(cboTipoVisualizacao.SelectedValue)              
            };
           string retorno = tipoProgramacao.SalvarTipoProgramacao(model).GetAwaiter().GetResult();


            if (TipoProgramacaoId !=0)
            {
                Util.Alert.Show(this.Page, "Tipo de programação alterado com sucesso", "info", "Tipo de Programação");
            }
            else
            {
                Util.Alert.Show(this.Page, "Tipo de programação incluído com sucesso", "info", "Tipo de Programação");
                System.Threading.Thread.Sleep(3000);
                Response.Redirect("TiposProgramacao.aspx");
                return;
            }
            System.Threading.Thread.Sleep(3000);
            Response.Redirect("TiposProgramacao.aspx");
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            if (!this.Page.ClientScript.IsClientScriptBlockRegistered("back"))
            {
                Response.Redirect("TiposProgramacao.aspx");
            }
        }
    }
}