﻿using FeriasWeb.Models;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;

namespace Ferias.Web.Dao.Ferias
{
    public class EmpresaFilialDAO: System.Web.UI.Page
    {
        #region Variables
        private string uri = System.Configuration.ConfigurationManager.AppSettings["UrlFeriasAPI"];
        #endregion

        public List<EmpresaFilialModel> GetEmpresas()
        {
            if (Session["EmpresaFilial"] != null)
            {
                return (List<EmpresaFilialModel>)Session["EmpresaFilial"];
            }

            string Metodo = "EmpresaFilial/GetEmpresas/";
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;
            List<EmpresaFilialModel> result = new List<EmpresaFilialModel>();

            using (var client = new HttpClient())
            {

                using (var response = client.GetAsync(Url).GetAwaiter().GetResult())
                {
                    Retorno = response.IsSuccessStatusCode ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : response.ReasonPhrase.ToString();
                }
            }

            result = JsonConvert.DeserializeObject<List<EmpresaFilialModel>>(Retorno);
            
            Session["EmpresaFilial"] = result;

            return result;
        }

        public List<ListItem> GetUnidades(int empresaId)
        {
            List<ListItem> listRetorno = GetEmpresas().Where(e=>e.EMPR_ID ==  empresaId).Select(l => new ListItem { Value = l.FILI_ID.ToString(), Text = l.FILI_DESC}).ToList();
            listRetorno.Insert(0, new ListItem { Value = "0", Text = "(Selecione)" });

            return listRetorno.OrderBy(l => l.Text).ToList();
        }
    }
}