﻿using System.Text;
using System.Web;
using System.Web.UI;

namespace Pier.Web.Util
{
    public static class Alert
    {

        public static void Show(string mensagem)
        {
            if (string.IsNullOrEmpty(mensagem)) return;
            mensagem = mensagem.Replace("'", "\'");
            string script = string.Format("javascript:alert('{0}');",mensagem);
            Page page = HttpContext.Current.CurrentHandler as Page;

            if (page != null && !page.ClientScript.IsClientScriptBlockRegistered("alert"))
            {
                page.ClientScript.RegisterClientScriptBlock(page.GetType(), "alert", script);
            }
            
            
        }

        public static void Show(Page pagina, string mensagem, string tipo, string titulo)
        {
            ScriptManager.RegisterClientScriptBlock(pagina, pagina.GetType(), "MensagemRetorno", $"toastr.{tipo}('{mensagem}', '{titulo}');", true);
        }
    }
}