﻿using Ferias.Web.Dao.Ferias;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Pier.Web
{
    public partial class ControladorSelecaoGestor : System.Web.UI.UserControl
    {  
        public int GestorId
        {
            get; set;
        }

        public string NomeGestor{ get; set; }

        public bool Enabled
        {
            get { return ddlGestor.Enabled; }
            set { ddlGestor.Enabled = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
               ddlGestor.DataSource = new Funcionario().GetGestores();
               ddlGestor.DataBind();

                string perfil = Session["strPerfilAcesso"].ToString().ToUpper();
                ddlGestor.Enabled = "INFORMATICA;ADMINISTRADOR DO RH".Contains(perfil);

                if (Session["GestorId"] != null)
                {
                    GestorId = Convert.ToInt32(Session["GestorId"]);
                }

                ddlGestor.SelectedValue = GestorId.ToString();
            }
        }

        protected void ddlGestor_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Limpa a session Funcionários pra forçar consulta ao banco de dados pelo novo gestor selecionado
            Session["Funcionarios"] = null;
            Session["GestorId"] = Convert.ToInt32(ddlGestor.SelectedValue);
            GestorId = Convert.ToInt32(ddlGestor.SelectedValue);
            NomeGestor = ddlGestor.SelectedItem.Text;

            Response.Redirect(Request.RawUrl);
        }
    }
}