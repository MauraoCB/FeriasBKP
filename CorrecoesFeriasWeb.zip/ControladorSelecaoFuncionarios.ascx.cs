﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Reflection;
using System.Text;
using FeriasWeb.Models;
using Ferias.Web.Dao.Ferias;
using System.Data;

namespace Pier.Web
{

	public partial class ControladorSelecaoFuncionarios : UserControl
	{
		public delegate void EventoSelecionouFuncionario(object source, EventArgs e);
		public event EventoSelecionouFuncionario AoSelecionarFuncionario;

		public FuncionarioModel FuncionarioSelecionado { get; set; }
		/// <summary>
		/// Define ou retorna o ID da previsão ou da programação de férias, de acordo com a respectiva tela/tabela
		/// </summary>
		public int IdPrevisaoProgramacao {
			get
			{
				if (Session["IdPrevisaoProgramacao"] != null)
				{
					return Convert.ToInt32(Session["IdPrevisaoProgramacao"]);
				}
				else
				{
					return 0;
				}
			}
			set { Session["IdPrevisaoProgramacao"] = value; }
		}

		public List<FuncionarioModel> Funcionarios
		{
			get
			{
				if (Session["Funcionarios"] != null)
				{
					return (List<FuncionarioModel>)Session["Funcionarios"];
				}
				else
				{
					return new List<FuncionarioModel>();
				}

			}
			set { Session["Funcionarios"] = value; }
		}

		public List<DistribuicaoFeriasOperModel> PrevisaoFerias
		{
			get
			{
				if (Session["PrevisaoFerias"] != null)
				{
					return (List<DistribuicaoFeriasOperModel>)Session["PrevisaoFerias"];
				}
				else
				{
					return new List<DistribuicaoFeriasOperModel>();
				}

			}
			set { Session["PrevisaoFerias"] = value; }
		}

		public List<ProgramacaoModel> ProgramacaoFerias
		{
			get
			{
				if (Session["ProgramacaoFerias"] != null)
				{
					return (List<ProgramacaoModel>)Session["ProgramacaoFerias"];
				}
				else
				{
					return new List<ProgramacaoModel>();
				}

			}
			set { Session["ProgramacaoFerias"] = value; }
		}
		// expose the event publicly
		public event EventHandler UserControlButtonClicked;

		// a method to raise the publicly exposed event
		private void OnUserControlButtonClick()
		{
			UserControlButtonClicked?.Invoke(this, EventArgs.Empty);
		}

		protected override void OnLoad(EventArgs e)
		{
			//	base.OnLoad(e);
			if (Session["Funcionarios"] == null)
			{
				Funcionarios = new Funcionario().GetFuncionarios(Convert.ToInt32(Session["GestorId"]));
			}
			if (Session["PrevisaoFerias"] == null && this.Page.GetType().Name == "previsaoferias_aspx")
			{
				Session["PrevisaoFerias"] = new PrevisaoFeriasDAO().GetDistribuicaoFerias();
			}

			if (Session["ProgramacaoFerias"] == null && this.Page.GetType().Name == "programacaoferias_aspx")
			{
				Session["ProgramacaoFerias"] = new ProgramacaoFeriasDAO().GetProgramacaoFerias();
				ProgramacaoFerias = (List<ProgramacaoModel>)Session["ProgramacaoFerias"];
			}

			if (!Page.IsPostBack)
			{
				_ = new TipoProgramacao().GetTipoProgramacao();

				string operacao = "" + Request.QueryString["Operacao"];

				if (this.Page.GetType().Name == "previsaoferias_aspx")
				{
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Chefia", DataField = "DFOP_NOME_CHEFIA" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Período Aquisitivo", DataField = "DFOP_PERIODO_AQUISITIVO" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Programação", DataField = "DFOP_PROGRAMACAO", DataFormatString = "{0:MM/yyyy}" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Data Limite", DataField = "DFOP_DATA_LIMITE", DataFormatString = "{0:dd/MM/yyyy}" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Qtd. Dias", DataField = "DFOP_QTDE_DIAS" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Abono", DataField = "DFOP_ABONO" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "13º Salário", DataField = "DFOP_13" });
				}
				else
				{
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Chefia", DataField = "PGFR_NOME_CHEFIA" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Período Aquisitivo", DataField = "PGFR_PERIODO_AQUISITIVO" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Tipo de Programação", DataField = "TPPG_DESCRICAO" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Programação 1", DataField = "PGFR_PROGRAMACAO_1", DataFormatString = "{0:dd/MM/yyyy}" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Programação 2", DataField = "PGFR_PROGRAMACAO_2", DataFormatString = "{0:dd/MM/yyyy}" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Data Limite", DataField = "PGFR_DATA_LIMITE", DataFormatString = "{0:dd/MM/yyyy}" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "13º Salário", DataField = "PGFR_13" });
					GridFuncionarios.Columns.Add(new BoundField() { HeaderText = "Status", DataField = "PGFR_STATUS" });
					GridFuncionarios.Columns.Add(new CheckBoxField() { HeaderText = "Aprovar", DataField = "PGFR_AUTORIZADO", ReadOnly = false, Visible = operacao == "APROVAR" });
				}
				CarregarGrid(Funcionarios);
			}
		}

		protected void GridFuncionarios_SelectedIndexChanged(object sender, EventArgs e)
		{
			var funcId = GridFuncionarios.DataKeys[GridFuncionarios.SelectedIndex].Values[0].ToString();

			IdPrevisaoProgramacao = (int)GridFuncionarios.DataKeys[GridFuncionarios.SelectedIndex].Values[1];

			FuncionarioSelecionado = Funcionarios.Where(f => f.FUNC_ID.ToString() == funcId).FirstOrDefault();

			// AoSelecionarFuncionario = new EventoSelecionouFuncionario(OnSelecionarFuncionario);;
			//AoSelecionarFuncionario.Invoke(sender, e);

			//Gambiarra dos infernos porque a porra do evento não foi acionado
			if (this.Page.GetType().Name == "previsaoferias_aspx")
			{
				((PrevisaoFerias)this.Page).OcultarSelecaoFuncionario();
			}
			else
			{
				((ProgramacaoFerias)this.Page).OcultarSelecaoFuncionario();
			}

			//OnUserControlButtonClick();
		}

		protected virtual void onSelecionouFuncionario()
		{

		}

		public void OnSelecionarFuncionario(object source, EventArgs e)
		{

		}
		protected void ddlCarregaConsulta_SelectedIndexChanged(object sender, EventArgs e)
		{
			txtRegistroNome.Text = "";
			txtRegistroNome.Width = new Unit(120, UnitType.Pixel);
			ddlParametroConsulta.Visible = ddlCarregaConsulta.SelectedIndex > 2;
			pnlProcurar.Visible = ddlCarregaConsulta.SelectedIndex <= 2;

			if (ddlCarregaConsulta.SelectedValue == "2")
			{
				txtRegistroNome.Width = new Unit(300, UnitType.Pixel);
			}

			switch (ddlCarregaConsulta.SelectedValue)
			{
				case "0":
					Funcionarios = new Funcionario().GetFuncionarios(Convert.ToInt32(Session["GestorId"]));
					CarregarGrid(Funcionarios);
					break;
				case "3":
					ddlParametroConsulta.DataSource = new Funcionario().GetCentroCusto();
					break;
				case "4":
					ddlParametroConsulta.DataSource = new Funcionario().GetCargos();
					break;
				case "5":
					ddlParametroConsulta.DataSource = new Funcionario().GetEquipes();
					break;
				default:
					return;
			}
			ddlParametroConsulta.DataBind();
		}

		protected void ddlParametroConsulta_SelectedIndexChanged(object sender, EventArgs e)
		{
			switch (ddlCarregaConsulta.SelectedValue)
			{				
				case "3":
					BuscaPorCentroCusto();
					break;
				case "4":
					BuscaPorCargo();
					break;
				case "5":
					BuscaPorEquipe();
					break;
				default:
					GridFuncionarios.DataSource = Funcionarios;
					GridFuncionarios.DataBind();
					break;
			}
		}

		public void CarregarGrid(List<FuncionarioModel> funcionarios)
		{
			///Guarda na seção o último resul
			Session["FuncionariosUltimaBusca"] = funcionarios;

			if (this.Page.GetType().Name == "previsaoferias_aspx")
			{
				CarregarPrevisaoFerias(funcionarios);
			}
			else
			{
				if (Session["strPerfilAcesso"].ToString().ToUpper().Contains("DELEGAÇÃO"))
                {
					var delegacoes = new FeriasDelega().GetFeriasDelega(Convert.ToInt32(Session["GestorId"])).Where(d=> d.FUNC_REGISTRO_DELEGADO== Convert.ToInt32( Session["strUsuaRegistro"]) && d.FRDL_ATIVO).ToList();
                    if (delegacoes.Count ==0)
                    {
						Util.Alert.Show(this.Page, "Não há delegações ativas para " + Session["strNomeUsuario"].ToString(), "error", "Funcionário Delegado");
					}

					funcionarios =
						   (from func in funcionarios
							join d in delegacoes on func.FUNC_REGISTRO equals d.FUNC_REGISTRO_DELEGADO.ToString()
							select func).Distinct().ToList();
				}
				CarregarProgramacaoFerias(funcionarios);
			}

            if (GridFuncionarios.Rows.Count == 0)
            {				
				Util.Alert.Show(this.Page, "Sem dados para o filtro selecionado. Por favor verifique se a leitura da planilha foi executada", "info", "");
			}
		}
		#region Métdos privados
		private void BuscaPorCentroCusto()
		{
			var funcionariosCentroCusto = Funcionarios.Where(f => f.FUNC_CC.ToString()  == ddlParametroConsulta.SelectedValue.Trim().ToUpper()).ToList();
			CarregarGrid(funcionariosCentroCusto);
		}

		private void BuscaPorCargo()
		{
			var funcionariosCargo = Funcionarios.Where(f => f.FUNC_COD_CARGO.ToString() == ddlParametroConsulta.SelectedValue).ToList();

			CarregarGrid(funcionariosCargo);
		}
		private void BuscaPorEquipe()
		{
			var funcionariosEquipe = new Funcionario().GetEquipeFuncionarios().Where(e => e.Descricao == ddlParametroConsulta.SelectedValue).ToList();

			if (funcionariosEquipe.Count == 0)
			{
			 Util.Alert.Show	(this.Page, "Nenhum funcionário nesta equipe", "info", "");
				return;
			}

			var funcionariosFiltrados =
			(from func in Funcionarios
			 join eq in funcionariosEquipe on func.FUNC_ID equals eq.FUNC_ID
			 select func).Distinct().ToList();

			if (funcionariosFiltrados.Count == 0)
			{
				Util.Alert.Show(this.Page, "Nenhum funcionário nesta equipe", "info", "");
				return;
			}

			CarregarGrid(funcionariosFiltrados);
		}

		private void CarregarPrevisaoFerias(List<FuncionarioModel> funcionariosFiltrados)
		{
			var previsoes =
			(from func in funcionariosFiltrados
			 join prev in PrevisaoFerias on func.FUNC_REGISTRO equals prev.DFOP_MATRICULA.ToString()
			 select new
			 {
				 func.FUNC_ID,
				 ID_PREVISAO_PROGRAMACAO = prev.DFOP_ID,
				 func.FUNC_REGISTRO,
				 func.FUNC_NOME,
				 func.FUNC_CARGO,
				 prev.DFOP_NOME_CHEFIA,
				 prev.DFOP_PERIODO_AQUISITIVO,
				 prev.DFOP_PROGRAMACAO,
				 prev.DFOP_DATA_LIMITE,
				 prev.DFOP_13,
				 prev.DFOP_QTDE_DIAS,
				 prev.DFOP_ABONO
			 }).Distinct().OrderBy(f => f.FUNC_NOME).ToList();

			GridFuncionarios.DataSource = previsoes;
			GridFuncionarios.DataBind();
		}

		private void CarregarProgramacaoFerias(List<FuncionarioModel> funcionariosFiltrados)
		{			
            if (ProgramacaoFerias.Count ==0)
            {
				ProgramacaoFerias = new ProgramacaoFeriasDAO().GetProgramacaoFerias();
			}

			string[] opcao13Salario = "Não;1º Período;2º Período;1º e 2º Períodos".Split(';');

			var programacoes =
			(from func in funcionariosFiltrados
			 join prog in ProgramacaoFerias on func.FUNC_REGISTRO equals prog.PGFR_MATRICULA.ToString()
			 // join tppg in tipoProgramacao on prog.TPPG_ID equals tppg.TPPG_ID
			 select new
			 {
				 func.FUNC_ID,
				 ID_PREVISAO_PROGRAMACAO = prog.PGFR_ID,
				 func.FUNC_REGISTRO,
				 func.FUNC_NOME,
				 func.FUNC_CARGO,
				 prog.PGFR_NOME_CHEFIA,
				 prog.PGFR_PERIODO_AQUISITIVO,
				 prog.PGFR_PROGRAMACAO_1,
				 prog.PGFR_PROGRAMACAO_2,
				 prog.PGFR_DATA_LIMITE,
				 prog.PGFR_AUTORIZADO,
				 TPPG_DESCRICAO = GetDescricaoTipoProgramacao(prog.TPPG_ID),
				 PGFR_13 = opcao13Salario[prog.PGFR_13],
				 prog.PGFR_ABONO,
				 prog.PGFR_DT_LANC_PERIODO,
				 prog.PGFR_STATUS,
				 prog.PGFR_MOTIVO_STATUS
			 }).Distinct().OrderBy(f => f.PGFR_STATUS+f.FUNC_NOME).ToList();


			string operacao = "" + Request.QueryString["Operacao"];

            if (operacao == "APROVAR")
            {
				programacoes = programacoes.Where(p => p.PGFR_DT_LANC_PERIODO != DateTime.MinValue).ToList();
            }

			GridFuncionarios.DataSource = programacoes;
			GridFuncionarios.DataBind();

			btnAprovar.Visible = (operacao == "APROVAR" && programacoes.Count > 0);
		}

		private string GetDescricaoTipoProgramacao(int? tppgId)
		{
			if (tppgId == null)
			{
				return "";
			}
			return new TipoProgramacao().GetTipoProgramacao(tppgId.ToString()).FirstOrDefault().TPPG_DESCRICAO;
		}
		#endregion

		protected void btnProcurar_Click(object sender, ImageClickEventArgs e)
		{
			List<FuncionarioModel> funcionarios = new List<FuncionarioModel>();
			if (ddlCarregaConsulta.SelectedValue == "0")
			{
				funcionarios = Funcionarios.Where(f => f.FUNC_REGISTRO == txtRegistroNome.Text).ToList();
			}
			else
			{
				funcionarios = Funcionarios.Where(f => f.FUNC_NOME.ToUpper().Contains(txtRegistroNome.Text.ToUpper())).ToList();
			}
			if (funcionarios.Count() == 0)
			{
				Util.Alert.Show("Funcionário não encontrado");
				return;
			}
			CarregarGrid(funcionarios);
		}

		protected void GridFuncionarios_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			bool aprovadorSN = "" + Request.QueryString["Operacao"] == "APROVAR";
			var dataSource = (dynamic)GridFuncionarios.DataSource;

			for (int i = 0; i < e.Row.Cells.Count; i++)
			{
				if (e.Row.RowType == DataControlRowType.DataRow)
				{
					if (e.Row.Cells[i].Text.Contains("01/0001"))
					{
						e.Row.Cells[i].Text = "";
					}
					if (this.Page.GetType().Name == "previsaoferias_aspx" && i == 10)
					{
						e.Row.Cells[i].Text = "Não";

						if (e.Row.Cells[i].Text.ToLower() == "true")
						{
							e.Row.Cells[i].Text = "Sim";
						}
					}
					if (this.Page.GetType().Name == "programacaoferias_aspx")
					{
                        if (e.Row.Cells[11].Text == "Aprovado")
                        {
							e.Row.Cells[11].ForeColor = System.Drawing.Color.Green;
						}
						else if (e.Row.Cells[11].Text == "Não Aprovado")
						{
							e.Row.Cells[11].ForeColor = System.Drawing.Color.Red;
						}
						((CheckBox)e.Row.Cells[12].Controls[0]).Enabled = aprovadorSN;
						((CheckBox)e.Row.Cells[12].Controls[0]).Checked = dataSource[e.Row.RowIndex].PGFR_AUTORIZADO;
					}
				}
			}

		}
		protected void btnAprovar_Click(object sender, ImageClickEventArgs e)
		{
			string jsonAprovacoes = "[";
			for (int i = 0; i < GridFuncionarios.Rows.Count; i++)
			{

				string autorizado = "0";
				if (GridFuncionarios.Rows[i].RowType == DataControlRowType.DataRow)
				{
					if (((CheckBox)GridFuncionarios.Rows[i].Cells[12].Controls[0]).Checked)
					{
						autorizado = "1";
                    }
                    else
                    {
						continue;
                    }
				}
				jsonAprovacoes += $"{{PGFR_ID: {GridFuncionarios.DataKeys[i].Values[1]}, Autorizado : {autorizado}, Status: 'Aprovado', MotivoStatus: ''}},";
			}
			jsonAprovacoes = jsonAprovacoes.Remove(jsonAprovacoes.Length - 1) + "]";

			ProgramacaoFeriasDAO programacaoFeriasDAO = new ProgramacaoFeriasDAO();
			string[] retorno = programacaoFeriasDAO.AprovarProgramacoes(jsonAprovacoes).Result;

		    Util.Alert.Show(this.Page,  retorno[1] , retorno[0], "Aprovação");

			//Recarrega o gri de funcionários com última busca e a alteração da programação de férias
			Session["ProgramacaoFerias"] = null;

			CarregarGrid((List<FuncionarioModel>)Session["FuncionariosUltimaBusca"]);
		}
	}
}