﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pier.Web.Dao.Ferias
{
    public class Enums
    {
        public enum Bancos
        {
            TelematTecon,
            TelematImbituba,
            TelematLogistica,
            TelematConvicon,
            TelematTeconDW,
            SgtapTecon,
            SgtapImbituba,
            SgtapLogistica,
            SgtapConvicon,
            CtisTecon,
            CtisImbituba,
            CtisLogistica,
            CtisConvicon,
            FatuTecon,
            FatuImbituba,
            FatuLogistica,
            FatuConvicon,
            RestritoTecon,
            CorpTecon
        }

    }
}