﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Web;

namespace Pier.Web
{
    public class DelegacaoPerfil: System.Web.UI.Page
    {
        #region AtivarDesativarAcesso
        public void AtivarDesativarAcesso(string strRegistro, string strPerfilId, string strPerfilNome, string acao)
        {
            try
            {
                //Verifica se usuário tem acesso ao perfil, se existir, remove, se não existir, libera:
                using (var BllControleAcesso = new Bll.Ferias.ControleAcesso(Session["FuncRegistro"].ToString()))
                {
                    DataTable Dt = BllControleAcesso.GetAcessoPorRegistroPerfil(strRegistro, strPerfilId);
                    if (Dt?.Rows.Count > 0 && acao == "D")
                    {
                        //Se possui acesso, então deverá ser retirado com a ação do click no checkbox:
                        if (BllControleAcesso.RemoveAcesso(Dt.Rows[0]["ID"].ToString(), strPerfilId.ToString()))
                        {
                           Util.Alert.Show(this.Page, "Acesso ao perfil " + strPerfilNome + " retirado com sucesso do usuário registro " + strRegistro + ".", "success", "");
                            return;
                        }
                        else
                        {
                            Util.Alert.Show(this.Page, "Erro ao retirar o acesso ao perfil " + strPerfilNome + " do usuário registro " + strRegistro + ".", "error", "" );
                            return;
                        }
                    }
                    else if (acao == "A" && Dt?.Rows.Count == 0)
                    {
                        //Se NÃO possui acesso, então deverá ser incluído com a ação do click no checkbox:

                        //Verifica se usuário possui cadastro para o registro do funcionário na tabela PIER.USUARIO (ATIVO):
                        DataTable DtUsuario = BllControleAcesso.GetUsuarioPorRegistro(strRegistro);
                        if (DtUsuario?.Rows.Count == 0)
                        {
                            Util.Alert.Show(this.Page, "Não foi encontrado registro (ativo) cadastrado para o Funcionário Registro:" + strRegistro + " (PIER.USUARIO).", "success", "");
                            return;
                        }
                        else
                        {
                            string strIdUsuarioPier = DtUsuario.Rows[0]["ID"].ToString();
                            string strIdSession = "";

                            //Verifica se usuário possui acesso ao sistema/perfil como inativo, se existir, apenas ativar o acesso, caso contrário será necessário criar:
                            DataTable DtAcessoInativoSistemaPerfil = BllControleAcesso.GetAcessoInativoSistemaPorRegistroPerfil(strRegistro, strPerfilId);
                            if (DtAcessoInativoSistemaPerfil?.Rows.Count > 0)
                            {
                                string strAcessoId = DtAcessoInativoSistemaPerfil.Rows[0]["ID"].ToString();

                                //Usuário já possui acesso, porém consta como INATIVO, então, será necessário apenas ativar novamente o acesso:
                                if (BllControleAcesso.AtivaAcesso(strAcessoId, strPerfilId))
                                {
                                    Util.Alert.Show(this.Page, "Acesso ao perfil " + strPerfilNome + " ativado com sucesso para o usuário registro " + strRegistro + ".", "success", "");
                                    return;
                                }
                                else
                                {
                                    Util.Alert.Show(this.Page, "Erro ao ativar o acesso ao perfil " + strPerfilNome + " para o usuário registro " + strRegistro + ".", "error", "");
                                    return;
                                }
                            }
                            else
                            {
                                //Verifica se usuário possui acesso a outro perfil do mesmo sistema, se existir, utilizar o mesmo registro da tabela PIER.SESSAO:
                                DataTable DtAcessoLiberadoSistemaOutroPerfil = BllControleAcesso.GetAcessoLiberadoSistemaPorRegistroOutroPerfil(strRegistro, strPerfilId);
                                if (DtAcessoLiberadoSistemaOutroPerfil?.Rows.Count > 0)
                                {
                                    strIdSession = DtAcessoLiberadoSistemaOutroPerfil.Rows[0]["SESSAO_ID"].ToString();
                                }

                                //Se não encontrou registros para utilizar o mesmo SESSAO_ID, será necessário criar registro na tabela PIER.SESSAO para o usuário (strIdUsuarioPier):
                                if (string.IsNullOrEmpty(strIdSession))
                                {
                                    //Grava tabela PIER.SESSAO:
                                    strIdSession = BllControleAcesso.GravaSessao(strIdUsuarioPier).ToString();
                                }

                                //Grava tabela PIER.ACESSO:
                                if (BllControleAcesso.GravaAcesso(strPerfilId.ToString(), strIdUsuarioPier.ToString(), strIdSession.ToString()))
                                {
                                    Util.Alert.Show(this.Page, "Acesso ao perfil " + strPerfilNome + " gravado com sucesso para o usuário registro " + strRegistro + ".", "success", "");
                                    return;
                                }
                                else
                                {
                                    Util.Alert.Show(this.Page, "Erro ao gravar o acesso ao perfil " + strPerfilNome + " para o usuário registro " + strRegistro + ".", "error", "");
                                    return;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                using (var Funcoes = new MasterSbsa.Util.Funcoes())
                {
                    Funcoes.LogErros(Ex, this, new StackTrace());
                }
                Util.Alert.Show(this.Page, Ex.Message + "\r\n"  + Ex.StackTrace, "error", "");
            }
        }
        #endregion AtivarDesativarAcesso
    }
}