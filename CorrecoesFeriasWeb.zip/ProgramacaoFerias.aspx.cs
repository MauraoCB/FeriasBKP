﻿using Ferias.Web.Dao.Ferias;
using FeriasWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Pier.Web
{
    public partial class ProgramacaoFerias : System.Web.UI.Page
    {
        const int SEM_13_SALARIO = 0;
        const int PRIMEIRO_PERIODO_13_SALARIO = 1;
        const int SEGUNDO_PERIODO_13_SALARIO = 2;
        const int AMBOS_PERIODOS_13_SALARIO = 3;

        public List<TipoProgramacaoModel> ListaTipoProgramacao
        {
            get
            {
                if (Session["ListaTipoProgramacao"] != null)
                {
                    return (List<TipoProgramacaoModel>)Session["ListaTipoProgramacao"];
                }
                else
                {
                    return new List<TipoProgramacaoModel>();
                }

            }
            set { Session["ListaTipoProgramacao"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {             
                if (Session["strPerfilAcesso"].ToString().ToUpper() == "GESTOR")
                {
                    Session["GestorId"] = Session["strUsuaRegistro"];
                    ControladorSelecaoGestor.GestorId = Convert.ToInt32(Session["GestorId"]);                    
                }

                if (Session["strPerfilAcesso"].ToString().ToUpper().Contains("DELEGAÇÃO"))
                {
                    var funcionario = new Funcionario().GetFuncionario(Session["strUsuaRegistro"].ToString());
                   
                    Session["GestorId"] = funcionario.FUNC_GESTOR;
                    ControladorSelecaoGestor.GestorId = funcionario.FUNC_GESTOR;
                }
            }

            string operacao = "" + Request.QueryString["Operacao"];
            if (operacao == "APROVAR")
            {
                pnlLancamentoProgramacao.Enabled = false;
                btnSalvar.Visible = false;
                btnCancelar.Visible = false;
                btnAprovar.Visible = true;
                lblTitulo.Text = "Aprovação de Programação de Férias";
                ddlStatus.Enabled = true;
                txtMotivoSatus.Enabled = true;
            }
        }

        protected void btnSalvar_Click(object sender, EventArgs e)
        {
            if (cboTipoProgramacao.SelectedIndex < 1)
            {
               Util.Alert.Show(this.Page, "Por favor ecolha um tipo de programação", "info", "Salvar");
                return;
            }
            txtMotivoSatus.Text = "";
            ddlStatus.SelectedIndex = 1;
            SalvarProgramacao("atualizada");
        }

        protected void btnVoltar_Click(object sender, EventArgs e)
        {
            pnlLancamentoProgramacao.Visible = false;
            pnlBotoes.Visible = false;
            ControladorSelecaoFuncionarios.Visible = true;
            tblAprovacao.Visible = false;

            Session["ProgramacaoFerias"] = null;
            ControladorSelecaoFuncionarios.ProgramacaoFerias = new List<ProgramacaoModel>();
            ControladorSelecaoFuncionarios.CarregarGrid((List<FuncionarioModel>)Session["FuncionariosUltimaBusca"]);
        }

        internal void OcultarSelecaoFuncionario()
        {
            ControladorSelecaoFuncionarios.Visible = false;
            pnlLancamentoProgramacao.Visible = true;
            tblAprovacao.Visible = true;
           pnlBotoes.Visible = true;

            CarregarPragramacao();
        }

        protected void cboTipoProgramacao_SelectedIndexChanged(object sender, EventArgs e)
        {
            trDias2.Visible = false;
            trProgramacao2.Visible = false;
            tr13Salario2.Visible = false;

            if (cboTipoProgramacao.SelectedIndex <= 0)
            {
                return;
            }
            ConfigurarTipoProgramacao();
            txtMotivoSatus.Text = "";
            ddlStatus.SelectedIndex = 1;
        }

        private void ConfigurarTipoProgramacao()
        {
            var tipoProgramacao = ListaTipoProgramacao.Where(t => t.TPPG_ID.ToString() == cboTipoProgramacao.SelectedValue).FirstOrDefault();

            if (tipoProgramacao == null)
            {
                return;
            }

            var programacaoSelecionada = (ProgramacaoModel)Session["ProgramacaoFeriasSelecionada"];
            if (programacaoSelecionada.PGFR_DIAS_1 == 0)
            {
                txtDias.Text = tipoProgramacao.TPPG_DIAS_1_PER.ToString();
            }
            if (programacaoSelecionada.PGFR_ABONO == 0)
            {
                txtAbono.Text = tipoProgramacao.TPPG_ABONO.ToString();
            }

            if (Session["strPerfilAcesso"].ToString().ToUpper() != "ADMINISTRADOR DO RH")
            {
                DateTime fimPeridoAqusitivo = Convert.ToDateTime(lblPeriodoAquisitivo.Text.Substring(13));
                Calendar1.StartDate = fimPeridoAqusitivo.AddDays(1);
                Calendar1.EndDate = Convert.ToDateTime(lblDataLimite.Text);

                if (tipoProgramacao.TPPG_DIAS_2_PER > 0)
                {
                    Calendar2.StartDate = fimPeridoAqusitivo.AddDays(1);
                    Calendar2.EndDate = Convert.ToDateTime(lblDataLimite.Text);
                }
            }

            if (tipoProgramacao.TPPG_DIAS_2_PER > 0)
            {
                trDias2.Visible = true;
                trProgramacao2.Visible = true;
                tr13Salario2.Visible = true;

                txtDias2.Text = tipoProgramacao.TPPG_DIAS_2_PER.ToString();
            } 
        }

        protected void btnAprovar_Click(object sender, ImageClickEventArgs e)
        {
            if (ddlStatus.SelectedIndex == 2 && txtMotivoSatus.Text == "")
            {
                Util.Alert.Show(this.Page, "Obrigatório justificar a não aprovação", "error", "");
                return;
            }

            string autorizado = "1";
            if (ddlStatus.SelectedIndex == 2)
            {
                autorizado = "0";
            }
            string jsonProgramacoesAprovar = $"[{{PGFR_ID : '{ControladorSelecaoFuncionarios.IdPrevisaoProgramacao}', Autorizado : '{autorizado}', Status: '{ddlStatus.SelectedValue}', MotivoStatus : '{txtMotivoSatus.Text}'}}]";


            ProgramacaoFeriasDAO programacaoFeriasDAO = new ProgramacaoFeriasDAO();
            string[] retorno = programacaoFeriasDAO.AprovarProgramacoes(jsonProgramacoesAprovar).Result;

            Util.Alert.Show(this.Page, retorno[1], retorno[0], "Aprovação");

            btnVoltar_Click(sender, e);
        }


        #region Private methods
        private void SalvarProgramacao(string operacao)
        {
            try
            {
                //Salva / cancela a programação de férias
                var programacaoSalvar = (ProgramacaoModel)Session["ProgramacaoFeriasSelecionada"];

                programacaoSalvar.TPPG_ID = Convert.ToInt16(cboTipoProgramacao.SelectedValue);

                programacaoSalvar.PGFR_AUTORIZADO = false;

                if (operacao == "atualizada")
                {
                    programacaoSalvar.PGFR_ABONO = Convert.ToInt16(txtAbono.Text.PadLeft(1, '0'));
                    if (Util.ValidationHelper.IsDate(txtProgramacao.Text))
                    {
                        programacaoSalvar.PGFR_PROGRAMACAO_1 = Convert.ToDateTime(txtProgramacao.Text);
                    }
                    programacaoSalvar.PGFR_DIAS_1 = Convert.ToInt16(txtDias.Text.PadLeft(1, '0'));
                    if (Util.ValidationHelper.IsDate(txtProgramacao2.Text))
                    {
                        programacaoSalvar.PGFR_PROGRAMACAO_2 = Convert.ToDateTime(txtProgramacao2.Text);
                    }
                    programacaoSalvar.PGFR_DIAS_2 = Convert.ToInt16(txtDias2.Text.PadLeft(1, '0'));
                    programacaoSalvar.PGFR_13 = SEM_13_SALARIO;

                    if (chk13Salario1.Checked && !chk13Salario2.Checked)
                    {
                        programacaoSalvar.PGFR_13 = PRIMEIRO_PERIODO_13_SALARIO;
                    }

                    if (!chk13Salario1.Checked && chk13Salario2.Checked)
                    {
                        programacaoSalvar.PGFR_13 = SEGUNDO_PERIODO_13_SALARIO;
                    }

                    if (chk13Salario1.Checked && chk13Salario2.Checked)
                    {
                        programacaoSalvar.PGFR_13 = AMBOS_PERIODOS_13_SALARIO;
                    }

                    if (Session["strPerfilAcesso"].ToString().ToUpper() != "ADMINISTRADOR DO RH")
                    {
                        if (programacaoSalvar.PGFR_PROGRAMACAO_1 < Calendar1.StartDate || programacaoSalvar.PGFR_PROGRAMACAO_1 > Calendar1.EndDate)
                        {
                            Util.Alert.Show(this.Page, "Programação 1 inválida", "error", "Data não Permitida");
                            return;
                        }

                        if ((programacaoSalvar.PGFR_PROGRAMACAO_2 < Calendar2.StartDate || programacaoSalvar.PGFR_PROGRAMACAO_2 > Calendar2.EndDate) && programacaoSalvar.PGFR_PROGRAMACAO_2 != DateTime.MinValue)
                        {
                            Util.Alert.Show(this.Page, "Programação 2 inválida", "error", "Data não Permitida");
                            return;
                        }
                    }
                    else
                    {
                        ddlStatus.SelectedIndex = 1;
                        txtMotivoSatus.Text = "";
                    }

                    if (ddlStatus.SelectedIndex == 2 && txtMotivoSatus.Text == "")
                    {
                        Util.Alert.Show(this.Page, "Obrigatório justificar a não aprovação", "error", "");
                        return;
                    }
                    programacaoSalvar.PGFR_STATUS = ddlStatus.SelectedValue;
                    programacaoSalvar.PGFR_MOTIVO_STATUS = txtMotivoSatus.Text;
                }
                else
                {                    
                    programacaoSalvar.TPPG_ID = null;
                    programacaoSalvar.PGFR_ABONO = 0;
                    programacaoSalvar.PGFR_PROGRAMACAO_1 = DateTime.MinValue;
                    programacaoSalvar.PGFR_DIAS_1 = 0;
                    programacaoSalvar.PGFR_PROGRAMACAO_2 = DateTime.MinValue;
                    programacaoSalvar.PGFR_DIAS_2 = 0;
                    programacaoSalvar.PGFR_13 = SEM_13_SALARIO;
                    programacaoSalvar.PGFR_STATUS = "Aprovação Pendente";
                    programacaoSalvar.PGFR_MOTIVO_STATUS = "";
                }

                _ = new ProgramacaoFeriasDAO().SaveProgramacaoFerias(programacaoSalvar);
               Util.Alert.Show(this.Page, "Programação " + operacao + " com sucesso", "info", "");

                //Recarrega o grid de funcionários com última busca e a alteração da programação de férias
                Session["ProgramacaoFerias"] = null;
                ControladorSelecaoFuncionarios.ProgramacaoFerias = new List<ProgramacaoModel>();

                ControladorSelecaoFuncionarios.CarregarGrid((List<FuncionarioModel>)Session["FuncionariosUltimaBusca"]);

                pnlLancamentoProgramacao.Visible = false;
                tblAprovacao.Visible = false;
               pnlBotoes.Visible = false;
                ControladorSelecaoFuncionarios.Visible = true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private void CarregarPragramacao()
        {
            var programacaoFerias = ControladorSelecaoFuncionarios.ProgramacaoFerias.Where(p => p.PGFR_ID == ControladorSelecaoFuncionarios.IdPrevisaoProgramacao).FirstOrDefault();
            if (programacaoFerias == null)
            {
                return;
            }

            Session["ProgramacaoFeriasSelecionada"] = programacaoFerias;

            lblNomeFuncionario.Text = programacaoFerias.PGFR_NOME;
            lblRegistroFuncionario.Text = programacaoFerias.PGFR_MATRICULA.ToString();
            lblCargo.Text = ControladorSelecaoFuncionarios.FuncionarioSelecionado.FUNC_CARGO;
            if (programacaoFerias.PGFR_DATA_LIMITE != DateTime.MinValue)
            {
                lblDataLimite.Text = programacaoFerias.PGFR_DATA_LIMITE.ToString("dd/MM/yyyy");
            }
            lblPeriodoAquisitivo.Text = programacaoFerias.PGFR_PERIODO_AQUISITIVO;

            //Carrega o combo de tipos de programação de acordo com a coluna OPER_ADM da view de equipes
            CarregarTipoProgramacao(ControladorSelecaoFuncionarios.FuncionarioSelecionado.FUNC_ID);

            if (programacaoFerias.TPPG_ID != null)
            {
                cboTipoProgramacao.SelectedValue = programacaoFerias.TPPG_ID.ToString();
            }
            txtProgramacao.Text = "";

            if (programacaoFerias.PGFR_PROGRAMACAO_1 != DateTime.MinValue)
            {
                txtProgramacao.Text = programacaoFerias.PGFR_PROGRAMACAO_1.ToString("dd/MM/yyyy");
            }
            txtDias.Text = programacaoFerias.PGFR_DIAS_1.ToString();

            if (programacaoFerias.PGFR_PROGRAMACAO_2 != DateTime.MinValue)
            {
                txtProgramacao2.Text = programacaoFerias.PGFR_PROGRAMACAO_2.ToString("dd/MM/yyyy");
            }
            txtDias.Text = programacaoFerias.PGFR_DIAS_2.ToString();

            txtAbono.Text = programacaoFerias.PGFR_ABONO.ToString();
            chk13Salario1.Checked = false;
            chk13Salario2.Checked = false;
            chk13Salario1.Checked = (programacaoFerias.PGFR_13 == 1 || programacaoFerias.PGFR_13 == 3);
            chk13Salario2.Checked = (programacaoFerias.PGFR_13 == 2 || programacaoFerias.PGFR_13 == 3);
            chk13Salario1.Enabled = programacaoFerias.PGFR_PROGRAMACAO_1.Month >= 2 && programacaoFerias.PGFR_PROGRAMACAO_1.Month <= 6;
            chk13Salario2.Enabled = programacaoFerias.PGFR_PROGRAMACAO_2.Month >= 2 && programacaoFerias.PGFR_PROGRAMACAO_2.Month <= 6;

            ddlStatus.SelectedValue = programacaoFerias.PGFR_STATUS;
            txtMotivoSatus.Text = programacaoFerias.PGFR_MOTIVO_STATUS;
            trMotivoStatus.Visible = programacaoFerias.PGFR_STATUS == "Não Aprovado";

            ConfigurarTipoProgramacao();
        }

        private void CarregarTipoProgramacao(int funcId)
        {
            ListaTipoProgramacao = new TipoProgramacao().GetTipoProgramacao();

            var equipeFuncionario = new Funcionario().GetEquipeFuncionarios().Where(e => e.FUNC_ID == funcId).FirstOrDefault();

            if (equipeFuncionario != null)
            {
                if (equipeFuncionario.OperAdm == 0)
                {
                    ListaTipoProgramacao = ListaTipoProgramacao.Where(t => t.TPVZ_ID == 1 || t.TPVZ_ID == 3).ToList();
                }
                else
                {
                    ListaTipoProgramacao = ListaTipoProgramacao.Where(t => t.TPVZ_ID == 1 || t.TPVZ_ID == 2).ToList();
                }
            }

            cboTipoProgramacao.Items.Clear();
            cboTipoProgramacao.Items.Add(new ListItem { Value = "0", Text = "(Selecione)", Selected = true });

            foreach (var item in ListaTipoProgramacao)
            {
                cboTipoProgramacao.Items.Add(new ListItem { Value = item.TPPG_ID.ToString(), Text = item.TPPG_DESCRICAO });
            }
        }

        private bool Habilitar13Salario(string dataProgramacao)
        {
            DateTime outDataProgramacao;
            if (!DateTime.TryParse(dataProgramacao, out outDataProgramacao))
            {
                return false;
            }

            int mes = Convert.ToDateTime(dataProgramacao).Month;

            return mes >= 2 && mes <= 6;
        }
        #endregion

        protected void txtProgramacao_TextChanged(object sender, EventArgs e)
        {
            chk13Salario1.Checked = false;
            chk13Salario1.Enabled = Habilitar13Salario(txtProgramacao.Text);
            txtMotivoSatus.Text = "";
            ddlStatus.SelectedIndex = 1;
        }

        protected void txtProgramacao2_TextChanged(object sender, EventArgs e)
        {
            chk13Salario2.Checked = false;
            chk13Salario2.Enabled = Habilitar13Salario(txtProgramacao2.Text);
            txtMotivoSatus.Text = "";
            ddlStatus.SelectedIndex = 1;
        }

        protected void btnCancelar_Click1(object sender, EventArgs e)
        {
            SalvarProgramacao("cancelada");
        }

        protected void ddlStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            trMotivoStatus.Visible = ddlStatus.SelectedIndex == 2;
        }
    }
}