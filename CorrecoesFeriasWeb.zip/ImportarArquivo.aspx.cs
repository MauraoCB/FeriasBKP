﻿using Pier.Web.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Pier.Web
{
    public partial class ImportarArquivo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                hdnUrlFeriasAPI.Value = System.Configuration.ConfigurationManager.AppSettings["UrlFeriasAPI"] + "SaveImportedSheet/"; 
            }
        }

        protected void btnSaveImportedSheet_Click(object sender, EventArgs e)
        {
            ImportarArquivoService service = new ImportarArquivoService();

            string [] retorno = service.SaveImportedSheet(hdnJsonProgramacao.Value).Result;
           
            Util.Alert.Show(this.Page, retorno[1] , retorno[0] , "Leitura da Planilha");
            System.Threading.Thread.Sleep(5000);
        }
    }
}