﻿using FeriasWeb.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;

namespace Ferias.Web.Dao.Ferias
{
    public class ProgramacaoFeriasDAO : System.Web.UI.Page
    {
        #region Variables
        private string uri = System.Configuration.ConfigurationManager.AppSettings["UrlFeriasAPI"];
        #endregion

        public List<ProgramacaoModel> GetProgramacaoFerias()
        {            
            string Metodo = "/Programacao/GetProgramacaoFerias/";
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;
            List<ProgramacaoModel> result = new List<ProgramacaoModel>();

            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(20);
                using (var response = client.GetAsync(Url).GetAwaiter().GetResult())
                {
                    Retorno = response.IsSuccessStatusCode ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : response.ReasonPhrase.ToString();
                }
            }

            try
            {
                result = JsonConvert.DeserializeObject<List<ProgramacaoModel>>(Retorno);
                result = result.Where(p => p.PGFR_SITUACAO != "AFA").ToList();
            }
            catch (Exception)
            {
                
            }
            Session["ProgramacaoFerias"] = result;

            return result;
        }

        public async Task<string> SaveProgramacaoFerias(ProgramacaoModel model)
        {
            string Metodo = string.Concat("/Programacao/SaveProgramacao");
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;

            string jsonProgramacaoFerias = JsonConvert.SerializeObject(model);

            jsonProgramacaoFerias = jsonProgramacaoFerias.Replace("true", "1");
            jsonProgramacaoFerias = jsonProgramacaoFerias.Replace("false", "0");

            var httpContent = new StringContent(jsonProgramacaoFerias, Encoding.UTF8, "application/json");

            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(20);
                using (var response = await client.PostAsync(Url, httpContent))
                {
                    Retorno = response.IsSuccessStatusCode ? await response.Content.ReadAsStringAsync() : response.ReasonPhrase.ToString();
                }
            }

            return Retorno;
        }
        public async Task<string[]> AprovarProgramacoes(string jsonProgramacoesAprovar)
        {
            string Metodo = string.Concat("/Programacao/AprovarProgramacoes");
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;
            string icon = "error";

            var httpContent = new StringContent(jsonProgramacoesAprovar, Encoding.UTF8, "application/json");

            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(20);

                using (var response = await client.PostAsync(Url, httpContent))
                {
                    Retorno = response.IsSuccessStatusCode ? await response.Content.ReadAsStringAsync() : response.ReasonPhrase.ToString();

                    if (Convert.ToBoolean(response.StatusCode))
                    {
                        icon = "success";
                        Retorno = "Dados gravados com sucesso";
                    }
                }
            }

            return String.Format("{0};{1}", icon, Retorno).Split(';');
        }
        public List<ListItem> GetEmpresas()
        {
            var EmpresasList = GetProgramacaoFerias().GroupBy(e => new { Value = e.PGFR_CODIGO_EMPRESA, Text = e.PGFR_CODIGO_EMPRESA}).Select(g => g.First()).ToList();

            List<ListItem> listRetorno = EmpresasList.Select(l => new ListItem { Value = l.PGFR_CODIGO_EMPRESA.ToString(), Text = l.PGFR_NOME_EMPRESA }).ToList();
            listRetorno.Insert(0, new ListItem { Value = "0", Text = "(Selecione)" });

            return listRetorno.OrderBy(l=> l.Text).ToList();
        }
    }
}