﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Collections;
using System.Net.Mime;

namespace Pier.Web.Util
{
    public class Email : IDisposable
    {
        private readonly string Remetente = ConfigurationManager.AppSettings["Email.FROM"];
        private readonly string SMTP = ConfigurationManager.AppSettings["Email.SMTP"];
        private readonly string Usuario = ConfigurationManager.AppSettings["Email.NetworkCredential.User"];
        private readonly string Senha = ConfigurationManager.AppSettings["Email.NetworkCredential.PWS"];

        



    

        public static void EnviarEmail(string Assunto, string Html, string EmailRemetente,string EmailDestinatario,string EmailCopia, ArrayList anexos)
        {

            try
            {

          
            //Cria novo objeto MailMessage          
            MailMessage mailMessage = new MailMessage();
            //Define o remetente           
            mailMessage.From = new MailAddress(EmailRemetente);
            //Define primeiro destinatário          
            mailMessage.To.Add(EmailDestinatario);

            if (EmailCopia != null)
            {
                mailMessage.CC.Add(EmailCopia);
            }
            //Define segundo destinatário, note que podemos adicionar infinitos destinatários         
            //mailMessage.To.Add("E-MAIL DO DESTINATÁRIO");        
            //Define assunto do e-mail         
            mailMessage.Subject = Assunto;
            //Seta propriedade para enviar email em html como true(verdadeiro)         
            mailMessage.IsBodyHtml = true;
            //Seta o corpo do e-mail com a estrutura HTML gravada na stringbuilder sbBody         
            mailMessage.Body = Html;

            //// Recupera o binario enviado pelo FileUpload  
            if (anexos != null) { 
              foreach (string anexo in anexos)
               {
                    Attachment anexado = new Attachment(anexo, MediaTypeNames.Application.Octet);
                    mailMessage.Attachments.Add(anexado);
                }
            }

            //Cria novo SmtpCliente e seta o endereço          
            SmtpClient smtpClient = new SmtpClient("mail2.santosbrasil.com.br");
            //Credencial para envio por SMTP Seguro (APENAS QUANDO O SERVIDOR EXIGE AUTENTICAÇÃO)            
          //  smtpClient.Credentials = new NetworkCredential(Usuario, Senha);
            // Envia a mensagem            
            smtpClient.Send(mailMessage);
             
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message + "não foi possivel enviar email para" + EmailDestinatario); ;
            }

        }
        public static void EnviarEmailAnexos(string Assunto, string Html, string EmailRemetente, ArrayList EmailDestinatario, List<Attachment> anexos)
        {
            //Cria novo objeto MailMessage          
            MailMessage mailMessage = new MailMessage();
            //Define o remetente           
            mailMessage.From = new MailAddress(EmailRemetente);
            //Define primeiro destinatário    
            foreach (var itemEmail in EmailDestinatario)
            {
                  mailMessage.To.Add(itemEmail.ToString());
            }
            
            
            //Define segundo destinatário, note que podemos adicionar infinitos destinatários         
            //mailMessage.To.Add("E-MAIL DO DESTINATÁRIO");        
            //Define assunto do e-mail         
            mailMessage.Subject = Assunto;
            //Seta propriedade para enviar email em html como true(verdadeiro)         
            mailMessage.IsBodyHtml = true;
            //Seta o corpo do e-mail com a estrutura HTML gravada na stringbuilder sbBody         
            mailMessage.Body = Html;

            // Recupera o binario enviado pelo FileUpload  

            foreach (Attachment anexo in anexos)
            {
                mailMessage.Attachments.Add(anexo);
            }


            //Cria novo SmtpCliente e seta o endereço          
            SmtpClient smtpClient = new SmtpClient("mail2.santosbrasil.com.br");
            //Credencial para envio por SMTP Seguro (APENAS QUANDO O SERVIDOR EXIGE AUTENTICAÇÃO)            
            //  smtpClient.Credentials = new NetworkCredential(Usuario, Senha);
            // Envia a mensagem            
            try
            {
                smtpClient.Send(mailMessage);
                smtpClient.Dispose();
                
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }




   


        #region  IDisposable Members
        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
        #endregion
    }


   


}
