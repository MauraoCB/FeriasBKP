﻿using System.Collections.Generic;
namespace Flexigrid.Helper
{
    public class Flexigrid
    {
        public int page;
        public int total;
        public List<FlexigridLinha> rows = new List<FlexigridLinha>();
    }
    public class FlexigridLinha
    {
        public long id;
        public List<string> cell;
    }
}