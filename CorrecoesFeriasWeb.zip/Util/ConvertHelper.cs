﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

namespace Pier.Web.Util
{
    public static class ConvertHelper
    {
        public static DataTable ToDataTable(object list)
        {
           string jsonString = JsonConvert.SerializeObject(list);

           return JsonConvert.DeserializeObject<DataTable>(jsonString);
        }      
    }
}