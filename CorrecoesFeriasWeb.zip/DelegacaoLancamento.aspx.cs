﻿using Ferias.Web.Dao.Ferias;
using FeriasWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Pier.Web
{
    public partial class DelegacaoLancamento : System.Web.UI.Page
    {

        public List<FuncionarioModel> Funcionarios
        {
            get
            {
                if (Session["Funcionarios"] != null)
                {
                    return (List<FuncionarioModel>)Session["Funcionarios"];
                }
                else
                {
                    return new List<FuncionarioModel>();
                }

            }
            set { Session["Funcionarios"] = value; }
        }
    
        public List<FeriasDelegaModel> TiposVisualizacao { get; set; }
        public List<FeriasDelegaModel> DelegacaoList
        {
            get
            {
                 if (Session["DelegacaoList"] != null)
                 {
                    return (List<FeriasDelegaModel>)Session["DelegacaoList"];
                 }
                 else
                 {
                     return new List<FeriasDelegaModel>();  
                 }

             }
            set { Session["DelegacaoList"] = value; }
        }

        public int GestorId { get; set; }
        
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                if (Session["strPerfilAcesso"].ToString().ToUpper() == "GESTOR")
                {
                    GestorId = Convert.ToInt32(Session["GestorId"]);
                    Session["GestorId"] = Session["strUsuaRegistro"];
                    ControladorSelecaoGestor.GestorId = Convert.ToInt32(Session["GestorId"]);
                }

                if (Session["GestorId"] != null)
                {
                    GestorId = Convert.ToInt32(Session["GestorId"]);
                }

                FeriasDelega feriasDelega = new FeriasDelega();
                DelegacaoList = feriasDelega.GetFeriasDelega(GestorId);

                Funcionario funcionario = new Funcionario();
                
                Funcionarios = funcionario.GetFuncionarios(GestorId);

                var listaFuncionarioaDelegar = (from func in Funcionarios
                                                select new
                                                {
                                                    func.FUNC_REGISTRO,
                                                    func.FUNC_NOME,
                                                }).Distinct().ToList();

                cboFuncionarioDelegado.DataSource = listaFuncionarioaDelegar;
                cboFuncionarioDelegado.DataBind();

                cboFuncionarioDelegado.Items.Insert(0, new ListItem() { Value = "0", Text = "(Todos)" });

                if (DelegacaoList.Count != 0)
                {
                    GridFeriasDelega.DataSource = DelegacaoList;
                    GridFeriasDelega.DataBind(); 
                }
            } 
        }

        protected void btnIncluir_Click(object sender, EventArgs e)
        {
            if (cboFuncionarioDelegado.SelectedIndex <=0)
            {
                Util.Alert.Show(this.Page, "Por favor escolha o funcionário delegado", "info","Delegação de Lançamento");
                return;
            }
            Response.Redirect($"DelegacaoLancamentoNova.aspx?GestorId={ControladorSelecaoGestor.GestorId}&nomeGestor={ControladorSelecaoGestor.NomeGestor}&delegadoId={cboFuncionarioDelegado.SelectedValue}");
        }

      protected  void GridFeriasDelega_RowDataBound(Object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                FuncionarioModel delegado = Funcionarios.Where(f => f.FUNC_REGISTRO ==  GridFeriasDelega.DataKeys[e.Row.RowIndex].Values[1].ToString()).FirstOrDefault();
                e.Row.Cells[0].Text = delegado.FUNC_NOME;

                FuncionarioModel funcionario = Funcionarios.Where(f => f.FUNC_REGISTRO == GridFeriasDelega.DataKeys[e.Row.RowIndex].Values[2].ToString()).FirstOrDefault();
                e.Row.Cells[1].Text = funcionario.FUNC_NOME;
                if (e.Row.Cells[3].Text.Contains("01/0001"))
                {
                    e.Row.Cells[3].Text = "";
                }
                ((CheckBox)e.Row.Cells[4].Controls[0]).Enabled = true;
                ((CheckBox)e.Row.Cells[5].Controls[0]).Enabled = true;
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
           Response.Redirect("default.aspx");
        }

        protected void btnSalvar_Click(object sender, EventArgs e)
        {
            if (GridFeriasDelega.Rows.Count == 0)
            {
                Util.Alert.Show(this.Page, "Nenhum registro para salvar", "info", "Delegação de Lançamento");                
                return;
            }

            string jsonDelegacoes = "";

            foreach (GridViewRow item in GridFeriasDelega.Rows)
            {
                if (item.RowType == DataControlRowType.DataRow)
                {
                    string DataCriacao = Convert.ToDateTime( item.Cells[2].Text).ToString("yyyy-MM-dd");
                    string DataCancelamento = item.Cells[3].Text;

                    int flowGestor = ((CheckBox)item.Cells[4].Controls[0]).Checked?1:0;
                    int ativo = ((CheckBox)item.Cells[5].Controls[0]).Checked?1:0;

                    if (ativo == 0  )
                    {
                        if (DataCancelamento == "")
                        {
                            DataCancelamento = DateTime.Now.ToString("yyyy-MM-dd");
                        }
                        else
                        {
                            DataCancelamento = Convert.ToDateTime(item.Cells[3].Text).ToString("yyyy-MM-dd");
                        }
                    }
                    

                    jsonDelegacoes += $"{{'FRDL_ID' : {GridFeriasDelega.DataKeys[item.RowIndex].Values[0]}, 'FUNC_REGISTRO_DELEGADO' : {GridFeriasDelega.DataKeys[item.RowIndex].Values[1]}, 'FUNC_REGISTRO_FILHO' : {GridFeriasDelega.DataKeys[item.RowIndex].Values[2]}, 'FUNC_GESTOR' : {GestorId}, 'FRDL_CRIACAO' : '{DataCriacao}', 'FRDL_CANCEL' : '{DataCancelamento}', 'FRDL_FLOW_GESTOR': {flowGestor}, 'FRDL_ATIVO':{ativo}}},";
                }
            }

            jsonDelegacoes = "[" + jsonDelegacoes.Remove(jsonDelegacoes.Length - 1) + "]";
            jsonDelegacoes = jsonDelegacoes.Replace("'", "\"");

            FeriasDelega feriasDelega = new FeriasDelega();

            try
            {
                feriasDelega.SalvarDelegacoesLancamento(jsonDelegacoes).GetAwaiter().GetResult();
            }
            catch (Exception ex)
            {
                Util.Alert.Show(this.Page, "Erro ao atualizar delegações de lançamento: " + ex.Message, "error", "Delegação de Lançamento");
            }
        }

        protected void cboFuncionarioDelegado_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboFuncionarioDelegado.SelectedIndex != 0 && DelegacaoList.Count >0)
            {
                List<FeriasDelegaModel> filtroDelegado = DelegacaoList.FindAll(d => d.FUNC_REGISTRO_DELEGADO.ToString() == cboFuncionarioDelegado.SelectedValue);

                GridFeriasDelega.DataSource = filtroDelegado;
                GridFeriasDelega.DataBind();
            }
            else
            {
                GridFeriasDelega.DataSource = DelegacaoList;
                GridFeriasDelega.DataBind();
            }
        }
    }
}