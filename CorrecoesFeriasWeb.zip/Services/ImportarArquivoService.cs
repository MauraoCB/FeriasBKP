﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Pier.Web.Services
{
    public class ImportarArquivoService
    {
        #region Variables
        private string uri = System.Configuration.ConfigurationManager.AppSettings["UrlFeriasAPI"];
        #endregion

        public async Task<string []> SaveImportedSheet(string jsonProgramacao)
        {
            string Metodo = string.Concat("/Programacao/SaveImportedSheet");
            string Url = string.Concat(uri, Metodo);
            string Retorno = string.Empty;
            string icon = "error";

            var httpContent = new StringContent(jsonProgramacao, Encoding.UTF8, "application/json");

            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(20);

                using (var response = await client.PostAsync(Url, httpContent))
                {
                    Retorno = response.IsSuccessStatusCode ? await response.Content.ReadAsStringAsync() : response.ReasonPhrase.ToString();

                    if (Convert.ToBoolean(response.StatusCode))
                    {
                        icon = "success";
                        Retorno = "Programação importada com sucesso";
                    }
                }
            }

            return String.Format("{0};{1}", icon, Retorno).Split(';');
        }
    }
}