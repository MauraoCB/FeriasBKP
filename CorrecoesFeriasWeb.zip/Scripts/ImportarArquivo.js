﻿var jsonData = "";
var UrlBase_Cod = window.location.origin + '/ImportarArquivo';

function UploadProcess() {
    //Reference the FileUpload element.
    var fileUpload = document.getElementById("fileUpload");

    //Validate whether File is valid Excel file.
    
    if ( fileUpload.value.toLowerCase().indexOf(".xls") >= 0) {
        if (typeof (FileReader) != "undefined") {
            var reader = new FileReader();

            //For Browsers other than IE.
            if (reader.readAsBinaryString) {
                reader.onload = function (e) {
                    GetTableFromExcel(e.target.result);
                };
                reader.readAsBinaryString(fileUpload.files[0]);
            } else {
                //For IE Browser.
                reader.onload = function (e) {
                    var data = "";
                    var bytes = new Uint8Array(e.target.result);
                    for (var i = 0; i < bytes.byteLength; i++) {
                        data += String.fromCharCode(bytes[i]);
                    }
                    GetTableFromExcel(data);
                };
                reader.readAsArrayBuffer(fileUpload.files[0]);
            }
        } else {
            ShowModalMessage("O seu browser não suporta HTML5.", "Importar", "info");
        }
    } else {
        ShowModalMessage("Por favor escolha um arquivo Excel válido.", "Importar", "info");
    }
}

function GetTableFromExcel(data) {
    //Read the Excel File data in binary
    var workbook = XLSX.read(data, {
        type: 'binary'
    });

    //get the name of First Sheet.
    var Sheet = workbook.SheetNames[0];

    //Read all rows from First Sheet into an JSON array.
    var excelRows = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[Sheet]);

    if (excelRows.length > 4001) {
        ShowModalMessage("O número máximo de linhas deve ser 4000", "Importar", "error");
        return;
    }
    //Create a HTML Table element.
    var myTable = document.createElement("table");
    myTable.border = "1";
    myTable.style = "color:#333333;width:882px;border-collapse:collapse;"
    //Add the header row.
    var row = myTable.insertRow(-1);

    row.style = "color:White;background-color:#5D7B9D;font-weight:bold;"
    //Add the header cells.
    var headerCell = document.createElement("TH");
    headerCell.innerHTML = "Código da Empresa";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Nome da Empresa";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Código do Estabelecimento";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Nome do Estabelecimento";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Matrícula";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Nome";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Escala/ Turma";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Admissão";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Sit";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Período Aquisitivo";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Dat.Limite";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Qtd. (Dias)";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Meses";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Saldo (Dias)";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Dias Gozados";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Programação";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Dias";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Abono";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "13°Sal";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Código do Centro de Resultado";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Nome do Centro de Resultado";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Matrícula da Chefia";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Nome da Chefia";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Férias Compulsórias";
    row.appendChild(headerCell);

    headerCell = document.createElement("TH");
    headerCell.innerHTML = "Tipo de Programação";
    row.appendChild(headerCell);
    
    var jsonProperties = "PGFR_CODIGO_EMPRESA;PGFR_NOME_EMPRESA;PGFR_CODIGO_ESTABELECIMENTO;PGFR_NOME_ESTABELECIMENTO;PGFR_MATRICULA;PGFR_NOME;PGFR_ESCALA_TURMA;PGFR_ADMISSAO;PGFR_SITUACAO;PGFR_PERIODO_AQUISITIVO;PGFR_DATA_LIMITE;PGFR_QTDE_DIAS;PGFR_MESES;PGFR_SALDO;PGFR_DIAS_GOZADO;PGFR_PROGRAMACAO_1;PGFR_DIAS_1;PGFR_ABONO;PGFR_13;PGFR_CODIGO_CENTRO_RESULTADO;PGFR_NOME_RESULTADO;PGFR_MATRICULA_CHEFIA;PGFR_NOME_CHEFIA;PGFR_FERIAS_COMPULSORIAS;TPPG_ID".split(";");
    jsonData = "[";
    //Add the data rows from Excel file.
    for (var i = 0; i < excelRows.length; i++) {
        //Add the data row.
        var row = myTable.insertRow(-1);

        row.style = "color:#284775;background-color:White;"

        if ((i % 2) == 0 ) {
            row.style = "color:#333333;background-color:#F7F6F3;";
        }
        //Add the data cells.
        var cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Código da Empresa"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Nome da Empresa"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Código do Estabelecimento"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Nome do Estabelecimento"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Matrícula"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Nome"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Escala/ Turma"];

        cell = row.insertCell(-1);
        cell.innerHTML = formatDate(excelRows[i]["Admissão"]);

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Sit"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Período Aquisitivo"];

        cell = row.insertCell(-1);
        cell.innerHTML = formatDate(excelRows[i]["Dat.Limite"]);        

        cell = row.insertCell(-1);                      
        cell.innerHTML = excelRows[i]["Qtd. (Dias)"].replace(".", ",");

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Meses"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Saldo (Dias)"].replace(".", ",");

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Dias Gozados"].replace(".", ",");

        cell = row.insertCell(-1);
        cell.innerHTML = formatDate(excelRows[i]["Programação"]);

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Dias"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Abono"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["13°Sal"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Código do Centro de Resultado"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Nome do Centro de Resultado"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Matrícula da Chefia"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Nome da Chefia"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Férias Compulsórias"];

        cell = row.insertCell(-1);
        cell.innerHTML = excelRows[i]["Tipo de Programação"];

        var jsonRow = "";
        for (var j = 0; j < row.cells.length; j++) {
            row.cells[j].innerText = row.cells[j].innerText.replace("undefined", "");

            var propertyValue = row.cells[j].innerText;
            
            if (propertyValue.toLowerCase == "perdida") {
                propertyValue = "";
            }

            if (jsonProperties[j] == "TPPG_ID" && propertyValue == "") {
                propertyValue = "null";
            }

            if (j == 7 || j== 10 ) {
                propertyValue = formatIsoDate(propertyValue);
            }

            propertyValue = propertyValue.replace('"', ' ');

            if ("PGFR_QTDE_DIAS;PGFR_MESES;PGFR_SALDO;PGFR_DIAS_GOZADO".indexOf(jsonProperties[j]) >= 0) {
                jsonRow += '"' + jsonProperties[j] + '" : ' + parseInt(propertyValue.replace(',', '.')) + ',';
            } else {
                jsonRow += '"' + jsonProperties[j] + '" : "' + propertyValue + '",';
            }
        }
        jsonData += "{" + jsonRow.substring(0, jsonRow.length - 1) + "},";

    }

    jsonData = jsonData.substring(0, jsonData.length - 1) + "]";
    $("#hdnJsonProgramacao").val(jsonData);
    var ExcelTable = document.getElementById("ExcelTable");
    ExcelTable.innerHTML = "";
    ExcelTable.appendChild(myTable);

    if (!$("#chkPreviewImport").prop("checked")) {
        SaveImportedSheet();
    } else {
        //$("#SaveImportedSheet").show();
        $("#divSaveImportedSheet").show();
    }
}

function previewImport(value) {
    $("#divPreview").hide();

    if (value) {
        $("#divPreview").show();
    }
}

function SaveImportedSheet() {
    //$("#SaveImportedSheet").hide();
    $("#divSaveImportedSheet").hide();
    $("#upload").hide();   
    
    
    $.ajax({
        url: $("#hdnUrlFeriasAPI").val() ,
        type: 'POST',
        dataType: 'json',

        data: { jsonProgramacao: jsonData },
        success: function (response) {

            //success apenas indica que a API pode ser chamada, mesmo que tenha retornado erro
            if (response.success) {
                if (response.statusCode === "200") {

                    swal({ icon: "success", text: "Programação importada com sucesso", title: "" });
                } else {
                    swal({ text: response.message, title: 'Erro!', icon: 'info' });
                }
            }
            else {
                ShowModalMessage(response.message, 'Erro', 'error');
            }
        },
        error: function (resp2) {

        }
    });

    jsonData = "";
}

function formatDate(data) {
    if (data == undefined) {
        return "";
    }
    if (data.indexOf("/") <0 ) {
        return data;
    }

    var objData = new Date(data);
    var mes = objData.getMonth() + 1;
    var dia = data.split("/")[1];

    var data_ddMMaaaa = dia.padStart(2, "0") + "/" + mes.toString().padStart(2, '0') + "/" + objData.getFullYear().toString();

    return data_ddMMaaaa;
}

function formatIsoDate(data) {
    if (data == undefined) {
        return "";
    }
    if (data.indexOf("/") < 0) {
        return data;
    }
    var arrayData = data.split("/");
    var data_aaaaMMdd = arrayData[2] + "-" + arrayData[1].padStart(2, '0') + "-" + arrayData[0].padStart(2, '0');

    return data_aaaaMMdd;
}

function isValidDate(value) {
    return value instanceof Date && !isNaN(value);
}