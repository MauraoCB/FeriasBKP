﻿using Ferias.Web.Dao.Ferias;
using FeriasWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Pier.Web
{
    public partial class PrevisaoFerias : System.Web.UI.Page
    {
        public List<TipoProgramacaoModel> ListaTipoProgramacao
        {
            get
            {
                if (Session["ListaTipoProgramacaoPrevisao"] != null)
                {
                    return (List<TipoProgramacaoModel>)Session["ListaTipoProgramacaoPrevisao"];
                }
                else
                {
                    return new List<TipoProgramacaoModel>();
                }

            }
            set { Session["ListaTipoProgramacaoPrevisao"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {               

                if (Session["strPerfilAcesso"].ToString().ToUpper() == "GESTOR")
                {
                    Session["GestorId"] = Session["strUsuaRegistro"];
                    ControladorSelecaoGestor.GestorId = Convert.ToInt32(Session["GestorId"]);
                }               

                ListaTipoProgramacao = new TipoProgramacao().GetTipoProgramacao().Where(t => t.TPVZ_ID == 1 || t.TPVZ_ID == 3).ToList();

                cboTipoProgramacao.Items.Add(new ListItem { Value = "0", Text = "(Selecione)", Selected = true });

                foreach (var item in ListaTipoProgramacao)
                {
                    cboTipoProgramacao.Items.Add(new ListItem { Value = item.TPPG_ID.ToString(), Text = item.TPPG_DESCRICAO });
                }

                ControladorSelecaoFuncionarios.AoSelecionarFuncionario += new ControladorSelecaoFuncionarios.EventoSelecionouFuncionario(ControladorSelecaoFuncionarios_AoSelecionarSelecionarFuncionario);
                ControladorSelecaoFuncionarios.UserControlButtonClicked += ControladorSelecaoFuncionarios_UserControlButtonClicked;
            }
        }

        private void ControladorSelecaoFuncionarios_UserControlButtonClicked(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void ControladorSelecaoFuncionarios_AoSelecionarSelecionarFuncionario(object source, EventArgs e)
        {
            ControladorSelecaoFuncionarios.Visible = false;
            pnlLancamentoPrevisao.Visible = true;
        }
        public void OcultarSelecaoFuncionario()
        {
            ControladorSelecaoFuncionarios.Visible = false;
            pnlLancamentoPrevisao.Visible = true;

            CarregarPrevisao();
        }

        protected void btnSalvar_Click(object sender, EventArgs e)
        {

            if (cboTipoProgramacao.SelectedIndex < 1)
            {
                Util.Alert.Show(this.Page, "Por favor ecolha um tipo de programação", "info", "Salvar");
                return;
            }

            try
            {
                //Salva a previsão de férias
                var previsaoSalvar = (DistribuicaoFeriasOperModel)Session["PrevisaoFeriasSelecionada"];

                previsaoSalvar.DFOP_ABONO = Convert.ToInt16(txtAbono.Text);
                previsaoSalvar.DFOP_DIAS = Convert.ToInt16(txtDias.Text);
                previsaoSalvar.DFOP_PROGRAMACAO = Convert.ToDateTime("01/" + txtProgramacao.Text);
                previsaoSalvar.DFOP_13 = chk13Salario.Checked;
                previsaoSalvar.TPPG_ID = Convert.ToInt16(cboTipoProgramacao.SelectedValue);
                previsaoSalvar.DFOP_DT_LANC_PERIODO = DateTime.Now;
                List<DistribuicaoFeriasOperModel> listaSalvar = new List<DistribuicaoFeriasOperModel>();

                listaSalvar.Add(previsaoSalvar);

                _ = new PrevisaoFeriasDAO().SavePrevisaoFerias(listaSalvar);

                Util.Alert.Show(this.Page, "Previsão atualizada com sucesso", "info", "");

                //Recarrega o gri de funcionários com última busca e a alteração da previsão de férias
                Session["PrevisaoFerias"] = null;
                Session["ListaDistribuicaoFerias"] = null;

                ControladorSelecaoFuncionarios.CarregarGrid((List<FuncionarioModel>)Session["FuncionariosUltimaBusca"]);

                pnlLancamentoPrevisao.Visible = false;
                ControladorSelecaoFuncionarios.Visible = true;
                // Session["PrevisaoFeriasSelecionada"] = null;
            }
            catch (Exception)
            {
                throw;
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            pnlLancamentoPrevisao.Visible = false;
            ControladorSelecaoFuncionarios.Visible = true;
        }

        protected void cboTipoProgramacao_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboTipoProgramacao.SelectedIndex == 1)
            {
                txtDias.Text = "30";
                txtAbono.Text = "0";
            }
            else
            {
                txtDias.Text = "20";
                txtAbono.Text = "10";
            }
        }

        #region Private methods
        private void CarregarPrevisao()
        {
            var previsaoFerias = ControladorSelecaoFuncionarios.PrevisaoFerias.Where(p => p.DFOP_ID == ControladorSelecaoFuncionarios.IdPrevisaoProgramacao).FirstOrDefault();
            Session["PrevisaoFeriasSelecionada"] = previsaoFerias;

            lblNomeFuncionario.Text = previsaoFerias.DFOP_NOME;
            lblRegistroFuncionario.Text = previsaoFerias.DFOP_MATRICULA.ToString();
            lblCargo.Text = ControladorSelecaoFuncionarios.FuncionarioSelecionado.FUNC_CARGO;
            if (previsaoFerias.TPPG_ID != null)
            {
                cboTipoProgramacao.SelectedValue = previsaoFerias.TPPG_ID.ToString(); 
            }
            txtProgramacao.Text = "";
            chk13Salario.Checked = previsaoFerias.DFOP_13;

            if (previsaoFerias.DFOP_PROGRAMACAO != DateTime.MinValue)
            {
                txtProgramacao.Text = previsaoFerias.DFOP_PROGRAMACAO.ToString("MM/yyyy");
            }

            var tipoProgramacao = ListaTipoProgramacao.Where(t => t.TPPG_ID.ToString() == cboTipoProgramacao.SelectedValue).FirstOrDefault();

            if (tipoProgramacao == null)
            {
                return;
            }

            txtDias.Text = tipoProgramacao.TPPG_DIAS_1_PER.ToString();
            txtAbono.Text = tipoProgramacao.TPPG_ABONO.ToString();

        }
        #endregion
    }
}