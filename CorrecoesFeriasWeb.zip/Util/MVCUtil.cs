﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pier.Web.Util
{
    public static class MVCUtil
    {
        private static System.Net.NetworkCredential _credencial;
        /// <summary>
        /// Credencial do usuário logado no Active Directory (Client). Útil para WCF.
        /// </summary>
        public static System.Net.NetworkCredential CredencialWindows
        {
            get
            {
                return _credencial;
            }
            set
            {
                _credencial = value;
            }
        }
    }
}