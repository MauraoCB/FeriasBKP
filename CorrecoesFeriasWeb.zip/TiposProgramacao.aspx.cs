﻿using Ferias.Web.Dao.Ferias;
using FeriasWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Pier.Web
{
    public partial class TiposProgramacao : System.Web.UI.Page
    {
        public List<TipoVisualizacaoModel> TiposVisualizacao { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                TipoProgramacao tipoProgramacao = new TipoProgramacao();
                List<TipoProgramacaoModel> tipoProgramacaoList = tipoProgramacao.GetTipoProgramacao();

                TiposVisualizacao = tipoProgramacao.GetTipoVisualizacao();

                GridTiposProgramacao.DataSource = tipoProgramacaoList;
                GridTiposProgramacao.DataBind(); 
            }
        }

        protected void btnIncluir_Click(object sender, EventArgs e)
        {
            Response.Redirect("TipoProgramacaoEdit.aspx");
        }

      protected  void GridTiposProgramacao_RowDataBound(Object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                int tipoVisualizacaoId = ((List<TipoProgramacaoModel>)GridTiposProgramacao.DataSource)[e.Row.RowIndex].TPVZ_ID;
                var visualizacao = TiposVisualizacao.Where(v => v.TPVZ_ID == tipoVisualizacaoId).FirstOrDefault();
                e.Row.Cells[6].Text = visualizacao.TPVZ_DESCRICAO;
            }

        }


        protected void GridTiposProgramacao_SelectedIndexChanged(object sender, GridViewSelectEventArgs e)
        {
            Response.Redirect($"TipoProgramacaoEdit.aspx?tipoProgramacaoId={GridTiposProgramacao.DataKeys[e.NewSelectedIndex].Value}");
        }

        protected void btnVoltar_Click(object sender, EventArgs e)
        {
            Response.Redirect("Index.aspx");
        }
    }
}