﻿using Ferias.Web.Dao.Ferias;
using FeriasWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Pier.Web
{
    public partial class DelegacaoLancamentoNova : DelegacaoPerfil
    {
        public int GestorId { get; set; }
        public int DelegadoId { get; set; }
        public List<FeriasDelegaModel> DelegacaoLista = new List<FeriasDelegaModel>();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GestorId = Convert.ToInt32(Request.QueryString["GestorId"]);

                if (GestorId == 0)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "MensagemRetorno", "swal({ text: '', title: '', icon: 'info'});", true);
                    Util.Alert.Show(this.Page, "Você não está autorizado a acessar essa página.", "error", "Delegação de Lançamento");
                    System.Threading.Thread.Sleep(5000);
                    Response.Redirect("default.aspx");
                }

                lblGestor.Text = Request.QueryString["nomeGestor"];

                DelegadoId = Convert.ToInt32(Request.QueryString["delegadoId"]);

                LoadFeriasDelega();
            }
        }

        protected void btnVoltar_Click(object sender, EventArgs e)
        {
            Response.Redirect($"DelegacaoLancamento.aspx");
        }

        protected void btnSalvar_Click(object sender, EventArgs e)
        {
            if (cboFuncionarioDelegado.SelectedIndex <=0)
            {
                Util.Alert.Show(this.Page,"Por favor escolha o funcionário delegado", "info", "Delegação de Lançamento");
                return;
            }

            if (lstSelected.Items.Count == 0)
            {
                Util.Alert.Show(this.Page, "Por favor escolha pelo menos um funcionário", "info", "Delegação de Lançamento");
                return;
            }

            List<FeriasDelegaModel> feriaDelegaList = new List<FeriasDelegaModel>();

            DelegadoId = Convert.ToInt32(cboFuncionarioDelegado.SelectedValue);

            if (GestorId == 0 )
            {
                GestorId = Convert.ToInt32(Request.QueryString["GestorId"]); 
            }
            
            foreach (var item in lstSelected.Items)
            {
                FeriasDelegaModel model = new FeriasDelegaModel()
                {
                    FRDL_ATIVO = true,
                    FRDL_CRIACAO = DateTime.Now,
                    FRDL_FLOW_GESTOR = chkRequerValidacao.Checked,
                    FUNC_GESTOR = GestorId,
                    FUNC_REGISTRO_DELEGADO = DelegadoId,
                    FUNC_REGISTRO_FILHO = Convert.ToInt32(((ListItem)item).Value)
                };

                feriaDelegaList.Add(model);
            }

            FeriasDelega feriasDelegaDAO = new FeriasDelega();

            if (feriaDelegaList.Count >0)
            {
                feriasDelegaDAO.IncluirDelegacaoLancamento(feriaDelegaList).GetAwaiter().GetResult();
                AtivarDesativarAcesso(DelegadoId.ToString(), "3391", "Funcionário Delegado", "A");
            }

            cboFuncionarioDelegado.SelectedIndex = 0;
            chkRequerValidacao.Checked = false;

            btnVoltar_Click(null, null);
        }

        protected void btnSelect_Click(object sender, ImageClickEventArgs e)
        {
            MoveSelectedItems(lstUnselected, lstSelected);
        }

        #region Private Methods
        private void SetButtonsEditable()
        {
            btnSelect.Enabled = (lstUnselected.Items.Count > 0);
            btnSelectAll.Enabled = (lstUnselected.Items.Count > 0);
            btnUnselect.Enabled = (lstSelected.Items.Count > 0);
            btnUnselectAll.Enabled = (lstSelected.Items.Count > 0);
        }

        private void MoveAllItems(ListBox lstFrom, ListBox lstTo)
        {
            foreach (var item in lstFrom.Items)
            {
                lstTo.Items.Add((ListItem)item);
            }
            
            lstFrom.Items.Clear();
            SetButtonsEditable();
        }

        private void MoveSelectedItems(ListBox lstFrom, ListBox lstTo)
        {
             List<FuncionarioModel> itemsFrom = new List<FuncionarioModel>();
             List<FuncionarioModel> itemsTo = new List<FuncionarioModel>();

             foreach (var item in lstFrom.Items)
             {
                var funcionario = new FuncionarioModel() { FUNC_REGISTRO = ((ListItem)item).Value, FUNC_NOME = ((ListItem)item).Text };
                
                if (((ListItem)item).Selected)
                 {
                   
                     /* lstTo.Items.Add((ListItem)item);
                      lstFrom.Items.Remove((ListItem)item);*/
                     itemsTo.Add(funcionario);
                 }
                 else
                 {
                     itemsFrom.Add(funcionario);
                 }
             }

             foreach (var item in lstTo.Items)
             {
                var funcionario = new FuncionarioModel() { FUNC_REGISTRO = ((ListItem)item).Value, FUNC_NOME = ((ListItem)item).Text };
                itemsTo.Add(funcionario);
             }

             lstTo.DataSource = itemsTo.OrderBy(f=>f.FUNC_NOME);
             lstFrom.DataSource = itemsFrom.OrderBy(f => f.FUNC_NOME);

             lstTo.DataBind();
             lstFrom.DataBind();

            SetButtonsEditable();
        }
        private void LoadFeriasDelega()
        {
            FeriasDelega feriasDelega = new FeriasDelega();
            List<FeriasDelegaModel> delegacaoList = feriasDelega.GetFeriasDelega(GestorId).Where(f=> f.FRDL_CANCEL == DateTime.MinValue).ToList();

            Funcionario funcionario = new Funcionario();

            List<FuncionarioModel> funcionarios = funcionario.GetFuncionarios(0).Where(f => f.FUNC_GESTOR == GestorId || f.FUNC_REGISTRO == GestorId.ToString()).ToList();

            lstUnselected.Items.Clear();
            lstSelected.Items.Clear();

            foreach (var item in funcionarios)
            {
                if (delegacaoList.Count(d => d.FUNC_REGISTRO_FILHO.ToString() == item.FUNC_REGISTRO && d.FUNC_REGISTRO_DELEGADO == DelegadoId) == 0)
                {
                    lstUnselected.Items.Add(new ListItem { Value = item.FUNC_REGISTRO, Text = item.FUNC_NOME });
                }
                else
                {
                    lstSelected.Items.Add(new ListItem { Value = item.FUNC_REGISTRO, Text = item.FUNC_NOME });                    
                }
            }

            if (cboFuncionarioDelegado.Items.Count == 0)
            {
                cboFuncionarioDelegado.DataSource = funcionarios;
                cboFuncionarioDelegado.DataBind();

                cboFuncionarioDelegado.Items.Insert(0, new ListItem() { Value = "0", Text = "(Todos)" });
                cboFuncionarioDelegado.SelectedValue = DelegadoId.ToString();
            }
        }
        #endregion

        protected void cboFuncionarioDelegado_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboFuncionarioDelegado.SelectedIndex >=0 )
            {
                DelegadoId = Convert.ToInt32(cboFuncionarioDelegado.SelectedValue);
                LoadFeriasDelega();
            }
        }

        protected void btnSelectAll_Click(object sender, ImageClickEventArgs e)
        {
            MoveAllItems(lstUnselected,lstSelected);
        }

        protected void btnUnselect_Click(object sender, ImageClickEventArgs e)
        {
            MoveSelectedItems(lstSelected,lstUnselected);
        }

        protected void btnUnselectAll_Click(object sender, ImageClickEventArgs e)
        {
            MoveAllItems(lstSelected, lstUnselected);
        }

        protected void chkRequerValidacao_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}