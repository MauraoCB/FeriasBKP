﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using iTextSharp.text.html.simpleparser;
using System.Data;

namespace Pier.Web.Util
{
    public class Excel
    {
        public static void ExportGrid(GridView grdToExport, string Arquivo)
        {
            string attachment = "attachment; filename=" + Arquivo + ".xls";

            //Response.ClearContent();
            HttpContext.Current.Response.ClearContent();


            HttpContext.Current.Response.Buffer = true;
            HttpContext.Current.Response.AddHeader("content-disposition", attachment);
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";
            HttpContext.Current.Response.Charset = "";

            grdToExport.EnableViewState = false;

            System.IO.StringWriter sw = new System.IO.StringWriter();
            HtmlTextWriter htw = new HtmlTextWriter(sw);

            grdToExport.RenderControl(htw);
            HttpContext.Current.Response.Write(sw.ToString());
            HttpContext.Current.Response.End();
        }


        public static bool GerarExcelHtml(GridView gr, string tituloRelatorio, string subTitulo, string nomeRelatorio)
        {

            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment;filename=Relatorio_{0}.xls", nomeRelatorio + DateTime.Now.ToString("dd/MM/yyyy").Substring(0, 2) + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString()));
            HttpContext.Current.Response.ContentType = "application/ms-excel";
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Default;
            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);




            String cabecalho = String.Format("<div><table><tr rowspan=\"4\"><td><img src=\"http://pier_web_base.santosbrasil.com.br/Images/sbsa_80x60.jpg\"/></td><td colspan=\"{1}\" align=\"center\"><h2>{0}</h2></td></tr>{2}</table>", tituloRelatorio, gr.Columns.Count - 1, String.IsNullOrEmpty(subTitulo) ? "" : String.Format("<tr><td /><td colspan=\"{0}\" align=\"center\"><h3>{1}</h3></td></tr>", gr.Columns.Count - 1, subTitulo));

            String retornoHtml = "";

            retornoHtml = cabecalho;
            retornoHtml += "<table>";
            retornoHtml += "<tr>";


            retornoHtml += "<tr bgcolor=\"#CCCCCC\">";
            for (int i = 0; i < gr.Columns.Count; i++)
            {


                retornoHtml += "<td><font size=\"10px\" align=\"center\" border=\"solid 1px black\">" + gr.Columns[i].HeaderText.Trim() + "</font></td>";




            }
            retornoHtml += "</tr>";


            foreach (GridViewRow row in gr.Rows)
            {
                retornoHtml += "<tr>";
                for (int i = 0; i < gr.Columns.Count; i++)
                {

                    retornoHtml += "<td><font size=\"10px\" align=\"center\" border=\"solid 1px black\">" + row.Cells[i].Text + "</font></td>";


                }
                retornoHtml += "</tr>";

            }

            retornoHtml += "</div></table>";
            HttpContext.Current.Response.Write(retornoHtml);
            HttpContext.Current.Response.End();

            return true;


        }
        public static void ExportHtml(string htmlExport, string Arquivo)
        {
            string attachment = "attachment; filename=" + Arquivo + ".xls";

            //Response.ClearContent();
            HttpContext.Current.Response.ClearContent();


            HttpContext.Current.Response.Buffer = true;
            HttpContext.Current.Response.AddHeader("content-disposition", attachment);
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";
            HttpContext.Current.Response.Charset = "";


            //this.EnableViewState = false;

            System.IO.StringWriter sw = new System.IO.StringWriter();
            HtmlTextWriter htw = new HtmlTextWriter(sw);



            HttpContext.Current.Response.Write(sw.ToString());
            HttpContext.Current.Response.Redirect("", false);
        }


        public static void ExportToExcelDataTable(DataTable Dt, string tituloRelatorio, string subTitulo, string nomeRelatorio)
        {
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment;filename=Relatorio_{0}.xls", nomeRelatorio + DateTime.Now.ToString("dd/MM/yyyy").Substring(0, 2) + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString()));

            HttpContext.Current.Response.ContentType = "application/ms-excel";
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Default;

            StringBuilder sb = new StringBuilder();
            sb.Append("<style type=\"text/css\">\r\n");
            sb.Append(".tabHead\r\n");
            sb.Append("{\r\n");
            sb.Append("   background-color: #CCCCCC;\r\n");
            sb.Append("   border: solid 1px black;\r\n");
            sb.Append("   color: White;\r\n");
            sb.Append("   font-weight: bold;\r\n");
            sb.Append("}\r\n");
            sb.Append(".tabRow\r\n");
            sb.Append("{\r\n");
            sb.Append("   border: solid 1px black;\r\n");
            sb.Append("}\r\n");
            sb.Append("</style>\r\n\r\n");

            String cabecalho = String.Format("<div><table><tr rowspan=\"4\"><td><img src=\"http://pier_web_base.santosbrasil.com.br/Images/sbsa_80x60.jpg\"/></td><td colspan=\"{1}\" align=\"center\"><h2>{0}</h2></td></tr>{2}</table>", tituloRelatorio, Dt.Columns.Count - 1, String.IsNullOrEmpty(subTitulo) ? "" : String.Format("<tr><td /><td colspan=\"{0}\" align=\"center\"><h3>{1}</h3></td></tr>", Dt.Columns.Count - 1, subTitulo));

            sb.Append(cabecalho);
            sb.AppendFormat("<table>\r\n");
            sb.AppendFormat("<thead>\r\n");
            sb.AppendFormat("<tr>\r\n");

            //Columns
            foreach (DataColumn Column in Dt.Columns)
            {
                sb.AppendFormat("\t<td class=\"tabHead\">" + Column.ColumnName + "</td>\r\n");
            }
            sb.AppendFormat("</tr>\r\n");
            sb.AppendFormat("</thead>\r\n");
            sb.AppendFormat("<tbody>\r\n");

            //Row
            foreach (DataRow Row in Dt.Rows)
            {
                sb.AppendFormat("<tr>\r\n");
                for (int x = 0; x < Dt.Columns.Count; x++)
                {
                    sb.AppendFormat("\t<td class=\"tabRow\">" + Row[x].ToString().Trim() + "</td>\r\n");
                }
                sb.AppendFormat("</tr>\r\n");
            }
            sb.AppendFormat("</tbody>\r\n");
            sb.AppendFormat("</table>\r\n");

            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.Response.Write("<html><head><style type='text/css'>" + sb.ToString() + "</style></head></html>");
            HttpContext.Current.Response.End();
        }
        public static void ExportToExcelDataTableSimples(DataTable Dt, string nomeRelatorio)
        {
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment;filename=Relatorio_{0}.xls", nomeRelatorio + DateTime.Now.ToString("dd/MM/yyyy").Substring(0, 2) + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString()));

            HttpContext.Current.Response.ContentType = "application/ms-excel";
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Default;

            StringBuilder sb = new StringBuilder();
            sb.Append("<style type=\"text/css\">\r\n");
            sb.Append(".tabHead\r\n");
            sb.Append("{\r\n");
            sb.Append("   background-color: #CCCCCC;\r\n");
            sb.Append("   border: solid 1px black;\r\n");
            sb.Append("   color: White;\r\n");
            sb.Append("   font-weight: bold;\r\n");
            sb.Append("}\r\n");
            sb.Append(".tabRow\r\n");
            sb.Append("{\r\n");
            sb.Append("   border: solid 1px black;\r\n");
            sb.Append("}\r\n");
            sb.Append("</style>\r\n\r\n");


            sb.AppendFormat("<table>\r\n");
            sb.AppendFormat("<thead>\r\n");
            sb.AppendFormat("<tr>\r\n");



            //Columns
            foreach (DataColumn Column in Dt.Columns)
            {
                sb.AppendFormat("\t<td class=\"tabHead\">" + Column.ColumnName + "</td>\r\n");
            }
            sb.AppendFormat("</tr>\r\n");
            sb.AppendFormat("</thead>\r\n");
            sb.AppendFormat("<tbody>\r\n");

            //Row
            foreach (DataRow Row in Dt.Rows)
            {
                sb.AppendFormat("<tr>\r\n");
                for (int x = 0; x < Dt.Columns.Count; x++)
                {
                    sb.AppendFormat("\t<td class=\"tabRow\">" + Row[x].ToString().Trim() + "</td>\r\n");
                }
                sb.AppendFormat("</tr>\r\n");
            }
            sb.AppendFormat("</tbody>\r\n");
            sb.AppendFormat("</table>\r\n");

            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.Response.Write("<html><head><style type='text/css'>" + sb.ToString() + "</style></head></html>");
            HttpContext.Current.Response.End();
        }


        public static void ExportGridViewToExcel(GridView gr, string nomeRelatorio, String tituloRelatorio = "", String subTitulo = "")
        {
            StringWriter sw = new StringWriter();
            HtmlTextWriter tw = new HtmlTextWriter(sw);
            Control parent = gr.Parent;
            int GridIndex = 0;
            if (parent != null)
            {
                GridIndex = parent.Controls.IndexOf(gr);
                parent.Controls.Remove(gr);
            }
            RemoveLinks(gr);

            gr.RenderControl(tw);

            if (parent != null)
            {
                parent.Controls.AddAt(GridIndex, gr);
            }
            tw.Flush();

            String cabecalho = String.Format("<div><table><tr rowspan=\"4\"><td><img src=\"http://pier_web_base.santosbrasil.com.br/Images/sbsa_80x60.jpg\"/></td><td colspan=\"{1}\" align=\"center\"><h2>{0}</h2></td></tr>{2}</table>", tituloRelatorio, gr.Columns.Count - 1, String.IsNullOrEmpty(subTitulo) ? "" : String.Format("<tr><td /><td colspan=\"{0}\" align=\"center\"><h3>{1}</h3></td></tr>", gr.Columns.Count - 1, subTitulo));
            var html = new StringBuilder(cabecalho + sw.ToString().Substring(6));
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment;filename=Relatorio_{0}.xls", nomeRelatorio + DateTime.Now.ToString("dd/MM/yyyy").Substring(0, 2) + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString()));
            HttpContext.Current.Response.ContentType = "application/ms-excel";
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Default;
            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.Response.Write(html.ToString());
            HttpContext.Current.Response.End();
        }

        public static void ExportGridViewToExcelSemLogo(GridView gr, string nomeRelatorio, String tituloRelatorio = "", String subTitulo = "")
        {
            StringWriter sw = new StringWriter();
            HtmlTextWriter tw = new HtmlTextWriter(sw);
            Control parent = gr.Parent;
            int GridIndex = 0;
            if (parent != null)
            {
                GridIndex = parent.Controls.IndexOf(gr);
                parent.Controls.Remove(gr);
            }
            RemoveLinks(gr);
            gr.RenderControl(tw);

            if (parent != null)
            {
                parent.Controls.AddAt(GridIndex, gr);
            }
            tw.Flush();

            var html = new StringBuilder(sw.ToString().Substring(6));
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment;filename=Relatorio_{0}.xls", nomeRelatorio + DateTime.Now.ToString("dd/MM/yyyy").Substring(0, 2) + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString()));
            HttpContext.Current.Response.ContentType = "application/ms-excel";
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Default;
            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.Response.Write(html.ToString());
            HttpContext.Current.Response.End();
        }

        public static void ExportGridViewImoOnuToExcel(GridView gr, string nomeRelatorio, String tituloRelatorio, String subTitulo = "")
        {
            StringWriter sw = new StringWriter();
            HtmlTextWriter tw = new HtmlTextWriter(sw);
            Control parent = gr.Parent;
            int GridIndex = 0;
            if (parent != null)
            {
                GridIndex = parent.Controls.IndexOf(gr);
                parent.Controls.Remove(gr);
            }
            RemoveLinks(gr);
            gr.RenderControl(tw);

            if (parent != null)
            {
                parent.Controls.AddAt(GridIndex, gr);
            }
            tw.Flush();

            String cabecalho = String.Format("<div><table><tr rowspan=\"4\"><td><img src=\"http://pier_web_base.santosbrasil.com.br/Images/sbsa_80x60.jpg\"/></td><td colspan=\"{1}\" align=\"center\"><h2>{0}</h2></td></tr>{2}<tr><td><br /><br /><br /></td></tr></table>", tituloRelatorio, gr.Columns.Count - 1, String.IsNullOrEmpty(subTitulo) ? "" : String.Format("<tr><td /><td colspan=\"{0}\" align=\"center\"><h3>{1}</h3></td></tr>", gr.Columns.Count - 1, subTitulo));
            //String cabecalho = String.Format("<div><table><tr rowspan=\"4\"><td></td><td colspan=\"{1}\" align=\"center\"><h3>{0}</h3></td></tr>{2}</table>", tituloRelatorio, gr.Columns.Count - 1, String.IsNullOrEmpty(subTitulo) ? "" : String.Format("<tr><td /><td colspan=\"{0}\" align=\"center\"><h3>{1}</h3></td></tr>", gr.Columns.Count - 1, subTitulo));
            var html = new StringBuilder(cabecalho + sw.ToString().Substring(6));
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment;filename=Relatorio_{0}.xls", nomeRelatorio + DateTime.Now.ToString("dd/MM/yyyy").Substring(0, 2) + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString()));
            HttpContext.Current.Response.ContentType = "application/ms-excel";
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Default;
            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.Response.Write(html.ToString());
            HttpContext.Current.Response.End();
        }

        private static void RemoveLinks(GridView grid)
        {
            RemoveByRow(grid.HeaderRow);
            foreach (GridViewRow linha in grid.Rows)
            {
                RemoveByRow(linha);
            }
            RemoveByRow(grid.FooterRow);



        }
        private static void RemoveByRow(GridViewRow row)
        {
            if (row != null && row.Cells != null)
            {
                //foreach (LinkButton celula in row.Cells)
                //{
                //    foreach (Control controlex in celula.Controls)
                //    {
                //        if (controlex is System.Web.UI.WebControls.DataPager)
                //        {
                //            celula.Controls.Remove(controlex);
                //            //celula.Controls.Add(new Label { Text = (controlex as System.Web.UI.WebControls.DataPager). });
                //        }
                //    }
                //}
                foreach (DataControlFieldCell celula in row.Cells)
                {
                    foreach (Control controle in celula.Controls)
                    {
                        if (controle is System.Web.UI.WebControls.LinkButton)
                        {
                            celula.Controls.Remove(controle);
                            celula.Controls.Add(new Label { Text = (controle as System.Web.UI.WebControls.LinkButton).Text });
                        }
                        else if (controle is System.Web.UI.WebControls.Button)
                        {
                            celula.Controls.Remove(controle);
                            celula.Controls.Add(new Label { Text = (controle as System.Web.UI.WebControls.Button).Text });
                        }
                        else if (controle is HyperLink)
                        {
                            celula.Controls.Remove(controle);
                            //   celula.Controls.AddAt(i, new LiteralControl((controle as HyperLink).Text));
                        }
                        else if (controle is System.Web.UI.WebControls.CheckBox)
                        {
                            celula.Controls.Remove(controle);
                            //  celula.Controls.Add(new Label { Text = (controle as System.Web.UI.WebControls.CheckBox).Text   });
                        }
                    }

                }
            }
        }


        public static void Export(string fileName, GridView gv)
        {
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.AddHeader(
                "content-disposition", string.Format("attachment; filename={0}.xls", fileName));
            HttpContext.Current.Response.ContentType = "application/ms-excel";

            using (StringWriter sw = new StringWriter())
            {
                using (HtmlTextWriter htw = new HtmlTextWriter(sw))
                {
                    //  Create a form to contain the grid
                    Table table = new Table();

                    //  add the header row to the table
                    if (gv.HeaderRow != null)
                    {
                        PrepareControlForExport(gv.HeaderRow);
                        table.Rows.Add(gv.HeaderRow);
                    }

                    //  add each of the data rows to the table
                    foreach (GridViewRow row in gv.Rows)
                    {
                        PrepareControlForExport(row);
                        table.Rows.Add(row);
                    }

                    //  add the footer row to the table
                    if (gv.FooterRow != null)
                    {
                        PrepareControlForExport(gv.FooterRow);
                        table.Rows.Add(gv.FooterRow);
                    }

                    //  render the table into the htmlwriter
                    table.RenderControl(htw);

                    //  render the htmlwriter into the response
                    HttpContext.Current.Response.Write(sw.ToString());
                    HttpContext.Current.Response.End();
                }
            }
        }

        /// <summary>
        /// Replace any of the contained controls with literals
        /// </summary>
        /// <param name="control"></param>
        private static void PrepareControlForExport(Control control)
        {
            for (int i = 0; i < control.Controls.Count; i++)
            {
                Control current = control.Controls[i];
                if (current is LinkButton)
                {
                    control.Controls.Remove(current);
                    control.Controls.AddAt(i, new LiteralControl((current as LinkButton).Text));
                }
                else if (current is ImageButton)
                {
                    control.Controls.Remove(current);
                    control.Controls.AddAt(i, new LiteralControl((current as ImageButton).AlternateText));
                }
                else if (current is HyperLink)
                {
                    control.Controls.Remove(current);
                    control.Controls.AddAt(i, new LiteralControl((current as HyperLink).Text));
                }
                else if (current is DropDownList)
                {
                    control.Controls.Remove(current);
                    control.Controls.AddAt(i, new LiteralControl((current as DropDownList).SelectedItem.Text));
                }
                else if (current is CheckBox)
                {
                    control.Controls.Remove(current);
                    control.Controls.AddAt(i, new LiteralControl((current as CheckBox).Checked ? "True" : "False"));
                }

                if (current.HasControls())
                {
                    PrepareControlForExport(current);
                }
            }

        }
    }
}